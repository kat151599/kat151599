export interface IAccessPermissionDefinition {
key: string
category: string
}
export interface IAccessGroup {
id: number
name: string
description: string
system_key?: 'admin' | 'users' | string
permissions: string[]
member_count: number
created?: number
updated?: number
}
export interface IAccessUser {
id: number
username: string
name: string
email: string
phone: string
notes: string
is_admin: boolean
status: number
created: number
updated: number
groups: IAccessGroup[]
permissions?: string[]
permission_overrides?: Record<string, boolean>
}
export interface IAccessMe {
permissions: string[]
groups: IAccessGroup[]
}
export const ACCESS_PERMISSION = {
PROJECTS_VIEW: 'projects.view',
PROJECTS_MANAGE: 'projects.manage',
TASKS_ACCESS: 'tasks.access',
TASKS_VIEW_OWN: 'tasks.view_own',
TASKS_VIEW_PROJECT: 'tasks.view_project',
TASKS_VIEW_ALL: 'tasks.view_all',
TASKS_EDIT_OWN: 'tasks.edit_own',
TASKS_EDIT_PROJECT: 'tasks.edit_project',
TASKS_EDIT_ALL: 'tasks.edit_all',
LABELS_VIEW: 'labels.view',
LABELS_MANAGE: 'labels.manage',
TEAMS_VIEW: 'teams.view',
TEAMS_MANAGE: 'teams.manage',
WORK_GROUPS_MANAGE: 'work_groups.manage',
KANBAN_USE: 'kanban.use',
TIME_TRACKING: 'time_tracking.use',
WIALON_VIEW: 'wialon.view',
CALLCENTER_ACCESS: 'callcenter.access',
CALLCENTER_DASHBOARD_VIEW: 'callcenter.dashboard.view',
CALLCENTER_DIALER_USE: 'callcenter.dialer.use',
CALLCENTER_DATABASE_VIEW: 'callcenter.database.view',
CALLCENTER_DATABASE_EDIT: 'callcenter.database.edit',
CALLCENTER_CALLS_VIEW_OWN: 'callcenter.calls.view_own',
CALLCENTER_CALLS_VIEW_ALL: 'callcenter.calls.view_all',
CALLCENTER_CAMPAIGNS_VIEW: 'callcenter.campaigns.view',
CALLCENTER_CAMPAIGNS_MANAGE: 'callcenter.campaigns.manage',
CALLCENTER_ANALYTICS_VIEW: 'callcenter.analytics.view',
CALLCENTER_IMPORT: 'callcenter.import',
CALLCENTER_EXPORT: 'callcenter.export',
CALLCENTER_SETTINGS_MANAGE: 'callcenter.settings.manage',
} as const
