import type {IAbstract} from '@/modelTypes/IAbstract'

export interface IProjectFolder extends IAbstract {
	id: number
	title: string
	parentFolderId: number
	position: number
	created: Date
	updated: Date
}

export interface IProjectFolderProject {
	projectId: number
	folderId: number
	position: number
}

export interface IProjectFolderState {
	folders: IProjectFolder[]
	projects: IProjectFolderProject[]
}
