import type {Priority} from '@/constants/priorities'

import type {IAbstract} from './IAbstract'
import type {IUser} from './IUser'
import type {ILabel} from './ILabel'
import type {IAttachment} from './IAttachment'
import type {ISubscription} from './ISubscription'
import type {IProject} from './IProject'
import type {IBucket} from './IBucket'

import type {IRelationKind} from '@/types/IRelationKind'
import type {IRepeatAfter} from '@/types/IRepeatAfter'
import type {IRepeatMode} from '@/types/IRepeatMode'

import type {PartialWithId} from '@/types/PartialWithId'
import type {ITaskReminder} from '@/modelTypes/ITaskReminder'
import type {IReactionPerEntity} from '@/modelTypes/IReaction'
import type {ITaskComment} from '@/modelTypes/ITaskComment.ts'
import type {IWorkGroupSummary} from '@/modelTypes/IWorkGroup'

export type TaskWorkflowState = 'new' | 'in_progress' | 'waiting'

export interface ITask extends IAbstract {
	id: number
	title: string
	description: string
	workflowState: TaskWorkflowState
	done: boolean
	doneAt: Date | null
	deletedAt: Date | null
	priority: Priority
	labels: ILabel[]
	assignees: IUser[]
	workGroups?: IWorkGroupSummary[]

	dueDate: Date | null
	startDate: Date | null
	endDate: Date | null
	repeatAfter: number | IRepeatAfter
	repeatFromCurrentDate: boolean
	repeatMode: IRepeatMode
	reminders: ITaskReminder[]
	parentTaskId: ITask['id']
	hexColor: string
	percentDone: number
	relatedTasks: Partial<Record<IRelationKind, ITask[]>>
	attachments: IAttachment[]
	coverImageAttachmentId: IAttachment['id'] | null
	identifier: string
	index: number
	isFavorite: boolean
	isUnread?: boolean
	subscription: ISubscription

	position: number
	
	reactions: IReactionPerEntity
	comments: ITaskComment[]
	commentCount?: number
	timeEntriesCount?: number

	createdBy: IUser
	created: Date
	updated: Date

	projectId: IProject['id'] // Meta, only used when creating a new task
	bucketId: IBucket['id']
	buckets: IBucket[]
}

export type ITaskPartialWithId = PartialWithId<ITask>
