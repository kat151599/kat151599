import type {ITask} from '@/modelTypes/ITask'

export interface ProjectProgressSummary {
	total: number
	done: number
	pending: number
	percent: number
}

function validTime(value: Date | null | undefined): number | null {
	if (!(value instanceof Date)) {
		return null
	}

	const time = value.getTime()
	return Number.isFinite(time) ? time : null
}

export function getProjectProgressOrderDate(task: ITask): number | null {
	return validTime(task.startDate)
		?? validTime(task.dueDate)
		?? validTime(task.endDate)
}

function stableTaskOrder(task: ITask): number {
	if (Number.isFinite(task.index) && task.index > 0) {
		return task.index
	}

	return task.id
}

export function sortProjectProgressTasks(tasks: ITask[]): ITask[] {
	return [...tasks].sort((a, b) => {
		const aDate = getProjectProgressOrderDate(a)
		const bDate = getProjectProgressOrderDate(b)

		if (aDate !== null && bDate !== null && aDate !== bDate) {
			return aDate - bDate
		}

		if (aDate !== null && bDate === null) {
			return -1
		}

		if (aDate === null && bDate !== null) {
			return 1
		}

		const indexDiff = stableTaskOrder(a) - stableTaskOrder(b)
		if (indexDiff !== 0) {
			return indexDiff
		}

		return a.id - b.id
	})
}

export function summarizeProjectProgress(tasks: ITask[]): ProjectProgressSummary {
	const done = tasks.reduce(
		(count, task) => count + (task.done ? 1 : 0),
		0,
	)
	const total = tasks.length

	return {
		total,
		done,
		pending: total - done,
		percent: total === 0 ? 0 : Math.round((done / total) * 100),
	}
}
