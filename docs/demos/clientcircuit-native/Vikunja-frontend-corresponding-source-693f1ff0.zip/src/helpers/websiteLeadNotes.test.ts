import {describe, expect, it} from 'vitest'
import {visibleLeadNote} from './websiteLeadNotes'

describe('website lead notes', () => {
    const prefix = '[GTT_WEB_FORM_ATTEMPT; trigger=button_click; accepted_by_okaycms=UNKNOWN]'

    it('shows only the visitor message on old website-click leads', () => {
        expect(visibleLeadNote(prefix + '\nПожалуйста, перезвоните', 'website', 'website_form'))
            .toBe('Пожалуйста, перезвоните')
    })

    it('supports CRLF, marker-only notes, and normal site enquiries', () => {
        expect(visibleLeadNote(prefix + '\r\nТекст', 'website', 'website_form')).toBe('Текст')
        expect(visibleLeadNote(prefix, 'website', 'website_form')).toBe('')
        expect(visibleLeadNote('Текст клиента', 'website', 'website_form')).toBe('Текст клиента')
    })

    it('does not erase markers from unrelated/manual leads or other positions', () => {
        expect(visibleLeadNote(prefix + '\nТекст', 'manual', 'manual')).toBe(prefix + '\nТекст')
        expect(visibleLeadNote('Комментарий\n' + prefix, 'website', 'website_form'))
            .toBe('Комментарий\n' + prefix)
    })
})
