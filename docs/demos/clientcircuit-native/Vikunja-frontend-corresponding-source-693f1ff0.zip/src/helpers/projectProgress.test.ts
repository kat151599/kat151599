import {describe, expect, it} from 'vitest'

import {
	getProjectProgressOrderDate,
	sortProjectProgressTasks,
	summarizeProjectProgress,
} from '@/helpers/projectProgress'

import type {ITask} from '@/modelTypes/ITask'

function task(
	id: number,
	values: Partial<ITask> = {},
): ITask {
	return {
		id,
		index: id,
		done: false,
		startDate: null,
		dueDate: null,
		endDate: null,
		...values,
	} as ITask
}

describe('project progress', () => {
	it('uses start date, then due date, then end date for ordering', () => {
		const start = new Date('2026-10-02T00:00:00Z')
		const due = new Date('2026-10-03T00:00:00Z')
		const end = new Date('2026-10-04T00:00:00Z')

		expect(getProjectProgressOrderDate(task(1, {
			startDate: start,
			dueDate: due,
			endDate: end,
		}))).toBe(start.getTime())

		expect(getProjectProgressOrderDate(task(2, {
			dueDate: due,
			endDate: end,
		}))).toBe(due.getTime())

		expect(getProjectProgressOrderDate(task(3, {
			endDate: end,
		}))).toBe(end.getTime())
	})

	it('places dated tasks first and falls back to task index', () => {
		const tasks = [
			task(10, {index: 2}),
			task(11, {
				index: 9,
				dueDate: new Date('2026-10-03T00:00:00Z'),
			}),
			task(12, {
				index: 1,
				dueDate: new Date('2026-10-02T00:00:00Z'),
			}),
			task(13, {index: 1}),
		]

		expect(sortProjectProgressTasks(tasks).map(t => t.id))
			.toEqual([12, 11, 13, 10])
	})

	it('summarizes completed tasks', () => {
		const summary = summarizeProjectProgress([
			task(1, {done: true}),
			task(2, {done: true}),
			task(3),
		])

		expect(summary).toEqual({
			total: 3,
			done: 2,
			pending: 1,
			percent: 67,
		})
	})
})
