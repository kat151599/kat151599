import {Capacitor} from '@capacitor/core'

import {AuthenticatedHTTPFactory} from '@/helpers/fetcher'

export type WebPushState =
	| 'unsupported'
	| 'requires-install'
	| 'not-configured'
	| 'blocked'
	| 'available'
	| 'enabled'

interface WebPushConfig {
	enabled: boolean
	public_key: string
}

let cachedConfig: WebPushConfig | null = null

interface PushSubscriptionJSONLike {
	endpoint: string
	keys: {
		p256dh: string
		auth: string
	}
}

function isIOSLike(): boolean {
	const ua = navigator.userAgent
	const classicIOS = /iPad|iPhone|iPod/.test(ua)
	const iPadDesktopUA = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1
	return classicIOS || iPadDesktopUA
}

export function isStandaloneWebApp(): boolean {
	const navigatorWithStandalone = navigator as Navigator & {standalone?: boolean}
	return window.matchMedia('(display-mode: standalone)').matches || navigatorWithStandalone.standalone === true
}

function browserSupportsWebPush(): boolean {
	return !Capacitor.isNativePlatform() &&
		window.isSecureContext &&
		'serviceWorker' in navigator &&
		'PushManager' in window &&
		'Notification' in window
}

function subscriptionJSON(subscription: PushSubscription): PushSubscriptionJSONLike {
	const json = subscription.toJSON()
	const p256dh = json.keys?.p256dh ?? ''
	const auth = json.keys?.auth ?? ''

	if (!json.endpoint || !p256dh || !auth) {
		throw new Error('Browser returned an incomplete PushSubscription.')
	}

	return {
		endpoint: json.endpoint,
		keys: {p256dh, auth},
	}
}

function urlBase64ToArrayBuffer(value: string): ArrayBuffer {
	const padding = '='.repeat((4 - value.length % 4) % 4)
	const base64 = (value + padding)
		.replace(/-/g, '+')
		.replace(/_/g, '/')
	const raw = window.atob(base64)
	const buffer = new ArrayBuffer(raw.length)
	const output = new Uint8Array(buffer)
	for (let i = 0; i < raw.length; i++) {
		output[i] = raw.charCodeAt(i)
	}
	return buffer
}

async function getConfig(): Promise<WebPushConfig> {
	const {data} = await AuthenticatedHTTPFactory().get<WebPushConfig>('user/settings/web-push')
	cachedConfig = data
	return data
}

async function getExistingSubscription(): Promise<PushSubscription | null> {
	if (!browserSupportsWebPush()) {
		return null
	}

	const registration = await navigator.serviceWorker.ready
	return registration.pushManager.getSubscription()
}

async function registerSubscriptionWithBackend(subscription: PushSubscription): Promise<void> {
	await AuthenticatedHTTPFactory().put(
		'user/settings/web-push',
		subscriptionJSON(subscription),
	)
}

export async function getWebPushState(): Promise<WebPushState> {
	if (!browserSupportsWebPush()) {
		return 'unsupported'
	}
	if (isIOSLike() && !isStandaloneWebApp()) {
		return 'requires-install'
	}

	const config = await getConfig()
	if (!config.enabled || !config.public_key) {
		return 'not-configured'
	}

	if (Notification.permission === 'denied') {
		return 'blocked'
	}

	const existing = await getExistingSubscription()
	return existing ? 'enabled' : 'available'
}

export async function enableWebPush(): Promise<void> {
	if (!browserSupportsWebPush()) {
		throw new Error('Web Push is not supported in this browser.')
	}
	if (isIOSLike() && !isStandaloneWebApp()) {
		throw new Error('Install Vikunja on the Home Screen before enabling notifications.')
	}

	const config = cachedConfig
	if (!config?.enabled || !config.public_key) {
		throw new Error('Web Push is not ready yet. Reopen notification settings and try again.')
	}

	// On iOS the permission request must remain inside the direct user gesture.
	// Do not put a network/service-worker await before this call.
	const permission = await Notification.requestPermission()
	if (permission !== 'granted') {
		throw new Error('Notification permission was not granted.')
	}

	const registration = await navigator.serviceWorker.ready
	let subscription = await registration.pushManager.getSubscription()
	if (!subscription) {
		subscription = await registration.pushManager.subscribe({
			userVisibleOnly: true,
			applicationServerKey: urlBase64ToArrayBuffer(config.public_key),
		})
	}

	await registerSubscriptionWithBackend(subscription)
}

export async function syncExistingWebPushSubscription(): Promise<void> {
	if (!browserSupportsWebPush() || Notification.permission !== 'granted') {
		return
	}
	if (isIOSLike() && !isStandaloneWebApp()) {
		return
	}

	try {
		const subscription = await getExistingSubscription()
		if (!subscription) {
			return
		}

		const config = await getConfig()
		if (!config.enabled) {
			return
		}

		await registerSubscriptionWithBackend(subscription)
	} catch (error) {
		console.warn('[Vikunja] Could not sync web push subscription:', error)
	}
}

export async function disableWebPush(): Promise<void> {
	if (!browserSupportsWebPush()) {
		return
	}

	const subscription = await getExistingSubscription()
	if (!subscription) {
		return
	}

	try {
		await AuthenticatedHTTPFactory().delete('user/settings/web-push', {
			data: subscriptionJSON(subscription),
		})
	} finally {
		await subscription.unsubscribe()
	}
}

export async function unregisterWebPushOnLogout(): Promise<void> {
	try {
		await disableWebPush()
	} catch (error) {
		// Logout must continue even when the server is unreachable. The local
		// unsubscribe invalidates the endpoint, and the backend will prune it
		// after the push service returns an expired/gone response.
		console.warn('[Vikunja] Could not unregister web push subscription:', error)
	}
}
