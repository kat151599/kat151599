/**
 * Older website-click leads received a transport/audit marker inside their
 * user-facing notes. Hide only that exact first-line marker. Never modify an
 * ordinary note, or overwrite the original record when merely displaying it.
 */
const clickAttemptPrefix = /^[ \t]*\[GTT_WEB_FORM_ATTEMPT;[ \t]*trigger=button_click;[ \t]*accepted_by_okaycms=(?:UNKNOWN|YES|NO)\][ \t]*(?:\r?\n|$)/

export function visibleLeadNote(
    note: string | null | undefined,
    source: string | null | undefined,
    ingestMethod: string | null | undefined,
): string {
    if (!note) return ''
    if (source !== 'website' && ingestMethod !== 'website_form') return note
    return note.replace(clickAttemptPrefix, '')
}
