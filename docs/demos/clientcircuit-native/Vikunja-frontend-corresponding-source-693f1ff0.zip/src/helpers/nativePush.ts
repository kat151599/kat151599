import {Capacitor} from '@capacitor/core'
import {FirebaseMessaging} from '@capacitor-firebase/messaging'
import type {Router} from 'vue-router'

import {AuthenticatedHTTPFactory} from '@/helpers/fetcher'

const TOKEN_STORAGE_KEY = 'vikunja.nativePushToken'
const DEFAULT_PUSH_ROUTE = '/'

type NativePushPlatform = 'android' | 'ios'

let initialized = false
let shouldSyncRegistration = false
let currentToken: string | null = null
let appRouter: Router | null = null
let initializationPromise: Promise<void> | null = null
let registerPromise: Promise<void> | null = null

function nativePushPlatform(): NativePushPlatform | null {
	if (!Capacitor.isNativePlatform()) {
		return null
	}

	const platform = Capacitor.getPlatform()
	return platform === 'android' || platform === 'ios' ? platform : null
}

function safePushRoute(value: unknown): string {
	if (typeof value !== 'string' || !value.startsWith('/') || value.startsWith('//')) {
		return DEFAULT_PUSH_ROUTE
	}
	return value
}

function pushRouteFromData(value: unknown): string {
	if (typeof value !== 'object' || value === null) {
		return DEFAULT_PUSH_ROUTE
	}
	return safePushRoute((value as Record<string, unknown>).route)
}

async function registerTokenWithBackend(token: string, platform: NativePushPlatform): Promise<void> {
	try {
		await AuthenticatedHTTPFactory().put('user/settings/push-token', {
			token,
			platform,
		})
	} catch (error) {
		console.warn('[Vikunja] Could not register native push token:', error)
	}
}

async function removeTokenFromBackend(token: string, platform: NativePushPlatform): Promise<void> {
	try {
		await AuthenticatedHTTPFactory().delete('user/settings/push-token', {
			data: {
				token,
				platform,
			},
		})
	} catch (error) {
		console.warn('[Vikunja] Could not unregister native push token:', error)
	}
}

export function initializeNativePush(router: Router): Promise<void> {
	const platform = nativePushPlatform()
	if (!platform) {
		return Promise.resolve()
	}

	appRouter = router
	if (initializationPromise) {
		return initializationPromise
	}

	initializationPromise = (async () => {
		currentToken = localStorage.getItem(TOKEN_STORAGE_KEY)

		await FirebaseMessaging.addListener('tokenReceived', ({token}) => {
			if (!shouldSyncRegistration || !token) {
				return
			}

			currentToken = token
			localStorage.setItem(TOKEN_STORAGE_KEY, token)
			void registerTokenWithBackend(token, platform)
		})

		await FirebaseMessaging.addListener('notificationActionPerformed', (action) => {
			const route = pushRouteFromData(action.notification.data)
			if (appRouter) {
				void appRouter.push(route)
			}
		})

		initialized = true
	})().catch((error) => {
		console.warn('[Vikunja] Native push initialization failed:', error)
	})

	return initializationPromise
}

async function requestRegistration(): Promise<void> {
	if (registerPromise) {
		return registerPromise
	}

	registerPromise = (async () => {
		const platform = nativePushPlatform()
		if (!platform) {
			return
		}

		let permissions = await FirebaseMessaging.checkPermissions()
		if (permissions.receive === 'prompt' || permissions.receive === 'prompt-with-rationale') {
			permissions = await FirebaseMessaging.requestPermissions()
		}
		if (permissions.receive !== 'granted') {
			return
		}

		if (currentToken) {
			await registerTokenWithBackend(currentToken, platform)
		}

		const {token} = await FirebaseMessaging.getToken()
		if (!token) {
			return
		}

		currentToken = token
		localStorage.setItem(TOKEN_STORAGE_KEY, token)
		await registerTokenWithBackend(token, platform)
	})().finally(() => {
		registerPromise = null
	})

	return registerPromise
}

export async function syncNativePushToken(): Promise<void> {
	if (!nativePushPlatform()) {
		return
	}

	shouldSyncRegistration = true
	try {
		if (!initializationPromise) {
			return
		}
		await initializationPromise
		if (!initialized) {
			return
		}
		await requestRegistration()
	} catch (error) {
		console.warn('[Vikunja] Native push sync failed:', error)
	}
}

export async function unregisterNativePushToken(): Promise<void> {
	const platform = nativePushPlatform()
	if (!platform) {
		return
	}

	shouldSyncRegistration = false
	const token = currentToken ?? localStorage.getItem(TOKEN_STORAGE_KEY)
	if (token) {
		await removeTokenFromBackend(token, platform)
	}

	try {
		await FirebaseMessaging.deleteToken()
	} catch (error) {
		console.warn('[Vikunja] Native push unregister failed:', error)
	} finally {
		currentToken = null
		localStorage.removeItem(TOKEN_STORAGE_KEY)
	}
}
