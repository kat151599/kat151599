// Keep the real Vikunja product name outside the isolated portfolio demo.
const productTitle = import.meta.env.VITE_CC58_NATIVE_DEMO === '1'
	? 'ClientCircuit'
	: 'Vikunja'

export function setTitle(title : undefined | string) {
	document.title = (typeof title === 'undefined' || title === '')
		? productTitle
		: `${title} | ${productTitle}`
}
