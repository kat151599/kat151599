<template>
	<!-- This is a workaround to get the sw to "see" the to-be-cached version of the offline background image -->
	<div
		class="offline"
		style="height: 0;width: 0;"
	/>
	<div
		v-if="!online"
		class="app offline"
	>
		<div class="offline-message">
			<h1 class="title">
				{{ $t('offline.title') }}
			</h1>
			<p>{{ $t('offline.text') }}</p>
		</div>
	</div>
	<template v-else-if="baseStore.ready">
		<slot />
	</template>
	<section v-else-if="baseStore.error !== ''">
		<NoAuthWrapper>
			<p v-if="baseStore.error === ERROR_NO_API_URL">
				{{ $t('ready.noApiUrlConfigured') }}
			</p>
			<Message
				v-else
				variant="danger"
				class="mbe-4"
			>
				<p>
					{{ $t('ready.errorOccured') }}<br>
					{{ baseStore.error }}
				</p>
				<p>
					{{ $t('ready.checkApiUrl') }}
				</p>
			</Message>
			<ApiConfig
				:configure-open="true"
				@foundApi="baseStore.loadApp()"
			/>
		</NoAuthWrapper>
	</section>
	<CustomTransition name="fade">
		<section
			v-if="baseStore.loading"
			class="vikunja-loading"
			:class="{'clientcircuit-loading': isPortfolioDemo}"
		>
			<div
				v-if="isPortfolioDemo"
				class="cc-splash"
				role="status"
				aria-live="polite"
			>
				<div class="cc-splash-emblem">
					<img
						:src="demoBrandUrl"
						alt=""
						width="78"
						height="78"
						decoding="async"
					>
				</div>
				<div class="cc-splash-kicker">INTERACTIVE WORKSPACE</div>
				<h1 class="cc-splash-title">ClientCircuit</h1>
				<p class="cc-splash-description">{{ demoLoadingText }}</p>
				<div class="cc-splash-track" aria-hidden="true">
					<div class="cc-splash-progress" />
				</div>
				<p class="cc-splash-footnote">{{ demoFootnote }}</p>
			</div>
			<template v-else>
				<Logo class="logo" />
				<p>
					<span class="loader-container is-loading-small is-loading" />
					{{ $t('ready.loading') }}
				</p>
			</template>
		</section>
	</CustomTransition>
</template>

<script lang="ts" setup>
import {computed} from 'vue'
import {useI18n} from 'vue-i18n'
import Logo from '@/assets/logo.svg?component'
import ApiConfig from '@/components/misc/ApiConfig.vue'
import Message from '@/components/misc/Message.vue'
import CustomTransition from '@/components/misc/CustomTransition.vue'
import NoAuthWrapper from '@/components/misc/NoAuthWrapper.vue'

import {ERROR_NO_API_URL} from '@/helpers/checkAndSetApiUrl'

import {useOnline} from '@/composables/useOnline'
import {useBaseStore} from '@/stores/base'

const online = useOnline()
const baseStore = useBaseStore()

// Never affect standard Vikunja loading UI outside the isolated portfolio build.
const isPortfolioDemo = import.meta.env.VITE_CC58_NATIVE_DEMO === '1'
const demoBrandUrl = `${import.meta.env.BASE_URL}clientcircuit-brand.svg`
const {locale} = useI18n({useScope: 'global'})
const demoLoadingText = computed(() => {
	const language = String(locale.value).toLowerCase()
	if (language.startsWith('uk')) return 'Готуємо робочий простір…'
	if (language.startsWith('ru')) return 'Подготавливаем рабочее пространство…'
	return 'Preparing your workspace…'
})
const demoFootnote = computed(() => {
	const language = String(locale.value).toLowerCase()
	if (language.startsWith('uk')) return 'Демоверсія · локальні дані'
	if (language.startsWith('ru')) return 'Демоверсия · локальные данные'
	return 'Demo mode · browser-local data'
})
</script>

<style lang="scss" scoped>
// stylelint-disable no-invalid-position-declaration

.vikunja-loading {
	display: flex;
	justify-content: center;
	align-items: center;
	block-size: 100vh;
	inline-size: 100vw;
	flex-direction: column;
	position: fixed;
	inset-block-start: 0;
	inset-inline-start: 0;
	inset-block-end: 0;
	inset-inline-end: 0;
	background: var(--grey-100);
	z-index: 99;
}

// Private demo-only, visually matched to the green/navy portfolio design.
.vikunja-loading.clientcircuit-loading {
	background:
		radial-gradient(ellipse 60% 65% at 15% 16%, rgba(73, 182, 156, .17), transparent 70%),
		radial-gradient(ellipse 65% 70% at 93% 90%, rgba(77, 117, 184, .20), transparent 65%),
		linear-gradient(155deg, #0b2025 0%, #102c30 48%, #0c1b2e 100%);
	color: #eefcf4;
	overflow: hidden;
	isolation: isolate;
}

.clientcircuit-loading::before {
	content: '';
	position: absolute;
	inline-size: min(65vmax, 760px);
	block-size: min(65vmax, 760px);
	border: 1px solid rgba(144, 235, 202, .07);
	border-radius: 50%;
	transform: translate(42vw, -15vh);
	pointer-events: none;
}

.cc-splash {
	position: relative;
	z-index: 1;
	inline-size: min(440px, calc(100vw - 36px));
	box-sizing: border-box;
	padding: clamp(29px, 6vw, 46px) clamp(24px, 5vw, 40px);
	text-align: center;
	border: 1px solid rgba(174, 242, 215, .19);
	border-radius: 26px;
	background: linear-gradient(160deg, rgba(31, 66, 67, .82), rgba(16, 37, 51, .92));
	box-shadow: 0 24px 90px rgba(0, 0, 0, .25), inset 0 1px rgba(255,255,255,.08);
	backdrop-filter: blur(12px);
}

.cc-splash-emblem {
	display: grid;
	place-items: center;
	inline-size: 94px;
	block-size: 94px;
	margin: 0 auto 20px;
	border: 1px solid rgba(146, 232, 198, .21);
	border-radius: 24px;
	background: rgba(6, 25, 35, .55);
	box-shadow: 0 10px 35px rgba(0, 0, 0, .22);
}

.cc-splash-emblem img {
	display: block;
	inline-size: 78px;
	block-size: 78px;
	border-radius: 18px;
}

.cc-splash-kicker {
	font-size: .67rem;
	font-weight: 750;
	letter-spacing: .22em;
	color: #8bdfbb;
}

.cc-splash-title {
	margin: 9px 0 12px;
	color: #f2fff9;
	font-size: clamp(2rem, 5.5vw, 2.65rem);
	font-weight: 780;
	letter-spacing: -.04em;
	line-height: 1.16;
}

.cc-splash-description {
	min-block-size: 1.6em;
	margin: 0 0 27px;
	color: #c0ded4;
	font-size: clamp(.92rem, 2vw, 1rem);
	line-height: 1.6;
}

.cc-splash-track {
	block-size: 5px;
	inline-size: 100%;
	border-radius: 99px;
	background: rgba(197, 238, 222, .12);
	overflow: hidden;
}

.cc-splash-progress {
	inline-size: 40%;
	block-size: 100%;
	border-radius: inherit;
	background: linear-gradient(90deg, #64ddc4, #a3f5bf);
	box-shadow: 0 0 18px rgba(114, 229, 190, .35);
	animation: cc-progress 1.55s ease-in-out infinite alternate;
}

.cc-splash-footnote {
	margin: 16px 0 0;
	color: #89b3a9;
	font-size: .74rem;
	letter-spacing: .02em;
}

@keyframes cc-progress {
	from { transform: translateX(-25%); }
	to { transform: translateX(175%); }
}

@media (prefers-reduced-motion: reduce) {
	.cc-splash-progress { animation: none; inline-size: 100%; opacity: .6; }
}

.logo {
	margin-block-end: 1rem;
	inline-size: 100px;
	block-size: 100px;
}

.loader-container {
	margin-inline-end: 1rem;

	&.is-loading::after {
		border-inline-start-color: var(--grey-400);
		border-block-end-color: var(--grey-400);
	}
}

.offline {
	background: url('@/assets/llama-nightscape.jpg') no-repeat center;
	background-size: cover;
	block-size: 100vh;
}

.offline-message {
	text-align: center;
	position: absolute;
	inline-size: 100vw;
	inset-block-end: 5vh;
	color: $white;
	padding: 0 1rem;
}

.title {
	text-align: center;
	color: $white;
	font-weight: 700 !important;
	font-size: 1.5rem;
}
</style>
