<template>
	<section
		class="sticky-notes"
		:class="{'is-embedded': props.embedded}"
	>
		<header
			v-if="!props.embedded"
			class="sticky-notes__header"
		>
			<div>
				<span class="sticky-notes__eyebrow">
					Заметки
				</span>

				<h2>
					Быстрые заметки
				</h2>
			</div>

			<button
				class="sticky-notes__new"
				type="button"
				@click="createNote"
			>
				+ Новая заметка
			</button>
		</header>

		<div v-if="props.embedded" class="sticky-notes__compact-actions">
			<button class="sticky-notes__new" type="button" @click="createNote">
				+ Новая заметка
			</button>
		</div>

		<div
			v-if="store.isLoading"
			class="sticky-notes__state"
		>
			Загрузка…
		</div>

		<div
			v-else
			class="sticky-notes__carousel"
		>
			<button
				v-if="canScrollLeft"
				type="button"
				class="sticky-notes__arrow sticky-notes__arrow--left"
				aria-label="Прокрутить заметки влево"
				@click="scrollByCard(-1)"
			>
				‹
			</button>

			<div
				ref="viewport"
				class="sticky-notes__viewport"
				@scroll="updateOverflow"
			>
				<div
					ref="track"
					class="sticky-notes__track"
				>
					<article
						v-for="note in store.notes"
						:key="note.id"
						class="sticky-note"
					>
						<button
							class="sticky-note__delete"
							type="button"
							aria-label="Удалить заметку"
							title="Удалить"
							@click="deleteNote(note.id)"
						>
							×
						</button>

						<input
							v-model="note.title"
							class="sticky-note__title"
							maxlength="500"
							placeholder="Заголовок"
							@input="queueSave(note)"
							@blur="saveNow(note)"
						>

						<textarea
							v-model="note.content"
							class="sticky-note__content"
							rows="7"
							placeholder="Нажмите и напишите…"
							@input="queueSave(note)"
							@blur="saveNow(note)"
						/>
					</article>
				</div>
			</div>

			<button
				v-if="canScrollRight"
				type="button"
				class="sticky-notes__arrow sticky-notes__arrow--right"
				aria-label="Прокрутить заметки вправо"
				@click="scrollByCard(1)"
			>
				›
			</button>
		</div>
	</section>
</template>

<script setup lang="ts">
import {nextTick, onBeforeUnmount, onMounted, ref, watch} from 'vue'
import {usePrivateNotesStore, type IPrivateNote} from '@/stores/privateNotes'

const props = withDefaults(defineProps<{
	embedded?: boolean
}>(), {
	embedded: false,
})
const store = usePrivateNotesStore()
const saveTimers = new Map<number, number>()
const viewport = ref<HTMLElement | null>(null)
const track = ref<HTMLElement | null>(null)
const canScrollLeft = ref(false)
const canScrollRight = ref(false)
let resizeObserver: ResizeObserver | null = null

function clearSaveTimer(id: number) {
	const timer = saveTimers.get(id)
	if (timer !== undefined) {
		window.clearTimeout(timer)
		saveTimers.delete(id)
	}
}

function queueSave(note: IPrivateNote) {
	clearSaveTimer(note.id)
	saveTimers.set(note.id, window.setTimeout(() => void saveNow(note), 650))
}

async function saveNow(note: IPrivateNote) {
	clearSaveTimer(note.id)
	try {
		await store.update(note)
	} catch (error) {
		console.error('Could not autosave private note', error)
	}
}

async function createNote() {
	try {
		await store.create('', '')
		await nextTick()
		updateOverflow()
	} catch (error) {
		console.error('Could not create private note', error)
	}
}

async function deleteNote(id: number) {
	clearSaveTimer(id)
	try {
		await store.remove(id)
		await nextTick()
		updateOverflow()
	} catch (error) {
		console.error('Could not delete private note', error)
	}
}

function updateOverflow() {
	const element = viewport.value
	if (!element) {
		canScrollLeft.value = false
		canScrollRight.value = false
		return
	}

	canScrollLeft.value = element.scrollLeft > 2
	canScrollRight.value = element.scrollLeft + element.clientWidth < element.scrollWidth - 2
}

function cardStep() {
	const card = track.value?.querySelector<HTMLElement>('.sticky-note')
	if (!card || !track.value) return 296

	const styles = window.getComputedStyle(track.value)
	const gap = Number.parseFloat(styles.columnGap || styles.gap || '16') || 16
	return card.offsetWidth + gap
}

function scrollByCard(direction: -1 | 1) {
	viewport.value?.scrollBy({
		left: direction * cardStep(),
		behavior: 'smooth',
	})
	window.setTimeout(updateOverflow, 280)
}

watch(() => store.notes.length, async () => {
	await nextTick()
	updateOverflow()
})

onMounted(async () => {
	await store.load()
	await nextTick()

	resizeObserver = new ResizeObserver(updateOverflow)
	if (viewport.value) resizeObserver.observe(viewport.value)
	if (track.value) resizeObserver.observe(track.value)
	updateOverflow()
})

onBeforeUnmount(() => {
	resizeObserver?.disconnect()
	for (const note of store.notes) {
		if (saveTimers.has(note.id)) void saveNow(note)
	}
})
</script>

<style scoped lang="scss">
.sticky-notes {
	display: grid;
	gap: .75rem;
	min-inline-size: 0;
	padding: 1rem;
	border: 1px solid var(--gtt-border);
	border-radius: var(--gtt-radius-lg);
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
}

.sticky-notes.is-embedded {
	padding: 0;
	border: 0;
	border-radius: 0;
	background: transparent;
	box-shadow: none;
}

.sticky-notes__compact-actions {
	display: flex;
	justify-content: flex-end;
}

.sticky-notes__header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 1rem;

	h2 {
		margin: 0;
		color: var(--gtt-text);
		font-size: .95rem;
		font-weight: 730;
	}
}

.sticky-notes__eyebrow {
	display: block;
	margin-block-end: .15rem;
	color: var(--gtt-text-faint);
	font-size: .65rem;
	font-weight: 720;
	letter-spacing: .07em;
	text-transform: uppercase;
}

.sticky-notes__new {
	min-block-size: 38px;
	padding: .45rem .7rem;
	border: 1px solid var(--gtt-border);
	border-radius: 9px;
	background: var(--gtt-panel-soft);
	color: var(--gtt-green-800);
	font-size: .76rem;
	font-weight: 700;
	cursor: pointer;

	&:hover {
		border-color: var(--gtt-border-strong);
		background: var(--gtt-green-100);
	}
}

.sticky-notes__carousel {
	position: relative;
	min-inline-size: 0;
}

.sticky-notes__viewport {
	inline-size: 100%;
	overflow-x: hidden;
	scroll-behavior: smooth;
}

.sticky-notes__track {
	display: flex;
	align-items: stretch;
	flex-wrap: nowrap;
	gap: .8rem;
	inline-size: max-content;
	min-inline-size: 100%;
	padding: .15rem 2.55rem .35rem;
}

.sticky-note {
	position: relative;
	flex: 0 0 280px;
	inline-size: 280px;
	min-block-size: 185px;
	padding: .9rem;
	border: 1px solid var(--gtt-border);
	border-radius: 13px;
	background:
		linear-gradient(
			145deg,
			var(--gtt-lime-soft),
			var(--gtt-panel) 72%
		);
	box-shadow: var(--gtt-shadow-xs);
}

.sticky-note:nth-child(2n) {
	background: var(--gtt-panel-soft);
}

.sticky-note__delete {
	position: absolute;
	inset-block-start: .35rem;
	inset-inline-end: .45rem;
	z-index: 2;
	padding: .2rem;
	border: 0;
	background: transparent;
	color: var(--gtt-text-faint);
	font-size: 1.2rem;
	line-height: 1;
	cursor: pointer;
	opacity: .7;

	&:hover {
		color: var(--gtt-red);
		opacity: 1;
	}
}

.sticky-note__title,
.sticky-note__content {
	inline-size: 100%;
	border: 0;
	outline: 0;
	background: transparent;
	color: var(--gtt-text);
	font: inherit;
}

.sticky-note__title {
	padding: 0 1.6rem .45rem 0;
	font-size: .9rem;
	font-weight: 750;
}

.sticky-note__content {
	min-block-size: 125px;
	color: var(--gtt-text-soft);
	line-height: 1.5;
	resize: none;
}

.sticky-note__title::placeholder,
.sticky-note__content::placeholder {
	color: var(--gtt-text-faint);
}

.sticky-notes__state {
	padding: 1rem;
	color: var(--gtt-text-soft);
}

.sticky-notes__arrow {
	position: absolute;
	inset-block-start: 50%;
	z-index: 4;
	display: grid;
	place-items: center;
	inline-size: 2rem;
	block-size: 3rem;
	padding: 0;
	transform: translateY(-50%);
	border: 1px solid var(--gtt-border);
	border-radius: 10px;
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
	color: var(--gtt-text);
	font-size: 1.55rem;
	line-height: 1;
	cursor: pointer;
}

.sticky-notes__arrow--left {
	inset-inline-start: .15rem;
}

.sticky-notes__arrow--right {
	inset-inline-end: .15rem;
}

@media screen and (max-width: $tablet) {
	.sticky-notes__header {
		align-items: flex-start;
		flex-direction: column;
	}

	.sticky-notes__track {
		padding-inline: 2.25rem;
	}

	.sticky-note {
		flex-basis: 240px;
		inline-size: 240px;
	}
}
</style>
