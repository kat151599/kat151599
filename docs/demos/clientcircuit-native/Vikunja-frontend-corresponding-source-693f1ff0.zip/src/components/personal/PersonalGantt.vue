<template>
	<section
		class="personal-gantt"
		:class="{'is-embedded': props.embedded}"
	>
		<header
			v-if="!props.embedded"
			class="personal-gantt__header"
		>
			<div>
				<span class="personal-gantt__eyebrow">
					Сроки
				</span>

				<h2>
					План по времени
				</h2>

				<p>
					Задачи с датами начала, окончания и дедлайнами.
				</p>
			</div>
		</header>


		<div
			v-if="!hasDatedTasks && !store.isLoading"
			class="personal-gantt__empty"
		>
			Здесь появятся задачи, у которых задана дата начала, окончания или срок.
		</div>

		<div
			v-else
			class="personal-gantt__chart"
		>
			<GanttChart
				:filters="filters"
				:tasks="taskMap"
				:is-loading="store.isLoading"
				:default-task-start-date="defaultTaskStartDate"
				:default-task-end-date="defaultTaskEndDate"
				@update:task="updateTaskDates"
			/>
		</div>
	</section>
</template>

<script setup lang="ts">
import {computed, reactive} from 'vue'

import GanttChart from '@/components/gantt/GanttChart.vue'
import {useMyTasksStore} from '@/stores/myTasks'

import type {GanttFilters} from '@/views/project/helpers/useGanttFilters'
import type {ITaskPartialWithId} from '@/modelTypes/ITask'
import type {DateISO} from '@/types/DateISO'

const props = withDefaults(defineProps<{
	embedded?: boolean
}>(), {
	embedded: false,
})
const store = useMyTasksStore()

const today = new Date()
const dateFrom = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 15)
const dateTo = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 55)
const defaultEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7)

const filters = reactive<GanttFilters>({
	projectId: 0,
	viewId: 0,
	dateFrom: dateFrom.toISOString(),
	dateTo: dateTo.toISOString(),
	showTasksWithoutDates: false,
})

const defaultTaskStartDate: DateISO = new Date(
	today.getFullYear(),
	today.getMonth(),
	today.getDate(),
).toISOString()

const defaultTaskEndDate: DateISO = defaultEnd.toISOString()

const taskMap = computed(() => new Map(store.tasks.map(task => [task.id, task])))
const hasDatedTasks = computed(() => store.tasks.some(task => task.startDate || task.endDate || task.dueDate))

async function updateTaskDates(patch: ITaskPartialWithId) {
	const task = store.tasks.find(item => item.id === patch.id)
	if (!task) return

	try {
		await store.updateTask(task, patch)
	} catch (error) {
		console.error('Could not update task dates from personal gantt', error)
		await store.load()
	}
}
</script>

<style scoped lang="scss">
.personal-gantt {
	display: grid;
	gap: .75rem;
	padding: 1rem;
	border: 1px solid var(--gtt-border);
	border-radius: var(--gtt-radius-lg);
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
}

.personal-gantt.is-embedded {
	padding: 0;
	border: 0;
	border-radius: 0;
	background: transparent;
	box-shadow: none;
}

.personal-gantt__header {
	h2 {
		margin: 0;
		color: var(--gtt-text);
		font-size: .95rem;
		font-weight: 730;
	}

	p {
		margin: .2rem 0 0;
		color: var(--gtt-text-soft);
		font-size: .76rem;
	}
}

.personal-gantt__eyebrow {
	display: block;
	margin-block-end: .15rem;
	color: var(--gtt-text-faint);
	font-size: .65rem;
	font-weight: 720;
	letter-spacing: .07em;
	text-transform: uppercase;
}

.personal-gantt__chart {
	overflow-x: auto;
	padding: .35rem;
	border: 1px solid var(--gtt-border);
	border-radius: 12px;
	background: var(--gtt-canvas-soft);
}

.personal-gantt__empty {
	padding: 1.4rem;
	border: 1px dashed var(--gtt-border-strong);
	border-radius: 12px;
	background: var(--gtt-panel-soft);
	color: var(--gtt-text-soft);
	font-size: .8rem;
	text-align: center;
}
</style>
