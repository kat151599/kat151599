<template>
	<section
		v-if="projectId > 0 && !loading && (tasks.length > 0 || loadFailed)"
		class="project-progress d-print-none"
		aria-label="Ход проекта"
	>
		<div class="project-progress__header">
			<div>
				<strong>Ход проекта</strong>
				<span v-if="tasks.length">
					{{ summary.done }} из {{ summary.total }} задач выполнено · {{ summary.percent }}%
				</span>
			</div>
			<span
				v-if="loadFailed"
				class="project-progress__error"
			>
				Не удалось загрузить прогресс
			</span>
		</div>

		<div
			v-if="tasks.length"
			class="project-progress__viewport"
		>
			<div
				class="project-progress__track"
				:class="{'project-progress__track--single': tasks.length === 1}"
				:style="{minWidth: trackMinWidth}"
			>
				<span
					class="project-progress__line"
					aria-hidden="true"
				/>

				<RouterLink
					v-for="task in orderedTasks"
					:key="task.id"
					v-tooltip="tooltipText(task)"
					class="project-progress__point-link"
					:to="{name: 'task.detail', params: {id: task.id}}"
					:aria-label="pointAriaLabel(task)"
				>
					<span
						class="project-progress__point"
						:class="task.done
							? 'project-progress__point--done'
							: 'project-progress__point--pending'"
						aria-hidden="true"
					/>
				</RouterLink>
			</div>
		</div>
	</section>
</template>

<script setup lang="ts">
import {computed, ref, watch} from 'vue'

import TaskCollectionService from '@/services/taskCollection'
import {
	sortProjectProgressTasks,
	summarizeProjectProgress,
} from '@/helpers/projectProgress'
import {formatDate} from '@/helpers/time/formatDate'

import type {ITask} from '@/modelTypes/ITask'

const props = defineProps<{
	projectId: number
}>()

const tasks = ref<ITask[]>([])
const loading = ref(false)
const loadFailed = ref(false)

let loadGeneration = 0

const orderedTasks = computed(() =>
	sortProjectProgressTasks(tasks.value),
)

const summary = computed(() =>
	summarizeProjectProgress(tasks.value),
)

const trackMinWidth = computed(() =>
	`${Math.max(100, orderedTasks.value.length * 30)}px`,
)

function taskDateLabel(task: ITask): string {
	if (task.done) {
		if (task.doneAt) {
			return `Выполнено: ${formatDate(task.doneAt, 'D MMMM YYYY')}`
		}

		return 'Выполнено'
	}

	const deadline = task.dueDate ?? task.endDate
	if (deadline) {
		return `Срок: до ${formatDate(deadline, 'D MMMM YYYY')}`
	}

	return 'Срок не задан'
}

function tooltipText(task: ITask): string {
	return `${task.title} · ${taskDateLabel(task)}`
}

function pointAriaLabel(task: ITask): string {
	return `${task.title}. ${taskDateLabel(task)}`
}

async function loadTasks() {
	const generation = ++loadGeneration

	if (props.projectId <= 0) {
		tasks.value = []
		loadFailed.value = false
		loading.value = false
		return
	}

	loading.value = true
	loadFailed.value = false

	try {
		const service = new TaskCollectionService()
		const loaded: ITask[] = []

		let page = 1
		let totalPages = 1

		do {
			const pageTasks = await service.getAll(
				{projectId: props.projectId} as ITask,
				{
					sort_by: ['id'],
					order_by: ['asc'],
					filter: '',
					filter_include_nulls: false,
					s: '',
					per_page: 50,
				},
				page,
			)

			loaded.push(...pageTasks)
			totalPages = Math.max(service.totalPages || 1, 1)
			page += 1
		} while (page <= totalPages)

		if (generation === loadGeneration) {
			tasks.value = loaded
		}
	} catch {
		if (generation === loadGeneration) {
			tasks.value = []
			loadFailed.value = true
		}
	} finally {
		if (generation === loadGeneration) {
			loading.value = false
		}
	}
}

watch(
	() => props.projectId,
	() => {
		void loadTasks()
	},
	{immediate: true},
)

defineExpose({
	reload: loadTasks,
})
</script>

<style scoped>
.project-progress {
	margin-block-end: 1rem;
	padding: .8rem 1rem .9rem;
	border: 1px solid var(--brand-border);
	border-radius: 12px;
	background: var(--white);
	box-shadow: 0 3px 12px rgba(31, 91, 73, .04);
}

.project-progress__header {
	display: flex;
	align-items: baseline;
	justify-content: space-between;
	gap: .75rem;
	margin-block-end: .65rem;
}

.project-progress__header > div {
	display: flex;
	align-items: baseline;
	gap: .55rem;
	min-width: 0;
}

.project-progress__header strong {
	font-size: .85rem;
	color: var(--text-strong);
}

.project-progress__header span {
	font-size: .76rem;
	color: var(--brand-text-muted);
}

.project-progress__error {
	color: var(--danger) !important;
}

.project-progress__viewport {
	overflow-x: auto;
	overflow-y: hidden;
	padding-block: .25rem .35rem;
	scrollbar-width: thin;
}

.project-progress__track {
	position: relative;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
	block-size: 24px;
	padding-inline: 3px;
}

.project-progress__track--single {
	justify-content: flex-start;
}

.project-progress__line {
	position: absolute;
	z-index: 0;
	inset-inline: 11px;
	inset-block-start: 50%;
	block-size: 2px;
	transform: translateY(-50%);
	background: var(--grey-300);
}

.project-progress__track--single .project-progress__line {
	display: none;
}

.project-progress__point-link {
	position: relative;
	z-index: 1;
	display: inline-flex;
	align-items: center;
	justify-content: center;
	inline-size: 22px;
	block-size: 22px;
	flex: 0 0 22px;
	border-radius: 50%;
}

.project-progress__point {
	display: block;
	inline-size: 14px;
	block-size: 14px;
	border: 3px solid var(--white);
	border-radius: 50%;
	box-shadow: 0 0 0 1px rgba(0, 0, 0, .12);
	transition: transform 120ms ease, box-shadow 120ms ease;
}

.project-progress__point--done {
	background: var(--success);
}

.project-progress__point--pending {
	background: var(--danger);
}

.project-progress__point-link:hover .project-progress__point,
.project-progress__point-link:focus-visible .project-progress__point {
	transform: scale(1.28);
	box-shadow: 0 0 0 2px var(--white), 0 0 0 4px var(--brand-forest);
}

@media screen and (max-width: 768px) {
	.project-progress {
		padding-inline: .75rem;
	}

	.project-progress__header {
		align-items: flex-start;
		flex-direction: column;
		gap: .2rem;
	}

	.project-progress__header > div {
		align-items: flex-start;
		flex-direction: column;
		gap: .1rem;
	}
}
</style>
