<template>
	<ul
		class="project-grid"
		:class="{ 'show-even-number-of-projects': showEvenNumberOfProjects }"
	>
		<li
			v-for="folder in folders"
			:key="`folder_${folder.id}`"
			class="project-grid-item folder-grid-item"
			:class="{'is-drag-over': dragOverFolderId === folder.id}"
			@dragover.prevent="handleFolderDragOver(folder.id)"
			@dragleave="handleFolderDragLeave($event, folder.id)"
			@drop.prevent="handleFolderDrop($event, folder.id)"
		>
			<ProjectFolderCard
				:folder="folder"
				:can-manage="canManageFolders"
				:is-drop-target="dragOverFolderId === folder.id"
				@open="emit('openFolder', $event)"
				@rename="emit('renameFolder', $event)"
				@delete="emit('deleteFolder', $event)"
			/>
		</li>

		<li
			v-for="(item, index) in filteredProjects"
			:key="`project_${item.id}_${index}`"
			class="project-grid-item"
			:class="{
				'is-selection-mode': selectionMode,
				'is-selected': selectionMode && isSelected(item.id),
				'is-not-selectable': selectionMode && !isSelectable(item.id),
				'is-project-draggable': !selectionMode && isProjectDraggable(item.id),
			}"
			:draggable="!selectionMode && isProjectDraggable(item.id)"
			@dragstart="handleProjectDragStart($event, item)"
			@dragend="handleProjectDragEnd"
		>
			<button
				v-if="selectionMode"
				type="button"
				class="project-selection-overlay"
				:disabled="!isSelectable(item.id)"
				:aria-pressed="isSelected(item.id)"
				:aria-label="isSelected(item.id) ? `Снять выбор: ${item.title}` : `Выбрать: ${item.title}`"
				@click="emit('toggleSelection', item.id)"
			>
				<span
					v-if="isSelectable(item.id)"
					class="project-selection-checkbox"
					:class="{'is-selected': isSelected(item.id)}"
				>
					<Icon
						v-if="isSelected(item.id)"
						icon="check"
					/>
				</span>
			</button>

			<ProjectCard
				:project="item"
				:due-date="props.dueDates?.[item.id] ?? null"
			/>
			<div
				v-if="item.id > 0 && !selectionMode"
				class="project-card-actions"
				draggable="false"
				@pointerdown.stop
				@mousedown.stop
				@click.stop
				@dragstart.stop.prevent
			>
				<ProjectSettingsDropdown
					:project="item"
					compact-card-actions
				/>
			</div>
		</li>
	</ul>
</template>

<script lang="ts" setup>
import {computed, ref} from 'vue'
import type {IProject} from '@/modelTypes/IProject'
import type {IProjectFolder} from '@/modelTypes/IProjectFolder'

import ProjectCard from './ProjectCard.vue'
import ProjectSettingsDropdown from '@/components/project/ProjectSettingsDropdown.vue'
import ProjectFolderCard from './ProjectFolderCard.vue'

const props = withDefaults(defineProps<{
projects: readonly IProject[],
folders?: readonly IProjectFolder[],
showArchived?: boolean,
itemLimit?: boolean,
showEvenNumberOfProjects?: boolean,
dueDates?: Record<number, string>,
selectionMode?: boolean,
selectedProjectIds?: number[],
selectableProjectIds?: number[],
draggableProjectIds?: number[],
canManageFolders?: boolean,
}>(), {
	folders: () => [],
	showArchived: false,
	itemLimit: false,
	showEvenNumberOfProjects: false,
	dueDates: () => ({}),
	selectionMode: false,
	selectedProjectIds: () => [],
	selectableProjectIds: () => [],
	draggableProjectIds: () => [],
	canManageFolders: false,
})

const emit = defineEmits<{
'toggleSelection': [projectId: number],
'openFolder': [folderId: number],
'renameFolder': [folder: IProjectFolder],
'deleteFolder': [folder: IProjectFolder],
'moveProject': [projectId: number, folderId: number],
}>()

const draggedProjectId = ref<number | null>(null)
const dragOverFolderId = ref<number | null>(null)

let projectDragPreview: HTMLElement | null = null
const filteredProjects = computed(() => {
	return props.showArchived
		? props.projects
		: props.projects.filter(project => !project.isArchived)
})

function isSelected(projectId: number): boolean {
	return props.selectedProjectIds.includes(projectId)
}

function isSelectable(projectId: number): boolean {
	return props.selectableProjectIds.includes(projectId)
}

function isProjectDraggable(projectId: number): boolean {
	return props.draggableProjectIds.includes(projectId)
}

function removeProjectDragPreview() {
	projectDragPreview?.remove()
	projectDragPreview = null
}

function handleProjectDragStart(event: DragEvent, project: IProject) {
	if (!isProjectDraggable(project.id) || !event.dataTransfer) {
		event.preventDefault()
		return
	}

	removeProjectDragPreview()

	draggedProjectId.value = project.id
	event.dataTransfer.effectAllowed = 'move'

	event.dataTransfer.setData(
		'application/x-vikunja-project-id',
		String(project.id),
	)

	event.dataTransfer.setData(
		'text/plain',
		String(project.id),
	)

	const preview = document.createElement('div')
	preview.textContent = `\u25C6 ${project.title}`

	Object.assign(preview.style, {
		position: 'fixed',
		insetInlineStart: '-10000px',
		insetBlockStart: '-10000px',
		maxWidth: '280px',
		padding: '8px 12px',
		borderRadius: '10px',
		background: 'rgba(25, 29, 35, 0.94)',
		color: '#fff',
		fontSize: '14px',
		fontWeight: '600',
		lineHeight: '1.2',
		whiteSpace: 'nowrap',
		overflow: 'hidden',
		textOverflow: 'ellipsis',
		boxShadow: '0 8px 24px rgba(0, 0, 0, 0.18)',
		pointerEvents: 'none',
		zIndex: '2147483647',
	})

	document.body.appendChild(preview)
	projectDragPreview = preview

	event.dataTransfer.setDragImage(preview, 16, 16)
}

function handleProjectDragEnd() {
	draggedProjectId.value = null
	dragOverFolderId.value = null
	removeProjectDragPreview()
}
function handleFolderDragOver(folderId: number) {
	if (draggedProjectId.value === null) {
		return
	}

	dragOverFolderId.value = folderId
}

function handleFolderDragLeave(event: DragEvent, folderId: number) {
	const current = event.currentTarget as HTMLElement | null
	const related = event.relatedTarget as Node | null

	if (current && related && current.contains(related)) {
		return
	}

	if (dragOverFolderId.value === folderId) {
		dragOverFolderId.value = null
	}
}

function getDroppedProjectId(event: DragEvent): number | null {
	const raw =
event.dataTransfer?.getData('application/x-vikunja-project-id') ||
event.dataTransfer?.getData('text/plain') ||
''

	const projectId = Number(raw)

	if (!Number.isInteger(projectId) || !isProjectDraggable(projectId)) {
		return null
	}

	return projectId
}

function handleFolderDrop(event: DragEvent, folderId: number) {
	const projectId = getDroppedProjectId(event)

	draggedProjectId.value = null
	dragOverFolderId.value = null

	if (projectId === null) {
		return
	}

	emit('moveProject', projectId, folderId)
}
</script>

<style lang="scss" scoped>
.project-grid {
	--project-grid-item-height: 178px;
	--project-grid-gap: .9rem;
	display: grid;
	grid-template-columns: repeat(var(--project-grid-columns), minmax(0, 1fr));
	grid-auto-rows: var(--project-grid-item-height);
	gap: var(--project-grid-gap);
	margin: 0;
	padding: 0;
	list-style-type: none;

	@media screen and (min-width: $mobile) {
		--project-grid-columns: 1;
	}

	@media screen and (min-width: $mobile) and (max-width: $tablet) {
		--project-grid-columns: 2;
	}

	@media screen and (min-width: $tablet) and (max-width: $widescreen) {
		--project-grid-columns: 3;
	}

	@media screen and (min-width: $widescreen) {
		--project-grid-columns: 4;
	}

	&.show-even-number-of-projects {
		@media screen and (min-width: $widescreen) {
			.project-grid-item:nth-child(5) {
				display: none;
			}
		}
	}
}

.project-grid-item {
	position: relative;
	display: grid;
	margin-block-start: 0;
	border-radius: var(--gtt-radius-lg);

	&.is-selection-mode {
		:deep(.complete-toggle),
		:deep(.favorite) {
			opacity: 0 !important;
			pointer-events: none;
		}
	}

	&.is-not-selectable {
		opacity: .65;
	}

	&.is-project-draggable {
		cursor: grab;

		&:active {
			cursor: grabbing;
		}
	}
}

.project-grid-item:not(.folder-grid-item) {
	align-self: stretch;
	block-size: 100%;
	transition:
		transform 140ms ease,
		box-shadow 140ms ease;

	&:hover {
		transform: translateY(-3px);
	}

	&.is-project-draggable:active {
		transform: scale(.99);
	}
}

.project-grid-item :deep(.complete-toggle) {
	display: none;
}

.project-card-actions {
	position: absolute;
	inset-block-start: .65rem;
	inset-inline-start: .65rem;
	z-index: 12;

	:deep(.dropdown-trigger) {
		display: flex;
		align-items: center;
		justify-content: center;
		inline-size: 2rem;
		block-size: 2rem;
		padding: 0;
		border: 1px solid color-mix(
			in srgb,
			var(--gtt-border) 65%,
			transparent
		);
		border-radius: 9px;
		background: color-mix(
			in srgb,
			var(--gtt-panel) 90%,
			transparent
		);
		box-shadow: var(--gtt-shadow-xs);

		&:hover {
			background: var(--gtt-panel);
		}
	}

	:deep(.dropdown-menu) {
		min-inline-size: 14rem;
	}
}

.folder-grid-item {
	transition:
		transform 140ms ease,
		box-shadow 140ms ease;

	&.is-drag-over {
		transform: translateY(-2px);
	}
}

.project-selection-overlay {
	position: absolute;
	inset: 0;
	z-index: 10;
	padding: 0;
	border: 3px solid transparent;
	border-radius: var(--gtt-radius-lg);
	background: transparent;
	cursor: pointer;
	appearance: none;
	transition:
		border-color 120ms ease,
		box-shadow 120ms ease;

	&:hover:not(:disabled) {
		border-color: color-mix(
			in srgb,
			var(--gtt-green-700) 45%,
			transparent
		);
	}

	&:focus-visible {
		outline: none;
		box-shadow: var(--focus-ring);
	}

	&:disabled {
		cursor: not-allowed;
	}
}

.project-grid-item.is-selected .project-selection-overlay {
	border-color: var(--gtt-green-700);
	box-shadow:
		0 0 0 2px
		color-mix(
			in srgb,
			var(--gtt-green-700) 18%,
			transparent
		);
}

.project-selection-checkbox {
	position: absolute;
	inset-block-start: .65rem;
	inset-inline-start: .65rem;
	display: flex;
	align-items: center;
	justify-content: center;
	inline-size: 1.8rem;
	block-size: 1.8rem;
	border: 2px solid var(--gtt-border-strong);
	border-radius: 7px;
	background: var(--gtt-panel);
	color: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
	font-size: .85rem;

	&.is-selected {
		border-color: var(--gtt-green-700);
		background: var(--gtt-green-700);
	}
}
</style>
