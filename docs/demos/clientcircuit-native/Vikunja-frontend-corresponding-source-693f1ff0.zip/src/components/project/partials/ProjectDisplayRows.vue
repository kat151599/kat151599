<template>
    <div
        class="project-rows"
        :class="{'is-table': mode === 'table', 'is-list': mode === 'list'}"
        :role="mode === 'table' ? 'table' : 'list'"
        aria-label="Проекты и папки"
    >
        <div v-if="mode === 'table'" class="project-rows-heading" role="row">
            <span role="columnheader">Название</span>
            <span role="columnheader">Состояние</span>
            <span role="columnheader">Ближайший срок</span>
            <span role="columnheader">Изменён</span>
            <span role="columnheader" class="actions-title">Действия</span>
        </div>

        <div
            v-for="folder in folders"
            :key="'folder-' + folder.id"
            class="project-row is-folder"
            :class="{'is-drop-target': dropFolderId === folder.id}"
            :role="mode === 'table' ? 'row' : 'listitem'"
            @dragover.prevent="onFolderDragOver($event, folder.id)"
            @dragleave="onFolderDragLeave($event, folder.id)"
            @drop.prevent="onFolderDrop($event, folder.id)"
        >
            <div class="project-row-title" :role="mode === 'table' ? 'cell' : undefined">
                <span class="project-row-icon is-folder-icon"><Icon icon="folder" /></span>
                <button type="button" class="project-row-folder-button" @click="emit('openFolder', folder.id)">
                    {{ folder.title }}
                </button>
            </div>
            <span v-if="mode === 'table'" class="project-row-muted" role="cell">Папка</span>
            <span v-if="mode === 'table'" class="project-row-muted" role="cell">—</span>
            <span v-if="mode === 'table'" class="project-row-muted" role="cell">—</span>
            <div class="project-row-actions" :role="mode === 'table' ? 'cell' : undefined">
                <Dropdown v-if="canManageFolders">
                    <template #trigger="triggerProps">
                        <BaseButton
                            class="project-row-menu"
                            :aria-label="'Действия с папкой: ' + folder.title"
                            :aria-expanded="triggerProps.open"
                            @click.stop="triggerProps.toggleOpen"
                        ><Icon icon="ellipsis-h" /></BaseButton>
                    </template>
                    <DropdownItem icon="pen" @click="emit('renameFolder', folder)">Переименовать</DropdownItem>
                    <DropdownItem icon="trash-alt" class="has-text-danger" @click="emit('deleteFolder', folder)">Удалить</DropdownItem>
                </Dropdown>
            </div>
        </div>

        <div
            v-for="project in filteredProjects"
            :key="'project-' + project.id"
            class="project-row is-project"
            :class="{'is-selected': selectionMode && isSelected(project.id)}"
            :role="mode === 'table' ? 'row' : 'listitem'"
            :draggable="!selectionMode && isDraggable(project.id)"
            @dragstart="onProjectDragStart($event, project.id)"
            @dragend="onProjectDragEnd"
        >
            <div class="project-row-title" :role="mode === 'table' ? 'cell' : undefined">
                <button
                    v-if="selectionMode"
                    type="button"
                    class="project-row-select"
                    :disabled="!isSelectable(project.id)"
                    :aria-pressed="isSelected(project.id)"
                    :aria-label="isSelected(project.id) ? 'Снять выбор: ' + project.title : 'Выбрать: ' + project.title"
                    @click="emit('toggleSelection', project.id)"
                >
                    <Icon v-if="isSelected(project.id)" icon="check" />
                </button>
                <span v-else class="project-row-icon is-project-icon" :style="{'--project-accent': project.hexColor || 'var(--gtt-green-700)'}">
                    <Icon icon="tasks" />
                </span>
                <div class="project-row-name-group">
                    <span v-if="selectionMode" class="project-row-name">{{ getProjectTitle(project) }}</span>
                    <RouterLink
                        v-else
                        :to="{name: 'project.index', params: {projectId: project.id}}"
                        class="project-row-name"
                    >{{ getProjectTitle(project) }}</RouterLink>
                    <span v-if="mode === 'list'" class="project-row-subtitle">
                        {{ status(project) }}<span v-if="dueDates[project.id]"> · Срок {{ dateText(dueDates[project.id]) }}</span>
                    </span>
                </div>
            </div>
            <span v-if="mode === 'table'" class="project-row-status" role="cell">
                <span class="project-state" :class="{'is-complete': project.isCompleted, 'is-archived': project.isArchived}">
                    {{ status(project) }}
                </span>
            </span>
            <span v-if="mode === 'table'" class="project-row-muted" role="cell">
                {{ dueDates[project.id] ? dateText(dueDates[project.id]) : '—' }}
            </span>
            <span v-if="mode === 'table'" class="project-row-muted" role="cell">
                {{ project.updated ? dateText(project.updated) : '—' }}
            </span>
            <div class="project-row-actions" :role="mode === 'table' ? 'cell' : undefined">
                <ProjectSettingsDropdown
                    v-if="project.id > 0 && !selectionMode"
                    :project="project"
                    compact-card-actions
                />
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import {computed, ref} from 'vue'
import {RouterLink} from 'vue-router'
import type {IProject} from '@/modelTypes/IProject'
import type {IProjectFolder} from '@/modelTypes/IProjectFolder'
import {getProjectTitle} from '@/helpers/getProjectTitle'
import BaseButton from '@/components/base/BaseButton.vue'
import Dropdown from '@/components/misc/Dropdown.vue'
import DropdownItem from '@/components/misc/DropdownItem.vue'
import ProjectSettingsDropdown from '@/components/project/ProjectSettingsDropdown.vue'

const props = withDefaults(defineProps<{
    mode: 'list' | 'table',
    projects: readonly IProject[],
    folders?: readonly IProjectFolder[],
    showArchived?: boolean,
    dueDates?: Record<number, string>,
    selectionMode?: boolean,
    selectedProjectIds?: number[],
    selectableProjectIds?: number[],
    draggableProjectIds?: number[],
    canManageFolders?: boolean,
}>(), {
    folders: () => [],
    showArchived: false,
    dueDates: () => ({}),
    selectionMode: false,
    selectedProjectIds: () => [],
    selectableProjectIds: () => [],
    draggableProjectIds: () => [],
    canManageFolders: false,
})

const emit = defineEmits<{
    toggleSelection: [projectId: number],
    openFolder: [folderId: number],
    renameFolder: [folder: IProjectFolder],
    deleteFolder: [folder: IProjectFolder],
    moveProject: [projectId: number, folderId: number],
}>()

const filteredProjects = computed(() => props.showArchived
    ? props.projects
    : props.projects.filter(project => !project.isArchived))
const draggedId = ref<number | null>(null)
const dropFolderId = ref<number | null>(null)

function isSelected(id: number) { return props.selectedProjectIds.includes(id) }
function isSelectable(id: number) { return props.selectableProjectIds.includes(id) }
function isDraggable(id: number) { return props.draggableProjectIds.includes(id) }

function status(project: IProject): string {
    if (project.isArchived) return 'Архив'
    if (project.isCompleted) return 'Выполнен'
    return 'Активный'
}

function dateText(input: string | Date): string {
    const date = new Date(input)
    return Number.isNaN(date.getTime()) ? '—' : new Intl.DateTimeFormat('ru-RU', {
        day: '2-digit', month: '2-digit', year: 'numeric',
    }).format(date)
}

function onProjectDragStart(event: DragEvent, id: number) {
    if (props.selectionMode || !isDraggable(id) || !event.dataTransfer) {
        event.preventDefault()
        return
    }
    draggedId.value = id
    event.dataTransfer.effectAllowed = 'move'
    event.dataTransfer.setData('application/x-vikunja-project-id', String(id))
    event.dataTransfer.setData('text/plain', String(id))
}

function onProjectDragEnd() {
    draggedId.value = null
    dropFolderId.value = null
}

function onFolderDragOver(event: DragEvent, folderId: number) {
    if (draggedId.value === null) return
    dropFolderId.value = folderId
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move'
}

function onFolderDragLeave(event: DragEvent, folderId: number) {
    const element = event.currentTarget as HTMLElement | null
    const next = event.relatedTarget as Node | null
    if (element && next && element.contains(next)) return
    if (dropFolderId.value === folderId) dropFolderId.value = null
}

function onFolderDrop(event: DragEvent, folderId: number) {
    const raw = event.dataTransfer?.getData('application/x-vikunja-project-id') || ''
    const id = Number(raw)
    if (Number.isInteger(id) && isDraggable(id) && draggedId.value === id) {
        emit('moveProject', id, folderId)
    }
    onProjectDragEnd()
}
</script>

<style scoped>
.project-rows { border: 1px solid var(--gtt-border); border-radius: 13px; background: var(--gtt-panel); box-shadow: var(--gtt-shadow-xs); overflow: visible; }
.project-rows-heading,.project-row { display: grid; grid-template-columns: minmax(180px,2.2fr) minmax(105px,.8fr) minmax(125px,.8fr) minmax(115px,.8fr) 75px; align-items: center; gap: 12px; }
.project-rows-heading { padding: 12px 15px; color: var(--gtt-text-soft); background: var(--gtt-panel-soft); border-bottom: 1px solid var(--gtt-border); border-radius: 13px 13px 0 0; font-size: 11px; font-weight: 800; letter-spacing: .045em; text-transform: uppercase; }
.project-row { min-height: 55px; padding: 9px 15px; border-bottom: 1px solid var(--gtt-border); transition: background .12s; }
.project-row:last-child { border-bottom: 0; border-radius: 0 0 13px 13px; }
.project-row:hover { background: var(--gtt-panel-soft); }
.project-row.is-selected { background: var(--gtt-green-100); }
.project-row.is-drop-target { background: var(--gtt-lime-soft); box-shadow: inset 0 0 0 2px var(--gtt-green-700); }
.project-row[draggable="true"] { cursor: grab; }
.project-row[draggable="true"]:active { cursor: grabbing; }
.project-row-title { min-width: 0; display: flex; align-items: center; gap: 11px; }
.project-row-icon { width: 31px; height: 31px; flex: none; display: grid; place-items: center; border-radius: 9px; font-size: 14px; }
.is-folder-icon { color: var(--gtt-green-800); background: var(--gtt-lime-soft); }
.is-project-icon { color: var(--project-accent); background: var(--gtt-panel-soft); border: 1px solid var(--gtt-border); }
.project-row-name-group { display: grid; gap: 3px; min-width: 0; }
.project-row-name, .project-row-folder-button { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: left; font-weight: 680; color: var(--gtt-text); text-decoration: none; font-size: 13px; }
.project-row-folder-button { cursor: pointer; background: transparent; border: 0; padding: 7px 0; }
.project-row-name:hover, .project-row-folder-button:hover { color: var(--gtt-green-700); text-decoration: underline; }
.project-row-muted { color: var(--gtt-text-soft); font-size: 12px; }
.project-row-status { min-width: 0; }
.project-state { display: inline-block; border-radius: 7px; background: var(--gtt-green-100); color: var(--gtt-green-800); font-weight: 730; padding: 4px 8px; font-size: 11px; }
.project-state.is-complete { background: var(--gtt-lime-soft); }
.project-state.is-archived { background: var(--gtt-panel-soft); color: var(--gtt-text-soft); }
.project-row-actions { display: flex; align-items: center; justify-content: center; }
.project-row-menu { display: grid; place-items: center; height: 32px; width: 32px; padding: 0; color: var(--gtt-text-soft); border-radius: 8px; }
.project-row-menu:hover { background: var(--gtt-panel-soft); }
.project-row-select { display: grid; place-items: center; padding: 0; width: 22px; height: 22px; border: 2px solid var(--gtt-border-strong); background: var(--gtt-panel); color: var(--gtt-green-800); border-radius: 6px; cursor: pointer; flex: none; }
.project-row-select[aria-pressed="true"] { background: var(--gtt-lime-soft); border-color: var(--gtt-green-700); }
.project-row-select:disabled { opacity: .3; cursor: not-allowed; }
.project-rows.is-list { display: grid; gap: 6px; padding: 8px; border: 0; background: transparent; box-shadow: none; }
.is-list .project-row { grid-template-columns: minmax(0,1fr) 48px; min-height: 51px; padding: 9px 13px; border: 1px solid var(--gtt-border); background: var(--gtt-panel); border-radius: 10px; }
.is-list .project-row:hover { background: var(--gtt-panel-soft); }
.project-row-subtitle { color: var(--gtt-text-soft); font-size: 11px; }
@media (max-width: 740px) {
    .project-rows.is-table { overflow-x: auto; }
    .is-table .project-rows-heading, .is-table .project-row { min-width: 680px; }
}
</style>
