<template>
	<div
		class="project-folder-card"
		:class="{'is-drop-target': isDropTarget}"
	>
		<BaseButton
			class="folder-open-button"
			:aria-label="folder.title"
			@click="emit('open', folder.id)"
		>
			<span class="folder-title">{{ folder.title }}</span>
		</BaseButton>

		<Dropdown
			v-if="canManage"
			class="folder-menu"
		>
			<template #trigger="triggerProps">
				<BaseButton
					class="folder-menu-trigger"
					:aria-label="actionsLabel"
					:aria-expanded="triggerProps.open"
					@click.stop="triggerProps.toggleOpen"
				>
					<Icon icon="ellipsis-h" />
				</BaseButton>
			</template>

			<DropdownItem
				icon="pen"
				@click="emit('rename', folder)"
			>
				{{ renameLabel }}
			</DropdownItem>

			<DropdownItem
				icon="trash-alt"
				class="has-text-danger"
				@click="emit('delete', folder)"
			>
				{{ deleteLabel }}
			</DropdownItem>
		</Dropdown>
	</div>
</template>

<script setup lang="ts">
import type {IProjectFolder} from '@/modelTypes/IProjectFolder'

import BaseButton from '@/components/base/BaseButton.vue'
import Dropdown from '@/components/misc/Dropdown.vue'
import DropdownItem from '@/components/misc/DropdownItem.vue'

withDefaults(defineProps<{
folder: IProjectFolder,
canManage?: boolean,
isDropTarget?: boolean,
}>(), {
	canManage: false,
	isDropTarget: false,
})

const emit = defineEmits<{
open: [folderId: number],
rename: [folder: IProjectFolder],
delete: [folder: IProjectFolder],
}>()

const actionsLabel = '\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044f \u0441 \u043f\u0430\u043f\u043a\u043e\u0439'
const renameLabel = '\u041f\u0435\u0440\u0435\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u0442\u044c'
const deleteLabel = '\u0423\u0434\u0430\u043b\u0438\u0442\u044c'
</script>

<style lang="scss" scoped>
.project-folder-card {
	--folder-fill:
		color-mix(
			in srgb,
			var(--gtt-lime) 28%,
			var(--gtt-panel)
		);

	position: relative;
	block-size: 100%;
	overflow: visible;
	background: transparent;
	transition:
		transform 140ms ease,
		filter 140ms ease;

	&::before,
	&::after {
		content: '';
		position: absolute;
		background: var(--folder-fill);
		pointer-events: none;
	}

	&::before {
		inset-block-start: .15rem;
		inset-inline-start: .2rem;
		inline-size: 46%;
		block-size: 2.1rem;
		border: 1px solid var(--gtt-border);
		border-block-end: 0;
		border-radius: 1rem 1rem 0 0;
		clip-path:
			polygon(
				0 0,
				76% 0,
				100% 100%,
				0 100%
			);
	}

	&::after {
		inset-block-start: 1.42rem;
		inset-inline: 0;
		inset-block-end: 0;
		border: 1px solid var(--gtt-border);
		border-radius: var(--gtt-radius-lg);
		box-shadow: var(--gtt-shadow-sm);
	}

	&:hover {
		transform: translateY(-3px);
		filter: brightness(.99);

		&::after {
			box-shadow: var(--gtt-shadow-md);
		}
	}

	&.is-drop-target {
		transform: translateY(-2px);

		&::after {
			box-shadow:
				0 0 0 3px
				color-mix(
					in srgb,
					var(--gtt-green-700) 24%,
					transparent
				),
				var(--gtt-shadow-md);
		}
	}
}

.folder-open-button {
	position: relative;
	z-index: 1;
	display: flex;
	align-items: flex-end;
	justify-content: flex-start;
	inline-size: 100%;
	block-size: 100%;
	padding: 1rem;
	border: 0;
	background: transparent;
	color: var(--gtt-text);
	text-align: start;
}

.folder-title {
	inline-size: calc(100% - 2rem);
	overflow: hidden;
	color: var(--gtt-green-900);
	font-size: .92rem;
	font-weight: 730;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.folder-menu {
	position: absolute;
	inset-block-start: 1.7rem;
	inset-inline-end: .65rem;
	z-index: 5;
}

.folder-menu-trigger {
	display: flex;
	align-items: center;
	justify-content: center;
	inline-size: 2rem;
	block-size: 2rem;
	padding: 0;
	border: 0;
	border-radius: 9px;
	background: transparent;
	box-shadow: none;

	&:hover {
		background:
			color-mix(
				in srgb,
				var(--gtt-panel) 52%,
				transparent
			);
	}
}
</style>
