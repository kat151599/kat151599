<script setup lang="ts">
import { computed } from 'vue'
import { useNow } from '@vueuse/core'
import { useAuthStore } from '@/stores/auth'
import { useConfigStore } from '@/stores/config'
import { useColorScheme } from '@/composables/useColorScheme'

import LogoFull from '@/assets/logo-full.svg?component'
import LogoFullPride from '@/assets/logo-full-pride.svg?component'
import {MILLISECONDS_A_HOUR} from '@/constants/date'

const isPortfolioDemo = import.meta.env.VITE_CC58_NATIVE_DEMO === '1'
const demoBrandUrl = `${import.meta.env.BASE_URL}clientcircuit-brand.svg`

const now = useNow({
	interval: MILLISECONDS_A_HOUR,
})

const authStore = useAuthStore()
const configStore = useConfigStore()
const { isDark } = useColorScheme()

const Logo = computed(() => configStore.allowIconChanges
	&& authStore.settings.frontendSettings.allowIconChanges
	&& now.value.getMonth() === 5
	? LogoFullPride
	: LogoFull)

const CustomLogo = computed(() => {
	const lightLogo = window.CUSTOM_LOGO_URL
	const darkLogo = window.CUSTOM_LOGO_URL_DARK

	if (!lightLogo && !darkLogo) return ''
	if (!darkLogo) return lightLogo
	if (!lightLogo) return darkLogo

	return isDark.value ? darkLogo : lightLogo
})
</script>

<template>
	<div>
		<img
			v-if="isPortfolioDemo"
			:src="demoBrandUrl"
			alt="ClientCircuit"
			class="logo"
		>
		<Logo
			v-else-if="!CustomLogo"
			alt="Vikunja"
			class="logo"
		/>
		<img
			v-else
			v-show="CustomLogo"
			:src="CustomLogo"
			alt="Vikunja"
			class="logo"
		>
	</div>
</template>

<style lang="scss" scoped>
.logo {
	color: var(--logo-text-color);
	max-inline-size: 168px;
	max-block-size: 48px;
}
</style>
