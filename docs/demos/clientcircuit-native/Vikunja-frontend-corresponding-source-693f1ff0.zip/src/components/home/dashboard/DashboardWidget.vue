<template>
	<article
		class="dashboard-widget"
		:class="[`dashboard-widget--${widget.width}`, `dashboard-widget--type-${widget.type}`]"
	>
		<header class="dashboard-widget__header">
			<div class="dashboard-widget__heading">
				<button
					v-if="editing && !locked"
					type="button"
					class="dashboard-widget__drag-handle"
					aria-label="Переместить виджет"
				>
					⋮⋮
				</button>

				<span
					class="dashboard-widget__marker"
					aria-hidden="true"
				/>

				<h2>{{ widget.title }}</h2>
			</div>

			<div
				v-if="editing"
				class="dashboard-widget__actions"
			>
				<button
					type="button"
					class="dashboard-widget__action"
					aria-label="Настройки виджета"
					@click="$emit('settings')"
				>
					⚙
				</button>

				<button
					type="button"
					class="dashboard-widget__action dashboard-widget__action--danger"
					aria-label="Удалить виджет"
					@click="$emit('remove')"
				>
					×
				</button>
			</div>
		</header>

		<div class="dashboard-widget__content">
			<slot />
		</div>
	</article>
</template>

<script setup lang="ts">
import type {IDashboardWidget} from '@/modelTypes/IDashboard'

defineProps<{
widget: IDashboardWidget
editing: boolean
locked: boolean
}>()

defineEmits<{
remove: []
settings: []
}>()
</script>

<style lang="scss" scoped>
.dashboard-widget {
	display: flex;
	flex-direction: column;
	min-inline-size: 0;
	min-block-size: 0;
	border: 1px solid var(--gtt-border);
	border-radius: var(--gtt-radius-lg);
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
	overflow: hidden;
	transition:
		box-shadow 160ms ease,
		border-color 160ms ease;

	&:hover {
		border-color: var(--gtt-border-strong);
		box-shadow: var(--gtt-shadow-md);
	}

	&--normal {
		grid-column: span 4;
	}

	&--wide {
		grid-column: span 8;
	}

	&--full {
		grid-column: span 12;
	}

	@media screen and (max-width: $widescreen) {
		&--normal {
			grid-column: span 6;
		}

		&--wide,
		&--full {
			grid-column: span 12;
		}
	}

	@media screen and (max-width: $tablet) {
		&--normal,
		&--wide,
		&--full {
			grid-column: span 12;
		}
	}
}

.dashboard-widget--type-metric {
	background:
		linear-gradient(
			135deg,
			color-mix(
				in srgb,
				var(--gtt-lime-soft) 54%,
				var(--gtt-panel)
			),
			var(--gtt-panel) 58%
		);
}

.dashboard-widget__header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: .75rem;
	min-block-size: 50px;
	padding: .8rem 1rem;
	border-block-end: 1px solid var(--gtt-border);
}

.dashboard-widget__heading {
	display: flex;
	align-items: center;
	gap: .6rem;
	min-inline-size: 0;

	h2 {
		margin: 0;
		color: var(--gtt-text);
		font-size: .92rem;
		font-weight: 720;
		letter-spacing: -.015em;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
}

.dashboard-widget__marker {
	display: block;
	flex: 0 0 auto;
	inline-size: 8px;
	block-size: 8px;
	border-radius: 999px;
	background: var(--gtt-green-700);
	box-shadow: 0 0 0 4px var(--gtt-green-100);
}

.dashboard-widget--type-metric .dashboard-widget__marker {
	background: var(--gtt-lime);
}

.dashboard-widget--type-calendar .dashboard-widget__marker {
	background: var(--gtt-blue);
}

.dashboard-widget--type-activityStream .dashboard-widget__marker {
	background: var(--gtt-purple);
}

.dashboard-widget--type-activities .dashboard-widget__marker {
	background: var(--gtt-yellow);
}

.dashboard-widget__drag-handle,
.dashboard-widget__action {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	inline-size: 30px;
	block-size: 30px;
	padding: 0;
	border: 0;
	border-radius: 8px;
	background: transparent;
	color: var(--gtt-text-soft);
	cursor: pointer;

	&:hover {
		background: var(--gtt-panel-soft);
		color: var(--gtt-text);
	}
}

.dashboard-widget__drag-handle {
	cursor: grab;

	&:active {
		cursor: grabbing;
	}
}

.dashboard-widget__actions {
	display: flex;
	align-items: center;
	gap: .15rem;
}

.dashboard-widget__action--danger:hover {
	color: var(--danger);
}

.dashboard-widget__content {
	flex: 1;
	min-block-size: 0;
	container-type: inline-size;
	container-name: dashboard-widget-content;
	padding: 1rem;
}
</style>