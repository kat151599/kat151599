<template>
	<div class="tasks-widget">
		<AddTask
			:project-id="0"
			class="tasks-widget__add"
			@tasksAdded="store.addTasks"
		/>

		<div
			v-if="store.isLoading"
			class="tasks-widget__state"
		>
			{{ text.loading }}
		</div>
		<div
			v-else-if="openTasks.length === 0"
			class="tasks-widget__state"
		>
			{{ text.empty }}
		</div>

		<div
			v-else
			class="tasks-widget__list"
		>
			<div
				v-for="task in openTasks"
				:key="task.id"
				class="tasks-widget__task"
			>
				<RouterLink
					:to="{name: 'task.detail', params: {id: task.id}}"
					class="tasks-widget__task-title"
				>
					<Icon icon="tasks" />
					<span>{{ task.title }}</span>
				</RouterLink>

				<select
					class="tasks-widget__project-select"
					:value="task.projectId"
					@change="moveTask(task, $event)"
				>
					<option
						v-if="task.projectId === 0"
						:value="0"
						disabled
					>
						{{ text.noProject }}
					</option>
					<option
						v-for="project in projects"
						:key="project.id"
						:value="project.id"
					>
						{{ project.title }}
					</option>
				</select>
			</div>
		</div>

		<RouterLink
			:to="{name: 'tasks.my'}"
			class="tasks-widget__all"
		>
			{{ text.all }}
		</RouterLink>
	</div>
</template>

<script setup lang="ts">
import {computed, onMounted} from 'vue'

import AddTask from '@/components/tasks/AddTask.vue'
import {useMyTasksStore} from '@/stores/myTasks'
import {useProjectStore} from '@/stores/projects'

import type {ITask} from '@/modelTypes/ITask'

const props = withDefaults(defineProps<{
	autoload?: boolean
}>(), {
	autoload: true,
})

const text = {
	loading: '\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430\u2026',
	empty: '\u041d\u0435\u0442 \u0430\u043a\u0442\u0438\u0432\u043d\u044b\u0445 \u0437\u0430\u0434\u0430\u0447.',
	noProject: '\u0411\u0435\u0437 \u043f\u0440\u043e\u0435\u043a\u0442\u0430',
	all: '\u0412\u0441\u0435 \u043c\u043e\u0438 \u0437\u0430\u0434\u0430\u0447\u0438 \u2192',
}

const store = useMyTasksStore()
const projectStore = useProjectStore()

const openTasks = computed(() => store.tasks.filter(task => !task.done).slice(0, 8))
const projects = computed(() => projectStore.projectsArray
	.filter(project => project.id > 0 && !project.isArchived)
	.sort((a, b) => a.title.localeCompare(b.title)))

async function moveTask(task: ITask, event: Event) {
	const projectId = Number((event.target as HTMLSelectElement).value)
	if (projectId <= 0 || projectId === task.projectId) return
	try {
		await store.moveToProject(task, projectId)
	} catch (e) {
		console.error('Could not move dashboard task', e)
		await store.load()
	}
}

onMounted(async () => {
	if (!props.autoload) return

	if (projectStore.projectsArray.length === 0) {
		await projectStore.loadAllProjects()
	}
	if (store.tasks.length === 0) {
		await store.load()
	}
})
</script>

<style scoped lang="scss">
.tasks-widget {
	display: grid;
	gap: .85rem;
}

.tasks-widget :deep(.task-add) {
	padding: 0;
	border: 0;
	background: transparent;
	box-shadow: none;
}

.tasks-widget :deep(.add-task__field) {
	padding: .3rem;
	border: 1px solid var(--gtt-border-strong);
	border-radius: 12px;
	background: var(--gtt-panel-soft);
}

.tasks-widget :deep(.add-task-textarea) {
	background: transparent;
}

.tasks-widget__state {
	display: grid;
	place-items: center;
	min-block-size: 90px;
	padding: 1rem;
	color: var(--gtt-text-soft);
	text-align: center;
}

.tasks-widget__list {
	display: grid;
	gap: .4rem;
}

.tasks-widget__task {
	display: flex;
	align-items: center;
	gap: .75rem;
	padding: .65rem .75rem;
	border: 1px solid transparent;
	border-radius: 10px;
	background: var(--gtt-panel-soft);
	transition:
		background-color 120ms ease,
		border-color 120ms ease;

	&:hover {
		border-color: var(--gtt-border);
		background: var(--gtt-panel);
	}
}

.tasks-widget__task-title {
	display: flex;
	align-items: center;
	flex: 1;
	gap: .5rem;
	min-inline-size: 0;
	color: var(--gtt-text);
	font-size: .82rem;
	font-weight: 650;

	span {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
}

.tasks-widget__project-select {
	max-inline-size: 180px;
	min-block-size: 34px;
	border: 1px solid var(--gtt-border);
	border-radius: 8px;
	background: var(--gtt-panel);
	color: var(--gtt-text-soft);
	font-size: .72rem;
}

.tasks-widget__all {
	justify-self: end;
	color: var(--gtt-green-800);
	font-size: .78rem;
	font-weight: 700;
}

@media screen and (max-width: $tablet) {
	.tasks-widget__task {
		align-items: stretch;
		flex-direction: column;
	}

	.tasks-widget__project-select {
		max-inline-size: none;
		inline-size: 100%;
	}
}
</style>
