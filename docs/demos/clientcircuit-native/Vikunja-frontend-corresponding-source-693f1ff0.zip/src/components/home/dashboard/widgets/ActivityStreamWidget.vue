<template>
	<div class="activity-stream">
		<div class="activity-stream__visual">
			<span class="activity-stream__dot" />
			<span class="activity-stream__line" />
			<span class="activity-stream__dot activity-stream__dot--soft" />
			<span class="activity-stream__line" />
			<span class="activity-stream__dot activity-stream__dot--faint" />
		</div>

		<div class="activity-stream__copy">
			<strong>Лента активности</strong>

			<p>
				Здесь появятся последние изменения задач,
				комментарии и действия команды.
			</p>
		</div>
	</div>
</template>

<style scoped lang="scss">
.activity-stream {
	display: flex;
	align-items: center;
	gap: 1rem;
	min-block-size: 125px;
	padding: .5rem;
}

.activity-stream__visual {
	display: grid;
	place-items: center;
	flex: 0 0 auto;
	inline-size: 36px;
}

.activity-stream__dot {
	display: block;
	inline-size: 10px;
	block-size: 10px;
	border-radius: 999px;
	background: var(--gtt-purple);
	box-shadow:
		0 0 0 4px
		color-mix(
			in srgb,
			var(--gtt-purple) 16%,
			transparent
		);

	&--soft {
		opacity: .62;
	}

	&--faint {
		opacity: .32;
	}
}

.activity-stream__line {
	display: block;
	inline-size: 1px;
	block-size: 20px;
	background: var(--gtt-border-strong);
}

.activity-stream__copy {
	min-inline-size: 0;

	strong {
		color: var(--gtt-text);
		font-size: .9rem;
	}

	p {
		margin: .35rem 0 0;
		color: var(--gtt-text-soft);
		font-size: .78rem;
		line-height: 1.5;
	}
}
</style>