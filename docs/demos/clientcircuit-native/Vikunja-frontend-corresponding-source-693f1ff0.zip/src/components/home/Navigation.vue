<template>
	<aside
		:class="{'is-active': baseStore.menuActive, 'is-resizing': isResizing}"
		class="menu-container d-print-none"
		:style="{'--sidebar-width': sidebarWidth}"
	>
		<nav
			class="menu top-menu"
			:aria-label="$t('navigation.main')"
		>
			<RouterLink
				:to="{name: 'home'}"
				class="logo"
				:aria-label="$t('navigation.home')"
			>
				<img
					:src="isPortfolioDemo ? demoBrandUrl : companyLogoUrl"
					alt=""
					class="company-logo"
					height="44"
				>
				<span class="brand-wordmark">
					{{ isPortfolioDemo ? 'ClientCircuit' : 'Vikunja' }}
				</span>
			</RouterLink>
			<menu class="menu-list other-menu-items">
				<li v-if="canCreateTasks">
					<BaseButton
						class="list-menu-link task-create-link"
						style="inline-size:100%;display:flex;align-items:center;text-align:start;"
						@click="showAddTaskModal = true"
					>
						<span class="menu-item-icon icon"><Icon icon="plus" /></span>
						Добавить задачу
					</BaseButton>
				</li>
				<li>
					<RouterLink
						v-shortcut="'KeyG KeyO'"
						:to="{ name: 'home'}"
					>
						<span class="menu-item-icon icon">
							<Icon icon="home" />
						</span>
						{{ $t('navigation.overview') }}
					</RouterLink>
				</li>
				<li v-if="canTasks">
					<RouterLink :to="{name: 'personal.dashboard'}">
						<span class="menu-item-icon icon"><Icon icon="user" /></span>
						Личное
					</RouterLink>
				</li>
				<li v-if="canProjects">
					<RouterLink
						v-shortcut="'KeyG KeyP'"
						:to="{ name: 'projects.index'}"
					>
						<span class="menu-item-icon icon">
							<Icon icon="layer-group" />
						</span>
						{{ $t('project.projects') }}
					</RouterLink>
				</li>
				<li>
					<RouterLink :to="{ name: 'mailbox'}">
						<span class="menu-item-icon icon">
							<Icon icon="envelope" />
						</span>
						{{ $t('mailbox.title') }}
						<span
							v-if="mailboxStore.unreadCount > 0"
							class="mailbox-nav-badge"
						>
							{{
								mailboxStore.unreadCount > 99
									? '99+'
									: mailboxStore.unreadCount
							}}
						</span>
					</RouterLink>
				</li>
				<li v-if="canWialon">
					<RouterLink :to="{ name: 'wialon'}">
						<span class="menu-item-icon icon">
							<Icon icon="sitemap" />
						</span>
						{{ $t('wialon.title') }}
					</RouterLink>
				</li>
				<li v-if="timeTrackingEnabled && canTimeTracking">
					<RouterLink :to="{ name: 'time-tracking'}">
						<span class="menu-item-icon icon">
							<Icon :icon="['far', 'clock']" />
						</span>
						{{ $t('timeTracking.title') }}
					</RouterLink>
				</li>
			</menu>
		</nav>

		<nav

			v-if="canProjects"

			class="menu root-projects-menu"

			:aria-label="$t('project.projects')"
		>
			<RootProjectsNavigation />
		</nav>


		<div class="sidebar-bottom">
			<PoweredByLink
				utm-medium="navigation"
			/>

			<nav
				v-if="canCallCenter"
				class="call-center-module"
				aria-label="Call center"
			>
				<menu class="menu-list call-center-menu">
					<li>
						<RouterLink :to="{ name: 'call-center'}">
							<span class="menu-item-icon icon">
								<Icon icon="users" />
							</span>
							Колл-центр
						</RouterLink>
					</li>
				</menu>
			</nav>
		</div>

		<div
			v-if="!isMobile"
			class="resize-handle"
			@mousedown="startResize"
			@touchstart="startResize"
		/>
	</aside>

	<Modal
		v-if="showAddTaskModal"
		@close="showAddTaskModal = false"
	>
		<Card
			title="Добавить задачу"
			:has-content="false"
		>
			<AddTask
				:project-id="0"
				@tasksAdded="onGlobalTasksAdded"
			/>
		</Card>
	</Modal>
</template>

<script setup lang="ts">
import {computed, ref, watch} from 'vue'

import PoweredByLink from '@/components/home/PoweredByLink.vue'
import RootProjectsNavigation from '@/components/home/RootProjectsNavigation.vue'
import companyLogoUrl from '@/assets/company-logo.png'

// Demo branding is entirely opt-in: original UNI DEV / production keep Vikunja.
const isPortfolioDemo = import.meta.env.VITE_CC58_NATIVE_DEMO === '1'
const demoBrandUrl = `${import.meta.env.BASE_URL}clientcircuit-brand.svg`
import BaseButton from '@/components/base/BaseButton.vue'
import Modal from '@/components/misc/Modal.vue'
import Card from '@/components/misc/Card.vue'
import AddTask from '@/components/tasks/AddTask.vue'

import {useBaseStore} from '@/stores/base'
import {useConfigStore} from '@/stores/config'
import {useAccessStore} from '@/stores/access'
import {useAuthStore} from '@/stores/auth'
import {useMailboxStore} from '@/stores/mailbox'
import {useMyTasksStore} from '@/stores/myTasks'
import {ACCESS_PERMISSION} from '@/modelTypes/IAccessControl'
import {PRO_FEATURE} from '@/constants/proFeatures'
import type {ITask} from '@/modelTypes/ITask'
import {useSidebarResize} from '@/composables/useSidebarResize'

const baseStore = useBaseStore()
const configStore = useConfigStore()
const accessStore = useAccessStore()
const authStore = useAuthStore()
const mailboxStore = useMailboxStore()
const myTasksStore = useMyTasksStore()
const showAddTaskModal = ref(false)

watch(
	() => [
		authStore.authenticated,
		authStore.isLinkShareAuth,
	] as const,
	([authenticated, isLinkShareAuth]) => {
		if (authenticated && !isLinkShareAuth) {
			void mailboxStore.refreshUnread()
			return
		}

		mailboxStore.setUnreadCount(0)
	},
	{immediate: true},
)

function onGlobalTasksAdded(tasks: ITask[]) {
	myTasksStore.addTasks(tasks)
	showAddTaskModal.value = false
}

const timeTrackingEnabled = computed(() => configStore.isProFeatureEnabled(PRO_FEATURE.TIME_TRACKING))
const canProjects = computed(() => accessStore.can(ACCESS_PERMISSION.PROJECTS_VIEW))
const canTasks = computed(() => accessStore.can(ACCESS_PERMISSION.TASKS_ACCESS))
const canCreateTasks = computed(() =>
	accessStore.can(ACCESS_PERMISSION.TASKS_EDIT_OWN) ||
	accessStore.can(ACCESS_PERMISSION.TASKS_EDIT_PROJECT) ||
	accessStore.can(ACCESS_PERMISSION.TASKS_EDIT_ALL),
)
const canWialon = computed(() => accessStore.can(ACCESS_PERMISSION.WIALON_VIEW))
const canCallCenter = computed(() => accessStore.can(ACCESS_PERMISSION.CALLCENTER_ACCESS))
const canTimeTracking = computed(() => accessStore.can(ACCESS_PERMISSION.TIME_TRACKING))

const {sidebarWidth, isResizing, startResize, isMobile} = useSidebarResize()

</script>

<style lang="scss" scoped>
.logo {
	display: flex;
	align-items: center;
	gap: .7rem;
	min-block-size: $navbar-height;
	padding: .55rem .75rem 1rem;
	margin: 0;
	color: #ffffff;
	text-decoration: none;

	&:hover {
		color: #ffffff;
	}
}

.brand-wordmark {
	color: #f8fff9;
	font-size: 1.12rem;
	font-weight: 780;
	letter-spacing: -.035em;
}

.menu-container {
	--sidebar-width: #{$navbar-width};
	// Local token overrides make all nested project-navigation components work on the dark shell.
	--primary: var(--brand-lime);
	--primary-h: 78.4deg;
	--primary-s: 100%;
	--primary-l: 75.1%;
	--primary-hsl: var(--primary-h), var(--primary-s), var(--primary-l);
	--grey-700: #edf5f1;
	--grey-600: #d5e4de;
	--grey-500: #b1c5bd;
	--grey-400: #8fa89e;
	--grey-300: #68877b;
	--grey-200: rgba(255, 255, 255, .12);
	--grey-100: rgba(255, 255, 255, .08);
	--white: rgba(255, 255, 255, .075);

	display: flex;
	flex-direction: column;
	background:
		radial-gradient(circle at 12% 0%, rgba(216, 255, 128, .09), transparent 34%),
		linear-gradient(180deg, var(--brand-forest-strong) 0%, var(--brand-forest-deep) 100%);
	color: #edf5f1;
	padding-block-start: calc(1rem + var(--pwa-safe-area-top));
	padding-block-end: calc(.75rem + var(--pwa-safe-area-bottom));
	padding-inline-start: calc(.75rem + var(--pwa-safe-area-left));
	padding-inline-end: calc(.75rem + var(--pwa-safe-area-right));
	border-inline-end: 1px solid rgba(255, 255, 255, .07);
	box-shadow: 12px 0 32px rgba(7, 38, 31, .08);
	transition: transform $transition-duration ease-in;
	position: fixed;
	inset-block-start: 0;
	inset-block-end: 0;
	inset-inline-start: 0;
	transform: translateX(-100%);
	inline-size: var(--sidebar-width);
	overflow-y: auto;
	overflow-x: hidden;

	[dir="rtl"] & {
		transform: translateX(100%);
	}

	@media screen and (max-width: $tablet) {
		inset-block-start: 0;
		inline-size: min(84vw, 320px);
		z-index: 20;
		padding-block-start: calc(.75rem + var(--pwa-safe-area-top));
		box-shadow: 18px 0 45px rgba(0, 0, 0, .24);
	}

	&.is-active {
		transform: translateX(0);
		transition: transform $transition-duration ease-out;
	}

	&.is-resizing {
		transition: none;
	}

	:deep(.menu-list a),
	:deep(.menu-list .list-menu-link) {
		border-radius: 10px;
		color: #dce9e4;
		min-block-size: 42px;
		transition: background-color 140ms ease, color 140ms ease, transform 140ms ease;
	}

	:deep(.menu-list a:hover),
	:deep(.menu-list .list-menu-link:hover) {
		background: rgba(255, 255, 255, .075);
		color: #ffffff;
	}

	:deep(.menu-list a.router-link-exact-active) {
		background: rgba(216, 255, 128, .13);
		color: var(--brand-lime);
		font-weight: 700;
		box-shadow: inset 3px 0 0 var(--brand-lime);
	}

	:deep(.menu-list a.router-link-exact-active .icon:not(.handle)) {
		color: var(--brand-lime);
	}

	:deep(.menu-item-icon),
	:deep(.collapse-project-button svg) {
		color: #89a69a;
	}

	:deep(.color-bubble) {
		box-shadow: 0 0 0 2px rgba(255, 255, 255, .12);
	}
}

.sidebar-bottom {
	margin-block-start: auto;
	padding-block-start: 1rem;
}

.call-center-module {
	margin-block-start: .75rem;
	padding-block-start: .75rem;
	border-block-start: 1px solid rgba(255, 255, 255, .12);
}

.call-center-menu {
	margin: 0;

	li {
		margin: 0;
	}

	a {
		display: flex;
		align-items: center;
		gap: .35rem;
		min-block-size: 50px;
		padding: .8rem .9rem;
		border: 1px solid rgba(216, 255, 128, .28);
		border-radius: 12px;
		background: rgba(216, 255, 128, .08);
		color: #ffffff;
		font-weight: 750;
		box-shadow: 0 8px 22px rgba(0, 0, 0, .08);
		transition:
			background-color 140ms ease,
			border-color 140ms ease,
			transform 140ms ease,
			box-shadow 140ms ease;

		&:hover {
			background: rgba(216, 255, 128, .14);
			border-color: rgba(216, 255, 128, .45);
			color: #ffffff;
			transform: translateY(-1px);
			box-shadow: 0 10px 24px rgba(0, 0, 0, .12);
		}

		&.router-link-exact-active {
			background: rgba(216, 255, 128, .17);
			border-color: var(--brand-lime);
			color: var(--brand-lime);
			box-shadow:
				inset 3px 0 0 var(--brand-lime),
				0 10px 24px rgba(0, 0, 0, .1);
		}
	}

	.menu-item-icon {
		color: var(--brand-lime);
	}
}
.mailbox-nav-badge {
display: inline-flex;
align-items: center;
justify-content: center;
min-inline-size: 1.35rem;
block-size: 1.35rem;
padding-inline: .32rem;
margin-inline-start: auto;
border-radius: 999px;
background: #ef4444;
color: #ffffff;
font-size: .68rem;
font-weight: 800;
line-height: 1;
box-shadow: 0 0 0 2px rgba(255, 255, 255, .08);
}
.resize-handle {
	position: absolute;
	inset-block-start: 0;
	inset-block-end: 0;
	inset-inline-end: 0;
	inline-size: 5px;
	cursor: ew-resize;
	background: transparent;
	transition: background-color $transition-duration ease;
	touch-action: none;

	&:hover,
	&:active {
		background-color: rgba(216, 255, 128, .38);
	}
}

.top-menu .menu-list {
	li {
		font-weight: 600;
		font-family: $vikunja-font;
	}

	.list-menu-link,
	li > a {
		padding-inline: .85rem;
		display: flex;
		gap: .15rem;

		.icon {
			padding-block-end: 0;
		}
	}
}

.menu + .menu {
	padding-block-start: .8rem;
	margin-block-start: .55rem;
	border-block-start: 1px solid rgba(255, 255, 255, .065);
}

.company-logo {
	display: block;
	inline-size: 42px;
	block-size: 42px;
	object-fit: contain;
	filter: drop-shadow(0 6px 14px rgba(0, 0, 0, .16));
}
</style>
