<template>
	<div
		class="task loader-container draggable"
		:class="{
			'is-loading': loadingInternal || loading,
			'draggable': !(loadingInternal || loading),
			'has-light-text': !colorIsDark(color),
			'has-custom-background-color': color ?? undefined,
		}"
		:style="{'background-color': color ?? undefined}"
		:data-task-id="task.id"
		:data-project-id="task.projectId"
		:data-is-overdue="isOverdue || undefined"
		@click.exact="openTaskDetail()"
		@click.ctrl="() => toggleTaskDone(task)"
		@click.meta="() => toggleTaskDone(task)"
	>
		<img
			v-if="coverImageBlobUrl"
			:src="coverImageBlobUrl"
			alt=""
			class="tw:w-full"
		>
		<div class="p-2">
			<div class="tw:flex tw:justify-between">
				<span class="task-id">
					<Done
						class="kanban-card__done"
						:is-done="task.done"
						variant="small"
					/>
					<template v-if="task.identifier === ''">
						#{{ task.index }}
					</template>
					<template v-else>
						{{ task.identifier }}
					</template>
					<span
						v-if="showTaskPosition"
						class="tw:text-red-600 tw:ps-2"
					>
						{{ task.position }}
					</span>
				</span>
				<span
					v-if="task.dueDate > 0"
					v-tooltip="formatDateLong(task.dueDate)"
					class="due-date"
				>
					<span class="icon">
						<Icon :icon="['far', 'calendar-days']" />
					</span>
					<time :datetime="formatISO(task.dueDate)">
						{{ formatDisplayDate(task.dueDate) }}
					</time>
				</span>
			</div>
			
			<h3>
				<RouterLink
					:to="{ name: 'task.detail', params: {id: task.id} }"
					class="kanban-card__title-link"
					draggable="false"
					@click.exact.prevent.stop="openTaskDetail()"
					@click.ctrl.stop
					@click.meta.stop
				>
					{{ task.title }}
				</RouterLink>
			</h3>
			
			<span
				v-if="projectTitle"
				class="project-title"
			>
				{{ projectTitle }}
			</span>

			<ProgressBar
				v-if="task.percentDone > 0"
				class="task-progress"
				:value="task.percentDone * 100"
			/>
			<div class="footer">
				<Labels :labels="task.labels" />
				<PriorityLabel
					:priority="task.priority"
					:done="task.done"
					class="is-inline-flex is-align-items-center"
				/>
				<span
					v-if="task.attachments.length > 0"
					class="icon"
					role="img"
					:aria-label="$t('task.attributes.attachment', task.attachments.length)"
				>
					<Icon icon="paperclip" />
				</span>
				<span
					v-if="!isEditorContentEmpty(task.description)"
					class="icon"
				>
					<Icon icon="align-left" />
				</span>
				<span
					v-if="task.repeatAfter.amount > 0"
					class="icon"
				>
					<Icon icon="clock-rotate-left" />
				</span>
				<CommentCount
					:task="task"
					class="project-task-icon"
				/>
				<span
					v-for="group in (task.workGroups ?? [])"
					:key="`group-${group.id}`"
					class="tag work-group-tag"
					:title="$t('workGroups.assignedGroups')"
				>
					<Icon icon="users" />
					<span class="ml-1">{{ group.name }}</span>
				</span>
				<AssigneeList
					v-if="task.assignees.length > 0"
					:assignees="task.assignees"
					:avatar-size="24"
				/>
				<ChecklistSummary
					:task="task"
					class="checklist"
				/>
			</div>
		</div>
	</div>
</template>

<script lang="ts" setup>
import {computed, ref, watch} from 'vue'
import {useRouter} from 'vue-router'

import {useGlobalNow} from '@/composables/useGlobalNow'

import PriorityLabel from '@/components/tasks/partials/PriorityLabel.vue'
import ProgressBar from '@/components/misc/ProgressBar.vue'
import Done from '@/components/misc/Done.vue'
import Labels from '@/components/tasks/partials/Labels.vue'
import ChecklistSummary from './ChecklistSummary.vue'
import CommentCount from './CommentCount.vue'

import {getHexColor} from '@/models/task'
import type {ITask} from '@/modelTypes/ITask'
import type {IProject} from '@/modelTypes/IProject'
import {SUPPORTED_IMAGE_SUFFIX} from '@/models/attachment'
import AttachmentService, {PREVIEW_SIZE} from '@/services/attachment'

import {formatDateLong, formatDisplayDate, formatISO} from '@/helpers/time/formatDate'
import {colorIsDark} from '@/helpers/color/colorIsDark'
import {useTaskStore} from '@/stores/tasks'
import AssigneeList from '@/components/tasks/partials/AssigneeList.vue'
import {playPopSound} from '@/helpers/playPop'
import {isEditorContentEmpty} from '@/helpers/editorContentEmpty'
import {useProjectStore} from '@/stores/projects'
import {TASK_REPEAT_MODES} from '@/types/IRepeatMode'

const props = withDefaults(defineProps<{
	task: ITask,
	projectId: IProject['id'],
	loading?: boolean,
}>(), {
	loading: false,
})

const emit = defineEmits<{
	'taskCompletedRecurring': [task: ITask]
	'taskUpdated': [task: ITask]
}>()

const router = useRouter()

const loadingInternal = ref(false)

const color = computed(() => getHexColor(props.task.hexColor))

const projectStore = useProjectStore()

const projectTitle = computed(() => {
	if (props.projectId === props.task.projectId) {
		return
	}
	
	const project = projectStore.projects[props.task.projectId]
	return project?.title
})

const showTaskPosition = computed(() => window.DEBUG_TASK_POSITION)

const {now} = useGlobalNow()
const isOverdue = computed(() => (
	!props.task.done &&
	props.task.dueDate !== null &&
	props.task.dueDate.getTime() > 0 &&
	props.task.dueDate.getTime() <= now.value.getTime()
))

async function toggleTaskDone(task: ITask) {
	const isRecurringTask = task.repeatAfter.amount > 0 || task.repeatMode === TASK_REPEAT_MODES.REPEAT_MODE_MONTH
	const wasBeingMarkedDone = !task.done
	
	loadingInternal.value = true
	try {
		const updatedTask = await useTaskStore().update({
			...task,
			done: !task.done,
		})

		if (updatedTask.done) {
			playPopSound()
		}

		emit('taskUpdated', updatedTask)
		
		// Emit event if this was a recurring task being marked as done
		if (isRecurringTask && wasBeingMarkedDone && updatedTask.done) {
			emit('taskCompletedRecurring', updatedTask)
		}
	} finally {
		loadingInternal.value = false
	}
}

function openTaskDetail() {
	router.push({
		name: 'task.detail',
		params: {id: props.task.id},
		state: {backdropView: router.currentRoute.value.fullPath},
	})
}

const coverImageBlobUrl = ref<string | null>(null)

async function maybeDownloadCoverImage() {
	if (!props.task.coverImageAttachmentId) {
		coverImageBlobUrl.value = null
		return
	}

	const attachment = props.task.attachments.find(a => a.id === props.task.coverImageAttachmentId)
	if (!attachment || !SUPPORTED_IMAGE_SUFFIX.some((suffix) => attachment.file.name.toLowerCase().endsWith(suffix))) {
		return
	}

	const attachmentService = new AttachmentService()
	coverImageBlobUrl.value = await attachmentService.getBlobUrl(attachment, PREVIEW_SIZE.LG)
}

watch(
	() => props.task.coverImageAttachmentId,
	maybeDownloadCoverImage,
	{immediate: true},
)
</script>

<style lang="scss" scoped>
$task-background: var(--white);

.task {
	-webkit-touch-callout: none;
	user-select: none;
	cursor: pointer;
	box-shadow: 0 4px 14px rgba(31, 91, 73, .07);
	display: block;
	font-size: .9rem;
	border: 1px solid var(--brand-border);
	border-radius: 12px;
	background: $task-background;
	overflow: hidden;
	transition: transform 140ms ease, box-shadow 140ms ease, border-color 140ms ease;

	&:hover {
		transform: translateY(-2px);
		box-shadow: 0 10px 24px rgba(31, 91, 73, .12);
		border-color: color-mix(in srgb, var(--brand-forest) 26%, var(--brand-border));
	}

	&.loader-container.is-loading::after {
		inline-size: 1.5rem;
		block-size: 1.5rem;
		inset-block-start: calc(50% - .75rem);
		inset-inline-start: calc(50% - .75rem);
		border-width: 2px;
	}

	h3 {
		font-family: $family-sans-serif;
		font-size: .92rem;
		font-weight: 650;
		line-height: 1.42;
		color: var(--text-strong);
		word-break: break-word;
		margin-block: .35rem .15rem;
	}

	.kanban-card__title-link { color: inherit; text-decoration: none; }

	.due-date {
		float: inline-end;
		display: flex;
		align-items: center;
		padding: .18rem .45rem;
		font-size: .74rem;
		font-weight: 650;
		color: var(--brand-text-muted);
		.icon { margin-inline-end: .2rem; }
	}

	&[data-is-overdue] .due-date {
		color: var(--danger-text);
		background: hsla(var(--danger-h), var(--danger-s), var(--danger-l), .09);
	}

	.label-wrapper .tag { margin: .45rem .4rem 0 0; border-radius: 7px; }

	.footer {
		background: transparent;
		padding: 0;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		gap: .3rem;
		margin-block-start: .55rem;
		:deep(.checklist-summary) { padding-inline-start: 0; }
		.work-group-tag {
			font-size: .68rem;
			font-weight: 650;
			max-inline-size: 10rem;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
			border-radius: 7px;
		}
		.assignees {
			display: flex;
			.user { display: inline; margin: 0; img { margin: 0; } }
		}
		.priority-label {
			font-size: .72rem;
			padding: .18rem .45rem;
			.icon { block-size: 1rem; padding: 0 .2rem; margin-block-start: 0; }
		}
	}

	.footer .icon,
	.due-date,
	.priority-label {
		background: var(--brand-surface-soft);
		border-radius: 8px;
		padding: .18rem .45rem;
	}

	.task-id, .project-title {
		color: var(--brand-text-muted);
		font-size: .72rem;
		font-weight: 650;
		margin-block-end: .2rem;
		display: flex;
	}

	&.is-moving { opacity: .5; }
	span { inline-size: auto; }

	&.has-custom-background-color {
		color: #000;
		.footer .icon, .due-date, .priority-label { background: hsl(220, 13%, 91%); }
		.task-id, .project-title { color: inherit; }
		.footer :deep(.checklist-summary) { color: inherit; }
	}

	&.has-light-text {
		--white: hsla(var(--white-h), var(--white-s), var(--white-l), var(--white-a)) !important;
		color: var(--white);
		h3 { color: inherit; }
		.footer .icon, .due-date, .priority-label { background: rgba(0, 0, 0, .24); }
		.footer .icon svg { fill: var(--white); }
		.task-id, .project-title { color: inherit; }
		.footer :deep(.checklist-summary) { color: inherit; }
		&[data-is-overdue] .due-date,
		.priority-label.high-priority { color: hsl(var(--danger-h), var(--danger-s), 72%); }
	}
}

.kanban-card__done { margin-inline-end: .3rem; }
.task-progress { margin: 8px 0 0; inline-size: 100%; block-size: .42rem; border-radius: 999px; overflow: hidden; }
:deep(.comment-count) { background: var(--brand-surface-soft); border-radius: 8px; padding: .2rem .4rem; }
</style>
