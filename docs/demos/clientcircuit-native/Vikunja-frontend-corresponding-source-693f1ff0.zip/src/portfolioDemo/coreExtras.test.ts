import {beforeEach,expect,it} from 'vitest'
import {initialBrowserDemoData,type BrowserDemoState} from './seed'
import {coreRead,coreWrite} from './coreExtras'
import {UNHANDLED} from './features'

let state:BrowserDemoState
beforeEach(()=>{state=initialBrowserDemoData()})

it('edits a native project view locally',()=>{
 const v=state.projects[0].views[1]
 const updated=coreWrite(state,'post','/projects/101/views/'+v.id,{title:'Моя доска'})
 expect(updated).toMatchObject({title:'Моя доска'})
 expect(state.projects[0].views[1].title).toBe('Моя доска')
})

it('duplicates a project with all its native view modes',()=>{
 const result=coreWrite(state,'put','/projects/101/duplicate',{}) as {
  project:{id:number,views:Array<{project_id:number}>}
 }
 expect(result.project.views).toHaveLength(4)
 expect(result.project.views.every(v=>v.project_id===result.project.id)).toBe(true)
})

it('stores task comments in this browser model',()=>{
 coreWrite(state,'put','/tasks/1001/comments',{comment:'Тестовая заметка'})
 const comments=coreRead(state,'/tasks/1001/comments') as Array<{comment:string}>
 expect(comments.some(c=>c.comment==='Тестовая заметка')).toBe(true)
})

it('keeps assignee and team membership locally',()=>{
 const result=coreWrite(state,'put','/tasks/1001/assignees',{user_id:2})
 expect(result).toMatchObject({task_id:1001,user_id:2})
 const assigned=coreRead(state,'/tasks/1001/assignees') as unknown[]
 expect(assigned).toHaveLength(2)
 coreWrite(state,'put','/projects/101/teams',{team_id:201})
 expect(coreRead(state,'/projects/101/teams')).toHaveLength(1)
})

it('does not invent responses for unsupported actions',()=>{
 expect(coreRead(state,'/outside-service')).toBe(UNHANDLED)
 expect(coreWrite(state,'post','/outside-service',{})).toBe(UNHANDLED)
})
