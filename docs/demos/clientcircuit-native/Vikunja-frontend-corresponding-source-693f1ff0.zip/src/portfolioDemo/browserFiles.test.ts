import {beforeEach,expect,it} from 'vitest'
import {initialBrowserDemoData,type BrowserDemoState} from './seed'
import {demoFileRead,demoFileWrite,demoConvertInput} from './browserFiles'
import {UNHANDLED} from './features'
let state:BrowserDemoState
beforeEach(()=>{state=initialBrowserDemoData()})

it('stores task attachments as browser-local bytes and returns a real Blob', async()=>{
 const file=new File(['example fixture'],'example.txt',{type:'text/plain'})
 const form=new FormData()
 form.append('files',file)
 const input=await demoConvertInput(form)
 const uploaded=demoFileWrite(state,'post','/tasks/1001/attachments',input) as {
  success:Array<{id:number,file:{name:string}}>
 }
 expect(uploaded.success[0].file.name).toBe('example.txt')
 expect(uploaded.success[0]).toMatchObject({task_id:1001})
 const list=demoFileRead(state,'/tasks/1001/attachments') as Array<{id:number}>
 expect(list.length).toBe(1)
 const blob=demoFileRead(state,'/tasks/1001/attachments/'+list[0].id) as Blob
 expect(blob).toBeInstanceOf(Blob)
 expect(await blob.text()).toBe('example fixture')
})

it('replays locally stored mailbox files after page state is serialized',async()=>{
 const form=new FormData()
 form.append('files',new File(['private fictional attachment'],'demo.txt'))
 const payload=await demoConvertInput(form)
 demoFileWrite(state,'post','/mailbox/messages/1/attachments',payload)
 const restored=JSON.parse(JSON.stringify(state)) as BrowserDemoState
 const blob=demoFileRead(restored,'/mailbox/messages/1/attachments/1') as Blob
 expect(await blob.text()).toBe('private fictional attachment')
})

it('denies unknown routes and never forwards a file to a server',()=>{
 expect(demoFileRead(state,'/private/customer/attachment')).toBe(UNHANDLED)
 expect(demoFileWrite(state,'post','/private/customer/attachment',{})).toBe(UNHANDLED)
})

it('keeps original project background upload and removal browser-local',async()=>{
 const form=new FormData()
 form.append('background',new File(['fictional-image'],'demo.png',{type:'image/png'}))
 const payload=await demoConvertInput(form)
 const updated=demoFileWrite(state,'put','/projects/101/backgrounds/upload',payload) as {
  background_information:{type:string}}
 expect(updated.background_information.type).toBe('upload')
 const blob=demoFileRead(state,'/projects/101/background') as Blob
 expect(await blob.text()).toBe('fictional-image')
 demoFileWrite(state,'delete','/projects/101/background',{})
 expect(demoFileRead(state,'/projects/101/background')).toBe(UNHANDLED)
})
it('enforces a small bounded file size for localStorage quota',async()=>{
 const form=new FormData()
 form.append('files',new File([new Uint8Array(512*1024+1)],'too-large.bin'))
 await expect(demoConvertInput(form)).rejects.toThrow('DEMO_FILE_TOO_LARGE_512_KIB')
 expect(state.extra).toEqual({})
})
