import {beforeEach,expect,it} from 'vitest'
import {initialBrowserDemoData,type BrowserDemoState} from './seed'
import {additionalRead,additionalWrite} from './additionalRoutes'
import {UNHANDLED} from './features'
let state:BrowserDemoState
beforeEach(()=>{state=initialBrowserDemoData()})

it('saves original Vue user general settings locally without credentials',()=>{
 const saved=additionalWrite(state,'post','/user/settings/general',{
  name:'Пользователь DEMO',language:'ru',password:'NOT_TO_STORE',token:'NOT_TO_STORE'
 }) as Record<string,unknown>
 expect(saved.name).toBe('Пользователь DEMO')
 expect(saved).not.toHaveProperty('password')
 expect(JSON.stringify(state)).not.toContain('NOT_TO_STORE')
 expect(additionalRead(state,'/user/settings/general')).toMatchObject({name:'Пользователь DEMO'})
})
it('maintains original native task checklist state and counters',()=>{
 const add=additionalWrite(state,'post','/tasks/1001/checklist-items',{title:'Демо-пункт'}) as {
  total:number,completed:number,items:Array<{id:number}>}
 expect(add).toMatchObject({total:1,completed:0})
 const state2=additionalWrite(state,'put','/tasks/1001/checklist-items/'+add.items[0].id,{
  title:'Демо-пункт',done:true}) as {total:number,completed:number}
 expect(state2).toMatchObject({total:1,completed:1})
 const after=additionalRead(state,'/tasks/1001/checklist-items') as typeof state2
 expect(after.completed).toBe(1)
})
it('keeps task relation and emoji reactions in browser only',()=>{
 const relation=additionalWrite(state,'put','/tasks/1001/relations',{
  other_task_id:1002,relation_kind:'related'
 })
 expect(relation).toMatchObject({task_id:1001,other_task_id:1002})
 const relations=additionalRead(state,'/tasks/1001/relations') as unknown[]
 expect(relations).toHaveLength(1)
 additionalWrite(state,'put','/tasks/1001/reactions',{value:'👍'})
 const reactions=additionalRead(state,'/tasks/1001/reactions') as Record<string,unknown[]>
 expect(reactions['👍']).toHaveLength(1)
})
it('creates only demo-local link shares without a valid public token',()=>{
 const share=additionalWrite(state,'put','/projects/101/shares',{
  name:'Только этот браузер'}) as {hash:string}
 expect(share.hash.startsWith('demo-browser-local-')).toBe(true)
 const list=additionalRead(state,'/projects/101/shares') as unknown[]
 expect(list).toHaveLength(1)
})
it('keeps webhook settings local and drops provider secrets',()=>{
 const webhook=additionalWrite(state,'put','/projects/101/webhooks',{
  target_url:'https://example.invalid',secret:'DO_NOT_STORE',basic_auth_password:'DO_NOT_STORE'
 }) as Record<string,unknown>
 expect(webhook).not.toHaveProperty('secret')
 expect(webhook).not.toHaveProperty('basic_auth_password')
 expect(JSON.stringify(state)).not.toContain('DO_NOT_STORE')
})
it('returns disabled real external functionality without a privileged session',()=>{
 expect(additionalRead(state,'/user/settings/web-push')).toMatchObject({enabled:false})
 expect(additionalWrite(state,'post','/user/settings/totp/enable',{}))
  .toMatchObject({demo_only:true})
 expect(additionalRead(state,'/unknown/secret/provider')).toBe(UNHANDLED)
 expect(additionalWrite(state,'post','/unknown/secret/provider',{access_token:'x'})).toBe(UNHANDLED)
})
