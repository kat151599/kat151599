# CC58 — native Vue / Vikunja browser-only portfolio demo (development branch)

**Product owner requirement, 2026-10-29:** publish the **ENTIRE existing customized Vikunja frontend**, not a rewritten dashboard. Preserve original Vue screens, navigation, original project routes, project-scoped list / kanban / table / gantt, all modules and Call Center. Only change sign-in to automatic demonstration **admin UI identity** and save visitor changes inside that visitor's browser. The existing production Vikunja, real tokens, DB, integrations and callers MUST NOT be reachable by anonymous visitors.

## Status

**SOURCE IMPLEMENTATION IN PROGRESS / NOT PUBLICLY DEPLOYED / DO NOT CLAIM FULL FUNCTIONAL PARITY.** This branch is not the existing published CC58P01 fake admin panel. Original DEV baseline pinned at `5025a6d57d9c0c05757e4dbe4823d3fac782905c`; production/default branches unchanged.

### Implemented on this branch

- The **real** original `src/components/home/Navigation.vue`, `RootProjectsNavigation.vue`, `views/project/ListProjects.vue`, `views/project/ProjectView.vue`, `ProjectList.vue`, `ProjectTable.vue`, `ProjectKanban.vue`, `views/callcenter/CallCenterView.vue` and `CallCenterDialer.vue` are used **unchanged**.
- Build-time `VITE_CC58_NATIVE_DEMO=1` is only for a separate public demo build. The normal source's behavior stays unchanged when the flag is absent.
- `src/stores/auth.ts`: no login UI required in demo build, sets a **fictional** `isAdmin` identity inside Pinia, **not** a real server admin account or JWT.
- `src/helpers/fetcher.ts` uses `portfolioDemo/adapter.ts` only in demo build; HTTPFactory never forwards any Ajax request, and unknown/foreign URLs are rejected.
- `portfolioDemo/seed.ts`: fictional projects, actual Vikunja views, project tasks, buckets, fake users/teams/leads.
- `portfolioDemo/adapter.ts`: initial demo API facade with browser-only localStorage state namespaced as `cc58:v1:native-vue:fictional-state`, supports key project/task/callcenter reads and some mutations, declines unimplemented routes rather than silently returning successful writes. Local dialer actions are simulations only, not telephone calls.
- Demo build uses hash routing to support native deep links within existing static path; normal web-history routing remains unchanged.
- Demo build suppresses Vikunja PWA/service-worker generation and registration on shared portfolio origin. Adds demo-only Content-Security-Policy forbidding outbound `connect-src`, workers, media, third-party frames and forms.
- Test source `adapter.test.ts` covers original-shaped project task/views, Call Center synthetic data, browser-only persistence, and API escape denial.

### NOT YET satisfied / safety blockers

1. Full native frontend build has not been run. Baseline frontend's `vue-tsc` had 1453 diagnostics; must independently validate Vite build and the new demo source via `pnpm vite build --mode portfolio-demo` on isolated Windows staging.
2. The mock adapter **does not implement every API route** used across 66+ frontend services. Some routes/views currently return 404, so do NOT claim all native modules work. Need comprehensive endpoint inventory, complete visitor-visible mock behavior and tests for projects, mail, CRM, integrations, Call Center, admin settings, data export, upload and error paths.
3. Real-browser integration not tested: sidebar, project navigation, tasks and Call Center, refresh local state, responsive behavior, CSP and actual external-network absence.
4. The original `index.html` embeds a normal API URL. The demo Vite transform removes that script and injects a no-network CSP; verify this in actual build output.
5. The public site under `portfolio.solair.vip` currently still shows the **incorrect old custom HTML mock** at `/demos/clientcircuit-admin/`. Do not overwrite or silently describe it as native Vikunja. Real native demo must replace it only after safety and functionality testing.
6. Need browser-only storage quota handling, wipe/reset separate demo state, separate visitor isolation and a documented offline experience. Never store real customer personal data, API credentials or production session tokens in this mock.
7. Public deployment must be a static isolated bundle under portfolio path or a separately access-controlled domain; **never** publish the original administrative Go server, normal admin JWT, live provider SIP credentials or production DB. Existing Caddy/CC57/other apps must remain unchanged.
8. Respect upstream Vikunja frontend AGPL-3.0-or-later license and provide source + notices for public compiled artifact.

## BLOCK-DRIVEN DEVELOPMENT

The owner does not want 10 small source/test launchers. Finish a meaningful **single** native Vue functional block, test automatically, then give ONE pinned launcher that safely builds and publishes and verifies both UI and security. No source-only or individual test run should be represented as acceptance.

## Technical interpretation of 'auto login as admin'

The admin role belongs only to a fake browser-local UI user. A public site **must not issue a real admin credential**. Real admin privileges in the frontend are safe only because the demo's isolated HTTP transport has no production backend to contact. The UX may show all menus; external effects (calls, mail, actual CRM updates and integrations) must be local, fictional simulations.

## Technical interpretation of 'save only in browser cache'

Use namespaced localStorage or IndexedDB as a local database, not an HTTP caching proxy, and never send visitor writes to a real API. Persistence is per browser/profile/origin, not shared between visitors. The UI should keep normal buttons, task moves and edit forms, routing those actions to this local store. Unsupported operations currently fail closed until implemented.

## CC58P03 development checkpoint — 2026-10-30 (source, not release)

The original Vue components remain byte-identical to baseline, including Navigation.vue, RootProjectsNavigation.vue, ListProjects.vue, ProjectView.vue, ProjectKanban.vue, CallCenterView.vue and CallCenterDialer.vue (verified by GitHub blob SHA comparisons). No mock HTML/CSS replacement was made.

Added `features.ts` covering synthetic browser-only mailbox (inbox/sent), CRM campaigns/prospects/calls, client profile/custom fields/history, Wialon configuration/status with forced blank API URL, Google Calendar status/settings, user/task board, admin overview/users, time tracking and groups. These simulate local effects, NEVER external calls.

Added `coreExtras.ts` covering native project view CRUD, project/task duplication, task comments, task assignees and labels, team and user membership, saved filters, project folders, and task position; original Kanban drag/drop uses a local TaskBucketService-compatible path. Creating and duplicating projects now provisions their Kanban buckets.

Prevented original auth logout from clearing **all** localStorage keys on `portfolio.solair.vip`, suppresses adoption of any previously stored real JWT by the demo build, and suppresses storing `API_URL` at the shared origin. Regular production code paths retain their original semantics. Native avatar requests now receive a locally generated SVG Blob and do not access a remote service.

Build-only changes: Vite demo mode switches to hash routing to avoid Caddy rewrite, enforces CSP `connect-src 'none'`, skips PWA/service worker, skips Sentry uploads and editor DevTools plugins. All original screens still imported by Vue.

Added Vitest test sources: `adapter.test.ts`, `features.test.ts`, `coreExtras.test.ts`; Playwright source `tests/e2e/cc58-native-portfolio.spec.ts` checks the **actual** Vue sidebar, original project view, Call Center and no external API. These tests have **NOT yet passed in a real Windows or CI runtime**. GitHub Actions previous job stopped before any steps; manual-only CI exists but its fresh updated checks have not run. DO NOT record a PASS, publish, or hand out runtime launcher yet.

### Known remaining scope / functional parity work

The source now supports core project/task and a substantial number of secondary routes, but does not implement ALL services across the original frontend. Unsupported routes deliberately reject with a synthetic 404 rather than silently succeeding. In particular, some real application integrations and file attachments, and various advanced admin/settings flows need end-to-end local browser implementations or explicit simulated behavior. Performing a native Vite build plus browser integration tests is mandatory before public replacement. Never load real customer data into a portfolio fixture.

**AGPL:** the original Vikunja frontend declares `AGPL-3.0-or-later`; a public compiled demonstration must provide the corresponding complete source and license notices to visitors. This repo is currently **private**. Prepare a sanitized, reproducible public source release of the demo frontend and its modifications (excluding private secrets and non-demo data) together with the deployed bundle.

Existing wrong public CC58P01 static admin demo remains in site until safe replacement; public GitHub `kat151599/kat151599`, shared Caddy, original DEV and SERV production were NOT modified during CC58P03 source work.

## CC58P04 continuation — browser-local file support and native fixture repairs

- Retained original Vue navigation, project Kanban, and Call Center component byte hashes.
- Repaired original `ProjectViewModel` fixture contract: `filter` is singular (not the previously invented `filters`). Created project views use the same property.
- `initialBrowserDemoData()` now creates independent `structuredClone` fixtures; tests, multiple demo sessions and browser resets no longer mutate module-level defaults.
- Patched **demo-only** Vite transform of `main.ts` so the native static build does not delete another application’s `API_URL` key from the shared `portfolio.solair.vip` origin; original `main.ts` is unchanged.
- Added `browserFiles.ts` to support task and mailbox attachments and client proposals as local-only small files, with genuine Blob downloads and filenames; all bytes are stored only in namespaced synthetic browser state. 512 KiB **per-file** upper bound limits localStorage quota. Failure of the final localStorage write is reported as HTTP 507, never as a successful remote upload. No real attachment backend or provider is contacted.
- Added `seed.test.ts`, `browserFiles.test.ts` to the Vitest command; tests of fixture independence, original view property, browser-local attachment roundtrip and quota rejection. These are **test source**, not actual passing results.
- Native branch source pin at this checkpoint: `cb7773b263a0b12d7a8021a39945ec1a2c15dc9d`. Original DEV/production untouched; public portfolio still has previous incorrect stand-in.

### Outstanding
Native Vite binary build, Vitest and Playwright real browser check remain **NOT EXECUTED** because previously observed hosted CI job failed before any steps. This is a hard release gate. Some advanced routes still unsupported (fail closed) and user visible behavior not yet demonstrated. Browser attachment support is bounded by local storage, not identical to unlimited server-backed uploads. Full-page screenshot/visual comparison with owner's original Vikunja remains pending. Do not call this complete, do not publish built assets or issue live administrator credentials. Existing public static stand-in must be replaced only by tested original Vue bundle.

## CC58P05 — functional source extension (2026-10-30)

The original Vue modules remain unchanged. A source-level audit reviewed 62 original Vikunja frontend service modules, and the browser-only transport was expanded rather than inventing a new dashboard. All additions are under explicit `VITE_CC58_NATIVE_DEMO=1`; production clients do not use this adapter.

- `callCenterDemo.ts`: original `CallCenterView.vue` and `CallCenterDialer.vue` contracts: lead CRUD, real-shaped history events, fictional call records, callback scheduling, conversions, import, dialer batches and local outcome resolution. Real calls and external APIs are never made.
- Native fake admin now has `defaultProjectId=100`, backed by a fictional **Inbox** project with real project views and Kanban buckets, so the Call Center's existing callback action can create tasks through the original v2 service. Original project's task creation places tasks in that project's own first bucket.
- `additionalRoutes.ts`: original Vue user general settings, checklists, task relations/reactions, link-share local previews, webhook settings (without secrets), API-token demo placeholders, TOTP/web-push disabled simulations, project read-status and other secondary service endpoints. No real admin JWT, shared link, token, webhook, password change, telephony, email or push.
- `browserFiles.ts` additionally supports original project background uploads and Blob reads/removal as local-only small files, still bounded by browser storage.
- The native Axios adapter now correctly incorporates `config.params` (original `AbstractService` filtering/search/pagination) in addition to query parameters in the request URL; before this fix the user-facing search silently returned unfiltered items.
- Tests added for all these contracts: `callCenterDemo.test.ts`, `additionalRoutes.test.ts`, and regression extensions to `adapter.test.ts` and `browserFiles.test.ts`. These tests remain **unexecuted**, not PASS. Test suite is prepared for genuine Windows/SERV Vite/Vitest/Playwright acceptance.
- The demo-only Vite `main.ts` transform now correctly normalizes single Windows path separators, preserving unrelated `API_URL` localStorage keys on the shared portfolio origin.

**Release remains denied.** This checkpoint is still source, not a verified running native Vue build. Hosted CI previously failed before steps. The public `portfolio.solair.vip` demo still uses the former incorrect standalone HTML mock; it has NOT been replaced in this block. The owner requested single block-based acceptance only after a complete tested native frontend, and no new owner-run command has been issued. Do not claim all 62 service modules are fully supported until a dynamic route-coverage and browser matrix prove it. Some URLs intentionally fail closed rather than masquerading as working operations.
