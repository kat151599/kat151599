import {expect,it} from 'vitest'
import {initialBrowserDemoData} from './seed'

it('creates independent visitor fixtures for every new browser session', () => {
  const first=initialBrowserDemoData()
  const second=initialBrowserDemoData()
  const originalTitle=second.projects[0].title
  first.projects[0].title='Local project changed'
  first.tasks[0].title='Local task changed'
  first.leads[0].notes='Local note'
  expect(second.projects[0].title).toBe(originalTitle)
  expect(second.tasks[0].title).not.toBe('Local task changed')
  expect(second.leads[0].notes).not.toBe('Local note')
})

it('provides the original ProjectViewModel filter property, not filters', () => {
  const state=initialBrowserDemoData()
  for (const project of state.projects) {
    expect(project.views.map(view=>view.view_kind)).toEqual(['list','kanban','table','gantt'])
    for (const view of project.views) {
      expect(view).toHaveProperty('filter')
      expect(view).not.toHaveProperty('filters')
    }
  }
})

it('seeds correct Kanban buckets and matching project task relationships', () => {
  const state=initialBrowserDemoData()
  for (const project of state.projects) {
    const buckets=state.buckets.filter(bucket=>bucket.project_id===project.id)
    expect(buckets).toHaveLength(3)
    const ids=new Set(buckets.map(b=>b.id))
    expect(state.tasks.filter(task=>task.project_id===project.id)
      .every(task=>ids.has(task.bucket_id))).toBe(true)
  }
})
