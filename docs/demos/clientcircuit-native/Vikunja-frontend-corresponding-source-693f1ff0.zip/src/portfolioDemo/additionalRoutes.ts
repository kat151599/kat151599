/**
 * Additional ORIGINAL Vikunja HTTP service endpoints in safe public DEMO mode.
 * No real session, passwords, share links, webhooks, email or network provider.
 * Real Vue components use these exact JSON shapes with browser-local data.
 */
import type {BrowserDemoState} from './seed'
import {UNHANDLED} from './features'
type Row=Record<string,unknown>
const now=()=>new Date().toISOString()
const duplicate=<T>(value:T):T=>JSON.parse(JSON.stringify(value)) as T
function rows(state:BrowserDemoState,key:string):Row[] {
 const value=state.extra['additional:'+key]
 return Array.isArray(value)?value as Row[]:[]
}
function saveRows(state:BrowserDemoState,key:string,value:Row[]):void {
 state.extra['additional:'+key]=value
}
function next(rows:Row[]):number {
 return Math.max(0,...rows.map(x=>Number(x.id)||0))+1
}
function handleCollection(state:BrowserDemoState,method:string,path:string,base:string,key:string,input:Row):unknown {
 const entries=rows(state,key)
 if(path===base&&['post','put'].includes(method)){
  const id=next(entries),stamp=now()
  const record={...input,id,created:stamp,updated:stamp}
  entries.push(record);saveRows(state,key,entries);return record
 }
 const suffix=path.startsWith(base+'/')?path.slice(base.length+1):''
 if(!/^\d+$/.test(suffix))return UNHANDLED
 const i=entries.findIndex(x=>Number(x.id)===Number(suffix))
 if(i<0)return UNHANDLED
 if(method==='delete'){
  entries.splice(i,1);saveRows(state,key,entries);return {}
 }
 const updated={...entries[i],...input,id:Number(suffix),updated:now()}
 entries[i]=updated;saveRows(state,key,entries)
 return updated
}
function checklist(state:BrowserDemoState,id:number):Row {
 const task=state.tasks.find(x=>x.id===id)
 const items=rows(state,'checklist-'+id)
 return {items,total:items.length,completed:items.filter(x=>x.done).length,
  task_done:!!task?.done,task_done_at:task?.done_at??null}
}
function reactions(state:BrowserDemoState,key:string):Row {
 return rows(state,'reactions-'+key).reduce((acc,row)=>{
  const emoji=String(row.emoji),users=acc[emoji] as Row[]|undefined
  acc[emoji]=[...(users??[]),state.users[0]]
  return acc
 },{} as Row)
}
export function additionalRead(state:BrowserDemoState,path:string):unknown {
 if(path==='/user/settings/general')return state.settings
 if(path==='/user/settings/web-push')return {enabled:false,public_key:''}
 if(path==='/user/settings/totp')return {enabled:false,secret:'',url:'',qrcode:''}
 if(path==='/user/settings/avatar')return {avatar_provider:'initials'}
 if(path==='/user/settings/email')return {email:'admin@example.invalid'}
 if(path==='/user/settings/token/caldav')return []
 if(path==='/tokens')return rows(state,'api-tokens')
 if(path==='/routes')return []
 if(path==='/user/bots')return rows(state,'bot-users')
 if(path==='/backgrounds/unsplash/search')return []
 if(path==='/webhooks/events'||path==='/user/settings/webhooks/events')return [
  'task.created','task.updated','task.deleted','project.created','project.updated'
 ]
 const share=path.match(/^\/projects\/(\d+)\/shares(?:\/(\d+))?$/)
 if(share){
  const key='shares-'+share[1],data=rows(state,key)
  return share[2]?data.find(x=>Number(x.id)===Number(share[2]))??UNHANDLED:data
 }
 const hooks=path.match(/^\/projects\/(\d+)\/webhooks(?:\/(\d+))?$/)
 if(hooks){
  const data=rows(state,'webhooks-project-'+hooks[1])
  return hooks[2]?data.find(x=>Number(x.id)===Number(hooks[2]))??UNHANDLED:data
 }
 const userHooks=path.match(/^\/user\/settings\/webhooks(?:\/(\d+))?$/)
 if(userHooks){
  const data=rows(state,'webhooks-user')
  return userHooks[1]?data.find(x=>Number(x.id)===Number(userHooks[1]))??UNHANDLED:data
 }
 const check=path.match(/^\/tasks\/(\d+)\/checklist-items(?:\/(\d+))?$/)
 if(check){
  const result=checklist(state,Number(check[1]))
  if(!check[2])return result
  return (result.items as Row[]).find(x=>Number(x.id)===Number(check[2]))??UNHANDLED
 }
 const rel=path.match(/^\/tasks\/(\d+)\/relations$/)
 if(rel)return rows(state,'relations-'+rel[1])
 const react=path.match(/^\/(tasks|projects|comments)\/(\d+)\/reactions$/)
 if(react)return reactions(state,react[1]+'-'+react[2])
 if(/^\/projects\/\d+\/background$/.test(path))return UNHANDLED
 const readable=path.match(/^\/tasks\/(\d+)\/read$/)
 if(readable)return {task_id:Number(readable[1]),is_unread:false}
 return UNHANDLED
}
export function additionalWrite(state:BrowserDemoState,method:string,path:string,input:Row):unknown {
 if(path==='/user/settings/general'&&['post','put','patch'].includes(method)){
  const nextSettings={...state.settings,...input}
  // Never store secrets or credentials even as accidental Vue form fields.
  for(const key of ['password','token','access_token','refresh_token','secret']){
   delete (nextSettings as Row)[key]
  }
  state.settings=nextSettings
  return nextSettings
 }
 if(path==='/user/settings/email')return {email:'admin@example.invalid',demo_only:true}
 if(path==='/user/password'||path.startsWith('/user/deletion/'))return {
  demo_only:true,notice:'This public demo never changes a real account.'
 }
 if(path==='/user/settings/totp/enroll'||path==='/user/settings/totp/enable'
    ||path==='/user/settings/totp/disable')return {enabled:false,demo_only:true}
 if(path==='/user/settings/avatar/upload'||path==='/user/settings/avatar')return {
  avatar_provider:'initials',demo_only:true
 }
 if(path==='/user/settings/web-push')return {
  enabled:false,public_key:'',demo_only:true
 }
 const check=path.match(/^\/tasks\/(\d+)\/checklist-items(?:\/(\d+))?$/)
 if(check){
  const id=Number(check[1])
  if(!state.tasks.some(t=>t.id===id))return UNHANDLED
  const key='checklist-'+id
  const current=rows(state,key)
  if(!check[2]&&method==='post'){
   const item={id:next(current),task_id:id,title:String(input.title||'Пункт'),
    done:false,completed_by:null,completed_at:null,position:current.length+1,
    created:now(),updated:now()}
   current.push(item);saveRows(state,key,current)
   return checklist(state,id)
  }
  const i=current.findIndex(x=>Number(x.id)===Number(check[2]))
  if(i<0)return UNHANDLED
  if(method==='delete')current.splice(i,1)
  else current[i]={...current[i],...input,id:Number(check[2]),
   completed_by:input.done?state.users[0]:null,
   completed_at:input.done?now():null,updated:now()}
  saveRows(state,key,current)
  return checklist(state,id)
 }
 const rel=path.match(/^\/tasks\/(\d+)\/relations(?:\/([^/]+)\/(\d+))?$/)
 if(rel){
  const taskId=Number(rel[1]),target=Number(rel[3]||input.other_task_id)
  if(!state.tasks.some(t=>t.id===taskId)||!state.tasks.some(t=>t.id===target))return UNHANDLED
  const key='relations-'+taskId,collection=rows(state,key)
  if(method==='delete'){
   const i=collection.findIndex(x=>x.other_task_id===target&&x.relation_kind===rel[2])
   if(i<0)return UNHANDLED
   collection.splice(i,1);saveRows(state,key,collection);return {}
  }
  const relation={id:next(collection),task_id:taskId,other_task_id:target,
   relation_kind:String(input.relation_kind||'related'),created_by:state.users[0],created:now()}
  collection.push(relation);saveRows(state,key,collection);return relation
 }
 const react=path.match(/^\/(tasks|projects|comments)\/(\d+)\/reactions(?:\/delete)?$/)
 if(react){
  const key='reactions-'+react[1]+'-'+react[2],entries=rows(state,key)
  const emoji=String(input.value||input.emoji||'👍')
  const i=entries.findIndex(x=>x.emoji===emoji)
  if(method==='delete'||path.endsWith('/delete')){
   if(i>=0)entries.splice(i,1)
  }else if(i<0)entries.push({emoji})
  saveRows(state,key,entries);return reactions(state,react[1]+'-'+react[2])
 }
 const share=path.match(/^\/projects\/(\d+)\/shares(?:\/(\d+))?$/)
 if(share){
  const key='shares-'+share[1]
  if(!share[2]&&['post','put'].includes(method)){
   const entries=rows(state,key),id=next(entries),record={
    id,project_id:Number(share[1]),name:String(input.name||'Демо-ссылка'),
    permission:Number(input.permission)||0,sharing_type:1,
    shared_by:state.users[0],hash:'demo-browser-local-'+id,
    created:now(),updated:now(),password:''}
   entries.push(record);saveRows(state,key,entries);return record
  }
  return handleCollection(state,method,path,'/projects/'+share[1]+'/shares',key,input)
 }
 const webhook=path.match(/^\/projects\/(\d+)\/webhooks(?:\/(\d+))?$/)
 if(webhook){
  const key='webhooks-project-'+webhook[1],base='/projects/'+webhook[1]+'/webhooks'
  const cleaned=duplicate(input)
  delete cleaned.secret;delete cleaned.basic_auth_password
  return handleCollection(state,method,path,base,key,cleaned)
 }
 const userWebhook=path.match(/^\/user\/settings\/webhooks(?:\/(\d+))?$/)
 if(userWebhook){
  const cleaned=duplicate(input)
  delete cleaned.secret;delete cleaned.basic_auth_password
  return handleCollection(state,method,path,'/user/settings/webhooks','webhooks-user',cleaned)
 }
 const tasks=path.match(/^\/tasks\/(\d+)\/read$/)
 if(tasks&&['post','put','patch'].includes(method)){
  const id=Number(tasks[1]),task=state.tasks.find(t=>t.id===id)
  if(!task)return UNHANDLED
  return {task_id:id,is_unread:false}
 }
 if(path==='/tokens'&&['post','put'].includes(method)){
  const data=rows(state,'api-tokens'),id=next(data)
  const row={id,title:String(input.title||'Демо-токен'),created:now(),
   expires_at:null,last_seen:null,permissions:[]}
  data.push(row);saveRows(state,'api-tokens',data)
  return {id,token:'DEMO_LOCAL_ONLY_NOT_A_CREDENTIAL',...row}
 }
 const token=path.match(/^\/tokens\/(\d+)$/)
 if(token&&method==='delete'){
  return handleCollection(state,method,path,'/tokens','api-tokens',{})
 }
 return UNHANDLED
}
