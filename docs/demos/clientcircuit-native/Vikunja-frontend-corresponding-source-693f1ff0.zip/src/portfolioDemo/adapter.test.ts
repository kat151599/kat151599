import {beforeEach, expect, it, vi} from 'vitest'
import axios from 'axios'
import {nativePortfolioDemoAdapter,resetPortfolioDemoMemoryForTests} from './adapter'

const http=axios.create({baseURL:'/api/v1/',adapter:nativePortfolioDemoAdapter})
beforeEach(()=>resetPortfolioDemoMemoryForTests(true))
it('exposes fictional administrator configuration without network',async()=>{
 const request=vi.fn(()=>{throw new Error('NETWORK_UNEXPECTED')})
 vi.stubGlobal('fetch',request)
 const r=await http.get('info')
 expect(r.data.version).toBe('CC58-local-synthetic')
 expect(r.data.enabled_pro_features).toContain('admin_panel')
 expect(request).not.toHaveBeenCalled()
 vi.unstubAllGlobals()
})
it('renders native-shaped projects with their own views and tasks',async()=>{
 const projects=(await http.get('/projects')).data
 expect(projects.length).toBeGreaterThanOrEqual(4)
 const id=projects[0].id
 const views=(await http.get('/projects/'+id+'/views')).data
 expect(views.map((v:{view_kind:string})=>v.view_kind)).toEqual(['list','kanban','table','gantt'])
 const tasks=(await http.get('/projects/'+id+'/tasks')).data
 expect(tasks.length).toBeGreaterThan(0)
 const kanban=views.find((v:{view_kind:string})=>v.view_kind==='kanban')
 const buckets=(await http.get('/projects/'+id+'/views/'+kanban.id+'/tasks')).data
 expect(buckets.length).toBeGreaterThan(0)
 expect(buckets.every((b:{tasks:unknown[];project_view_id:number})=>Array.isArray(b.tasks)&&b.project_view_id===kanban.id)).toBe(true)
 expect(buckets.flatMap((b:{tasks:unknown[]})=>b.tasks).length).toBe(tasks.length)
 expect(tasks.some((t:{project_view_id?:number})=>t.project_view_id!==undefined)).toBe(false)
})
it('preserves user edits in namespaced browser-only storage',async()=>{
 const foreign='CC58_other_service_state'
 localStorage.setItem(foreign,'DO_NOT_TOUCH')
 const task=(await http.get('/tasks/1001')).data
 const updated=await http.post('/tasks/1001',{title:'Изменено в моём браузере'})
 expect(updated.data.title).toBe('Изменено в моём браузере')
 const saved=localStorage.getItem('cc58:v1:native-vue:fictional-state')
 expect(saved).toContain('Изменено в моём браузере')
 resetPortfolioDemoMemoryForTests()
 const afterReload=(await http.get('/tasks/1001')).data
 expect(afterReload.title).toBe('Изменено в моём браузере')
 expect(localStorage.getItem(foreign)).toBe('DO_NOT_TOUCH')
 await http.post('/tasks/1001',{title:task.title})
 localStorage.removeItem(foreign)
})
it('moves a task across original project Kanban buckets and keeps it after refresh',async()=>{
 const projectId=101,viewId=1012,taskId=1001
 const r=await http.post('/projects/'+projectId+'/views/'+viewId+'/buckets/10102/tasks',
  {task_id:taskId,position:2})
 expect(r.data).toMatchObject({project_id:101,bucket_id:10102,task_id:1001})
 const task=(await http.get('/tasks/'+taskId)).data
 expect(task.bucket_id).toBe(10102)
 const buckets=(await http.get('/projects/'+projectId+'/views/'+viewId+'/tasks')).data
 expect(buckets.find((b:{id:number})=>b.id===10102).tasks.some((t:{id:number})=>t.id===taskId)).toBe(true)
})
it('creates a new real Vue project with a functioning native Kanban view',async()=>{
 const result=await http.put('/projects',{title:'Новый проект'})
 const p=result.data
 const buckets=(await http.get('/projects/'+p.id+'/views/'+(p.id*10+2)+'/tasks')).data
 expect(buckets.map((b:{title:string})=>b.title)).toEqual(['Новые','В работе','Готово'])
})
it('schedules a fictional Call Center callback in the native Inbox project',async()=>{
 const project=(await http.get('/projects/100')).data
 expect(project.title).toBe('Inbox')
 const result=await http.post('/api/v2/projects/100/tasks',{
  title:'Перезвонить: тестовый клиент',description:'Локальный пример',
  due_date:'2026-11-12T09:00:00Z'
 })
 expect(result.data).toMatchObject({project_id:100,bucket_id:10001})
 const tasks=(await http.get('/projects/100/tasks')).data
 expect(tasks.some((t:{id:number})=>t.id===result.data.id)).toBe(true)
})
it('uses original AbstractService axios params for filtering project-scoped tasks',async()=>{
 const original=(await http.get('/projects/101/tasks')).data
 const viaParams=(await http.get('/projects/101/tasks',{params:{s:'интерфейс'}})).data
 expect(viaParams.length).toBeLessThan(original.length)
 expect(viaParams.every((t:{title:string})=>t.title.toLowerCase().includes('интерфейс'))).toBe(true)
})
it('opens original Call Center data with no telephone contact details',async()=>{
 const leads=(await http.get('/callcenter/leads')).data
 expect(leads.length).toBeGreaterThan(0)
 expect(leads.every((l:{phone:null,email:null})=>!l.phone&&!l.email)).toBe(true)
 const snapshot=(await http.get('/callcenter/leads/'+leads[0].id+'/history-snapshot')).data
 expect(snapshot.lead.id).toBe(leads[0].id)
 const dialer=(await http.get('/callcenter/dialer')).data
 expect(dialer.batch).toBe(null)
})
it('denies backend escape, foreign origin and unknown endpoints',async()=>{
 for(const url of ['https://real-api.example.invalid/api/v1/user',
  '/api/v1/SECRET_ENDPOINT','//external.example.invalid/api/v1/projects']){
  await expect(http.get(url)).rejects.toMatchObject({isAxiosError:true})
 }
})
it('does not simulate unimplemented mutation as successfully saved',async()=>{
 await expect(http.post('/api/v1/admin/danger',{})).rejects.toMatchObject({isAxiosError:true})
})
