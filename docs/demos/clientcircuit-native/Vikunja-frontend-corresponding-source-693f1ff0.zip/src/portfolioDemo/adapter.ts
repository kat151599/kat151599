/**
 * Native Vue browser-only DEMO transport, used ONLY when VITE_CC58_NATIVE_DEMO=1.
 *
 * Every axios request is resolved in memory. Never forwards, proxies or retries
 * to production. Mutations persist to a namespaced per-browser localStorage.
 * No REAL admin account, JWT, customer, dialer or backend is involved.
 */
import type {AxiosAdapter, AxiosResponse, InternalAxiosRequestConfig} from 'axios'
import {fictionalAdmin, initialBrowserDemoData, type BrowserDemoState} from './seed'
import {featureRead, featureWrite, UNHANDLED} from './features'
import {coreRead, coreWrite} from './coreExtras'
import {demoFileRead, demoFileWrite, demoConvertInput} from './browserFiles'
import {readCallCenter, writeCallCenter} from './callCenterDemo'
import {additionalRead, additionalWrite} from './additionalRoutes'

const STORAGE_KEY = 'cc58:v1:native-vue:fictional-state'
let cached: BrowserDemoState | null = null
function clone<T>(value: T): T { return JSON.parse(JSON.stringify(value)) as T }
function load(): BrowserDemoState {
 if(cached)return cached
 try {
  const raw=window.localStorage.getItem(STORAGE_KEY)
  if(raw) {
   const state=JSON.parse(raw) as BrowserDemoState
   if(state.version===1 && Array.isArray(state.projects) && Array.isArray(state.tasks)
      && Array.isArray(state.leads) && Array.isArray(state.buckets)) {
    cached=state
    return state
   }
  }
 }catch { /* corrupt or denied storage: initialize fictional data in memory */ }
 cached=clone(initialBrowserDemoData())
 return cached
}
/** Internal regression utility; not referenced by the production Vue application. */
export function resetPortfolioDemoMemoryForTests(clearLocalStorage=false): void {
 cached=null
 if(clearLocalStorage) window.localStorage.removeItem(STORAGE_KEY)
}
function persist(state: BrowserDemoState): void {
 // Do not return success on a storage failure. A page reload must not lose
 // changes while the UI falsely claims they were saved.
 const serialized=JSON.stringify(state)
 window.localStorage.setItem(STORAGE_KEY,serialized)
 cached=state
}
function response(config: InternalAxiosRequestConfig,data:unknown,status=200):AxiosResponse {
 return {data, status, statusText:status===200?'OK':status===201?'Created':'Demo response',
  headers: {'x-pagination-result-count':String(Array.isArray(data)?data.length:1),
   'x-pagination-total-pages':'1','x-max-permission':'2'} as AxiosResponse['headers'],
  config}
}
function fail(config:InternalAxiosRequestConfig,status:number,message:string):Promise<AxiosResponse> {
 return Promise.reject({isAxiosError:true,name:'AxiosError',code:'ERR_BAD_RESPONSE',
  message:'Portfolio DEMO: '+message,config,
  response:response(config,{message:'Portfolio DEMO: '+message,code:status},status)})
}
function parseInput(value:unknown):Record<string,unknown> {
 if(!value)return {}
 if(typeof value==='string') {
  try {const parsed=JSON.parse(value);return parsed&&typeof parsed==='object'?parsed:{}}
  catch{return {}}
 }
 return typeof value==='object'?clone(value as Record<string,unknown>):{}
}
function asNum(value:string|undefined){return Number(value||0)}
function now(){return new Date().toISOString()}
function numberId(items: Array<{id:number}>):number{
 return Math.max(100,...items.map(x=>Number(x.id)||0))+1
}
function listQuery(items:Array<Record<string,unknown>>,params:URLSearchParams) {
 const search=(params.get('s')||'').toLowerCase().trim()
 const projectId=asNum(params.get('project_id')||undefined)
 let result=search?items.filter(i=>JSON.stringify(i).toLowerCase().includes(search)):items
 if(projectId)result=result.filter(i=>Number(i.project_id)===projectId)
 return result.map(x=>clone(x))
}
function extraGet(state:BrowserDemoState,path:string) {
 const val=state.extra[path]
 if(val!==undefined)return clone(val)
 return null
}
function checkURL(config:InternalAxiosRequestConfig):{path:string;query:URLSearchParams}|null {
 let url=config.url||''
 // axios's baseURL is /api/v1 and its normal URLs are "/projects" or "user".
 if(url.startsWith('//'))return null
 if(/^https?:\/\//i.test(url)) {
  const parsed=new URL(url)
  if(parsed.origin!==window.location.origin || !/^\/api\/v[12]\//.test(parsed.pathname))return null
  url=parsed.pathname+parsed.search
 }else if(!url.startsWith('/api/v1/')&&!url.startsWith('/api/v2/')){
  url='/api/v1/'+url.replace(/^\//,'')
 }
 const parsed=new URL(url,window.location.origin)
 if(parsed.origin!==window.location.origin)return null
 const path=parsed.pathname.replace(/^\/api\/v[12]/,'')
 if(!path.startsWith('/')||path.includes('..')||path.includes('//')||path.includes('\\'))return null
 // Original AbstractService passes filters/pagination using axios config.params,
 // not only URL-embedded query strings. Preserve native Vue behavior here.
 const query=new URLSearchParams(parsed.search)
 const extra=config.params as Record<string,unknown>|URLSearchParams|undefined
 if(extra instanceof URLSearchParams){
  extra.forEach((value,key)=>query.append(key,value))
 }else if(extra&&typeof extra==='object'){
  for(const [key,value] of Object.entries(extra)){
   if(value===null||value===undefined)continue
   if(Array.isArray(value)){
    for(const item of value)if(item!==null&&item!==undefined)query.append(key,String(item))
   }else query.set(key,String(value))
  }
 }
 return {path,query}
}
function read(state:BrowserDemoState,path:string,query:URLSearchParams):unknown {
 const extra=additionalRead(state,path)
 if(extra!==UNHANDLED)return extra
 const cc=readCallCenter(state,path)
 if(cc!==UNHANDLED)return cc
 const localFile=demoFileRead(state,path)
 if(localFile!==UNHANDLED)return localFile
 const core=coreRead(state,path)
 if(core!==UNHANDLED)return core
 const secondary=featureRead(state,path,query)
 if(secondary!==UNHANDLED)return secondary
 if(path==='/info')return {
  version:'CC58-local-synthetic', frontend_url:window.location.origin, motd:'Демонстрация: только данные этого браузера.',
  link_sharing_enabled:true, max_file_size:'20MB', max_items_per_page:250, available_migrators:[],
  task_attachments_enabled:true,totp_enabled:false,enabled_background_providers:[],
  legal:{imprint_url:'',privacy_policy_url:''},caldav_enabled:false,
  user_deletion_enabled:true,task_comments_enabled:true,demo_mode_enabled:false,
  webhooks_enabled:true,auth:{local:{enabled:true,registration_enabled:false},
   ldap:{enabled:false},openid_connect:{enabled:false,redirect_url:'',providers:[]}},
  public_teams_enabled:true,allow_icon_changes:true,
  enabled_pro_features:['admin_panel','time_tracking'],concurrent_writes:false,
 }
 if(path==='/user')return {...fictionalAdmin,settings:state.settings}
 if(path==='/user/settings')return state.settings
 if(/^\/avatar\/[A-Za-z0-9._%-]+$/.test(path)){
  const svg='<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="32" fill="#245a62"/><text x="32" y="41" text-anchor="middle" fill="white" font-family="sans-serif" font-size="24">D</text></svg>'
  return new Blob([svg],{type:'image/svg+xml'})
 }
 if(path==='/access/me')return {permissions:[],groups:[]}
 if(path==='/projects'){
  const items=listQuery(state.projects as unknown as Array<Record<string,unknown>>,query)
  return query.get('expand')==='permissions'?{items}:items
 }
 if(path==='/project-folders')return {folders:state.folders,projects:state.folder_projects}
 if(path==='/projects/favorites')return state.projects.filter(p=>p.is_favorite)
 if(path==='/tasks'||path==='/tasks/my')return listQuery(state.tasks as unknown as Array<Record<string,unknown>>,query)
 if(path==='/teams')return state.teams
 if(path==='/users'||path==='/users/search')return state.users
 if(path==='/labels')return state.labels
 if(path==='/notifications')return []
 if(path==='/mailbox'||path==='/mailbox/messages')return []
 if(path==='/callcenter/leads')return state.leads
 if(path==='/callcenter/dialer')return {batch:state.dialer?.batch??null,empty:!state.dialer?.batch}
 if(path==='/call-center/website-attempts/stats')return {total:2,with_contact:2,without_contact:0}
 if(path==='/admin/access/users')return {users:state.users}
 if(path==='/admin/access/groups')return {groups:[]}
 if(path==='/admin/access/permissions')return {permissions:[]}
 if(path==='/admin/overview')return {users:state.users.length,projects:state.projects.length,
  tasks:state.tasks.length,teams:state.teams.length}
 if(path==='/time-tracking'||path==='/time-entries')return []
 if(path==='/projects/permissions')return []
 const project=path.match(/^\/projects\/(\d+)$/)
 if(project)return state.projects.find(p=>p.id===asNum(project[1]))??null
 const task=path.match(/^\/tasks\/(\d+)$/)
 if(task)return state.tasks.find(t=>t.id===asNum(task[1]))??null
 const views=path.match(/^\/projects\/(\d+)\/views$/)
 if(views)return state.projects.find(p=>p.id===asNum(views[1]))?.views??[]
 const view=path.match(/^\/projects\/(\d+)\/views\/(\d+)$/)
 if(view)return state.projects.find(p=>p.id===asNum(view[1]))?.views.find(v=>v.id===asNum(view[2]))??null
 const projectTasks=path.match(/^\/projects\/(\d+)(?:\/views\/\d+)?\/tasks$/)
 if(projectTasks){
  const projectId=asNum(projectTasks[1])
  const tasks=listQuery(state.tasks.filter(t=>t.project_id===projectId) as unknown as Array<Record<string,unknown>>,query) as unknown as typeof state.tasks
  const viewId=asNum(path.match(/\/views\/(\d+)\/tasks$/)?.[1])
  const view=state.projects.find(p=>p.id===projectId)?.views.find(v=>v.id===viewId)
  if(view?.view_kind==='kanban')return state.buckets.filter(b=>b.project_id===projectId).map(b=>{
   const memberTasks=tasks.filter(t=>t.bucket_id===b.id)
   return {...b,project_view_id:viewId,count:memberTasks.length,tasks:memberTasks}
  })
  return tasks
 }
 const projectBuckets=path.match(/^\/projects\/(\d+)\/views\/(\d+)\/buckets$/)
 if(projectBuckets)return state.buckets.filter(b=>b.project_id===asNum(projectBuckets[1]))
 const lead=path.match(/^\/callcenter\/leads\/([^/]+)$/)
 if(lead)return state.leads.find(l=>l.id===lead[1])??null
 const history=path.match(/^\/callcenter\/leads\/([^/]+)\/(?:history|history-snapshot)$/)
 if(history){
  const l=state.leads.find(x=>x.id===history[1])
  if(!l)return null
  return {lead:l,events:state.history.filter(x=>String((x as Record<string,unknown>).lead_id)===history[1]),calls:[]}
 }
 if(path==='/projects/available')return state.projects
 const added=extraGet(state,path)
 if(added!==null)return added
 return undefined
}
function write(state:BrowserDemoState,method:string,path:string,input:Record<string,unknown>):unknown {
 const extra=additionalWrite(state,method,path,input)
 if(extra!==UNHANDLED)return extra
 const cc=writeCallCenter(state,method,path,input)
 if(cc!==UNHANDLED)return cc
 const update=<T extends {id:number}>(items:T[],id:number):T|undefined=>{
  const index=items.findIndex(i=>i.id===id)
  if(index<0)return undefined
  if(method==='delete'){return items.splice(index,1)[0]}
  items[index]={...items[index],...input,id} as T
  return items[index]
 }
 if(path==='/user/settings'&&(method==='post'||method==='put')){
  state.settings={...state.settings,...input};return state.settings
 }
 if(path==='/projects'&&method==='put'){
  const p={...clone(state.projects[0]),...input,id:numberId(state.projects),views:clone(state.projects[0].views)}
  p.views=([1,2,3,4] as number[]).map((n)=>({
   id:p.id*10+n,project_id:p.id,title:['Список','Канбан','Таблица','Гантт'][n-1],
   view_kind:['list','kanban','table','gantt'][n-1] as 'list'|'kanban'|'table'|'gantt',
   position:n,filter:{sort_by:[],order_by:[],filter:'',filter_include_nulls:true,s:''},
   bucket_configuration:[],bucket_configuration_mode:'manual',
   default_bucket_id:p.id*100+1,done_bucket_id:p.id*100+3
  }))
  state.projects.push(p)
  const titles=['Новые','В работе','Готово']
  for(let n=1;n<=3;n++){
   state.buckets.push({...clone(state.buckets[0]),id:p.id*100+n,
    project_id:p.id,project_view_id:p.id*10+2,title:titles[n-1],
    position:n,tasks:[],count:0})
  }
  return p
 }
 const pid=path.match(/^\/projects\/(\d+)$/)
 if(pid)return update(state.projects,asNum(pid[1]))
  // Original Vue quick-add uses the V2 bulk endpoint, even for one task.
  // All entries are validated before changing the cloned browser-only state.
  const bulkTasks=path.match(/^\/projects\/(\d+)\/tasks\/bulk$/)
  if(bulkTasks&&method==='post'){
   const projectId=asNum(bulkTasks[1])
   const requested=input.tasks
   if(!state.projects.some(project=>project.id===projectId)
      ||!Array.isArray(requested)||requested.length<1||requested.length>100)return undefined
   if(!requested.every(item=>item&&typeof item==='object'&&!Array.isArray(item)
      &&typeof item.title==='string'&&item.title.trim().length>0))return undefined
   const tasks=requested.map((item:Record<string,unknown>)=>{
    const requestedBucket=Number(item.bucket_id)||0
    const allowedBucket=state.buckets.some(b=>b.id===requestedBucket&&b.project_id===projectId)
    const task={...clone(state.tasks[0]),...item,id:numberId(state.tasks),
     title:String(item.title).trim(),project_id:projectId,
     bucket_id:allowedBucket?requestedBucket:projectId*100+1,
     created:now(),updated:now(),created_by:fictionalAdmin}
    state.tasks.push(task)
    return task
   })
   return {tasks}
  }
 const newTask=path.match(/^\/projects\/(\d+)\/tasks$/)
 if(newTask&&(method==='put'||method==='post')){
  const projectId=asNum(newTask[1])
  if(!state.projects.some(p=>p.id===projectId))return undefined
  const t={...clone(state.tasks[0]),...input,id:numberId(state.tasks),project_id:projectId,
   bucket_id:projectId*100+1,created:now(),updated:now(),done:false,
   created_by:fictionalAdmin}
  state.tasks.push(t);return t
 }
 const task=path.match(/^\/tasks\/(\d+)$/)
 if(task)return update(state.tasks,asNum(task[1]))
 const team=path.match(/^\/teams\/(\d+)$/)
 if(team)return update(state.teams,asNum(team[1]))
 if(path==='/teams'&&method==='put'){
  const t={...clone(state.teams[0]),...input,id:numberId(state.teams)}
  state.teams.push(t);return t
 }
 const lead=path.match(/^\/callcenter\/leads\/([^/]+)$/)
 if(lead){
  const index=state.leads.findIndex(x=>x.id===lead[1])
  if(index<0)return undefined
  if(method==='delete')return state.leads.splice(index,1)[0]
  state.leads[index]={...state.leads[index],...input,id:lead[1]}
  return state.leads[index]
 }
 if(path==='/callcenter/leads/import'&&method==='post'){
  const rows=Array.isArray(input.rows)?input.rows:[]
  for(const record of rows) {
   if(!record || typeof record!=='object')continue
   const newRecord={...clone(state.leads[0]),...(record as Record<string,unknown>),
    id:'demo-lead-'+Date.now().toString(36)+'-'+state.leads.length,
    phone:null,email:null,created_at:now(),updated_at:now()}
   state.leads.push(newRecord)
  }
  return {imported:rows.length}
 }
 const convert=path.match(/^\/callcenter\/leads\/([^/]+)\/convert$/)
 if(convert&&method==='post'){
  const lead=state.leads.find(x=>x.id===convert[1])
  if(!lead)return undefined
  lead.status='converted'
  ;(lead as {converted_at: string|null}).converted_at=now()
  return {project_id:lead.vikunja_project_id||102,created:false,lead}
 }
 if(path==='/callcenter/leads'&&method==='post'){
  const id='demo-lead-'+Date.now().toString(36)
  const created={...clone(state.leads[0]),...input,id,created_at:now(),updated_at:now(),
   phone:null,email:null}
  state.leads.push(created);return created
 }
 const folder=path.match(/^\/project-folders\/(\d+)(?:\/rename|\/move)?$/)
 if(folder){
  const id=asNum(folder[1]);const index=state.folders.findIndex(f=>f.id===id)
  if(index<0)return undefined
  if(method==='delete')return state.folders.splice(index,1)[0]
  state.folders[index]={...state.folders[index],...input}
  return state.folders[index]
 }
 const placement=path.match(/^\/projects\/(\d+)\/folder$/)
 if(placement){
  const id=asNum(placement[1])
  state.folder_projects=state.folder_projects.filter(x=>x.project_id!==id)
  const v={project_id:id,folder_id:Number(input.folder_id||0),position:Number(input.position||1)}
  state.folder_projects.push(v);return v
 }
 const addComment=path.match(/^\/tasks\/(\d+)\/comments$/)
 if(addComment&&method==='put'){
  const c={id:Date.now(),task_id:asNum(addComment[1]),comment:String(input.comment||''),
   author:fictionalAdmin,created:now()}
  state.comments.push(c);return c
 }
 const bucketTask=path.match(/^\/projects\/(\d+)\/views\/(\d+)\/buckets\/(\d+)\/tasks$/)
 if(bucketTask&&method==='post'){
  const projectId=Number(bucketTask[1]),viewId=Number(bucketTask[2]),bucketId=Number(bucketTask[3])
  const id=Number(input.task_id||input.taskId)
  const task=state.tasks.find(t=>t.id===id&&t.project_id===projectId)
  const bucket=state.buckets.find(b=>b.id===bucketId&&b.project_id===projectId)
  if(!task||!bucket)return undefined
  task.bucket_id=bucketId
  task.position=Number(input.position)||task.position
  task.done=bucketId===projectId*100+3
  task.updated=now()
  return {task_id:id,bucket_id:bucketId,project_view_id:viewId,
   project_id:projectId,task,bucket:{...bucket,tasks:[]}}
 }
 const bucket=path.match(/^\/projects\/(\d+)\/views\/(\d+)\/buckets(?:\/(\d+))?$/)
 if(bucket){
  if(!bucket[3]&&method==='put'){
   const b={...clone(state.buckets[0]),...input,id:numberId(state.buckets),
    project_id:asNum(bucket[1]),project_view_id:asNum(bucket[2])}
   state.buckets.push(b);return b
  }
  return update(state.buckets,asNum(bucket[3]))
 }
 // Call Center actions deliberately remain local; never dial or schedule real calls.
 if(/^\/callcenter\/leads\/[^/]+\/(?:notes|history|events|calls|scheduled-calls|spam-review)$/.test(path) &&
    ['put','post','patch'].includes(method)){
  const event={id:'event-'+Date.now(),lead_id:path.split('/')[3],
   occurred_at:now(),event_type:'demo_local',actor_user_id:'1',data:input}
  state.history.push(event);return event
 }
 if(path==='/callcenter/dialer/next'&&method==='post'){
  const items=state.leads.slice(0,5).map(lead=>({
   batch_id:'demo-batch-'+state.dialer.sequence,lead_id:lead.id,position:state.leads.indexOf(lead)+1,
   state:'pending',deferred_reason:null,resolved_at:null,
   first_name:lead.first_name,last_name:lead.last_name,company:lead.company,
   phone:lead.phone,email:lead.email,status:lead.status,notes:lead.notes,
   source:lead.source,ingest_method:lead.ingest_method
  }))
  const batch={id:'demo-batch-'+state.dialer.sequence,created_at:now(),items}
  state.dialer={batch,sequence:state.dialer.sequence+1}
  return {batch,empty:items.length===0,demo_only:true}
 }
 const dialItem=path.match(/^\/callcenter\/dialer\/items\/([^/]+)\/resolve$/)
 if(dialItem&&method==='post'){
  const current=state.dialer.batch
  if(!current)return {batch:null,empty:true,demo_only:true}
  const items=(current.items as Array<Record<string,unknown>>)
  const lead=items.find(item=>item.lead_id===decodeURIComponent(dialItem[1]))
  if(!lead)return undefined
  lead.state=input.mode==='deferred'?'deferred':'done'
  lead.deferred_reason=input.reason??null
  lead.resolved_at=now()
  state.dialer.batch={...current,items}
  return {batch:state.dialer.batch,empty:false,demo_only:true}
 }
 const core=coreWrite(state,method,path,input)
 if(core!==UNHANDLED)return core
 const secondary=featureWrite(state,method,path,input)
 if(secondary!==UNHANDLED)return secondary
 return undefined
}
export const nativePortfolioDemoAdapter:AxiosAdapter=async (config)=>{
 const route=checkURL(config)
 if(!route)return fail(config,403,'external or unexpected API URL blocked')
 const method=(config.method||'get').toLowerCase()
 const state=load()
 const {path,query}=route
 if(method==='get'||method==='head'){
  const data=read(state,path,query)
  if(data===undefined||data===null)return fail(config,404,'only fictional records are accessible')
  return response(config,typeof Blob!=='undefined'&&data instanceof Blob?data:clone(data))
 }
 if(!['put','post','patch','delete'].includes(method))return fail(config,405,'unsupported method')
 const modified=clone(state)
 const input=typeof FormData!=='undefined'&&config.data instanceof FormData
  ?await demoConvertInput(config.data):parseInput(config.data)
 const fileResult=demoFileWrite(modified,method,path,input)
 const result=fileResult!==UNHANDLED?fileResult:write(modified,method,path,input)
 if(result===undefined)return fail(config,404,'operation not supported by local demo transport')
 try{persist(modified)}catch{return fail(config,507,'browser storage is unavailable or full; no changes saved')}
 return response(config,clone(result),method==='put'?201:200)
}
