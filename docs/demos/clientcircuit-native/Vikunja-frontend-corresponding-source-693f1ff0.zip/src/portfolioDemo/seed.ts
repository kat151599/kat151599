/**
 * Browser-only fictional data for the ORIGINAL Vikunja Vue frontend.
 * No production records, credentials, phone numbers, API keys or real persons.
 * This is NOT the unrelated CC58P01 HTML mock.
 */
const admin = {
 id: 1, type: 1, exp: 4102444800, username: 'portfolio-demo-admin',
 name: 'Демо-администратор', email: 'admin@example.invalid',
 is_admin: true, is_local_user: true,
 created: '2026-01-01T00:00:00Z', updated: '2026-01-01T00:00:00Z',
 settings: {name: 'Демо-администратор', language: 'ru', timezone: 'Europe/Kyiv',
  default_project_id: 100,
  frontend_settings: {language: 'ru', default_project_view: 'kanban'}}
}
const mkView = (projectId: number, kind: 'list'|'kanban'|'table'|'gantt', n: number) => ({
 id: projectId*10+n, project_id: projectId, title: {
  list:'Список',kanban:'Канбан',table:'Таблица',gantt:'Гантт'
 }[kind], view_kind: kind, position:n,
 filter: {sort_by:[],order_by:[],filter:'',filter_include_nulls:true,s:''},
 bucket_configuration: [], bucket_configuration_mode: 'manual',
 default_bucket_id: projectId*100+1, done_bucket_id:projectId*100+3
})
const names=['Разработка ClientCircuit','Работа с клиентами','Мониторинг интеграций','Планирование релиза']
export const demoProjects=names.map((title,index)=>{
 const id=index+101
 return {id,title,description:'Учебный проект: '+title+'. Все данные вымышлены.',
  owner:admin, owner_id:1, parent_project_id:0, is_archived:false,is_completed:false,
  is_favorite:index===0, position:index+1, identifier:'DEMO'+(index+1),
  hex_color:['#3a8cc2','#aa78bc','#42ab90','#c9a045'][index],
  max_permission:2,views:[mkView(id,'list',1),mkView(id,'kanban',2),mkView(id,'table',3),mkView(id,'gantt',4)],
  created:'2026-10-01T09:00:00Z',updated:'2026-10-20T09:00:00Z'}
})
// The real CallCenterView schedules callbacks into the user's Inbox project.
// Keep this fictional inbox hidden from the normal project sidebar exactly as
// the original application does for its authenticated user's defaultProjectId.
const demoInbox={
 ...demoProjects[0], id:100, title:'Inbox',description:'Личная демонстрационная папка Inbox',
 identifier:'INBOX',is_favorite:false,position:0,
 views:demoProjects[0].views.map(v=>({...v,id:1000+v.position,
  project_id:100,default_bucket_id:10001,done_bucket_id:10003}))
}
const taskTitles=[
 ['Подготовить интерфейс проекта','Проверить карточки задач','Согласовать работу интеграций','Написать документацию'],
 ['Обработать новый запрос','Уточнить сценарии колл-центра','Подготовить напоминания'],
 ['Проверить синтетические события','Обновить показатели','Проверить обработку ошибок'],
 ['Собрать релизный список','Сверить итоги демонстрации','Провести презентацию']
]
let next=1000
export const demoTasks=taskTitles.flatMap((titles,p)=>{
 const project=demoProjects[p]
 return titles.map((title,i)=>{
  const id=++next
  const done=i===0,workflowState=done?'done':i===1?'in_progress':'new'
  return {id,title,description:'Демонстрационная задача. Данные и изменения остаются в этом браузере.',
   project_id:project.id,
   bucket_id:project.id*100+(done?3:i===1?2:1),done,workflow_state:workflowState,
   priority:i%3,position:i+1,index:i+1,identifier:project.identifier+'-'+(i+1),
   hex_color:'', percent_done:done?100:0,labels:[] as Array<Record<string,unknown>>,assignees:[admin],
   created_by:admin, due_date:'2026-11-'+String(3+i+p).padStart(2,'0')+'T12:00:00Z',
   created:'2026-10-01T09:00:00Z',updated:'2026-10-20T09:00:00Z',
   start_date:null,end_date:null,done_at:done?'2026-10-20T09:00:00Z':null,
   repeat_after:0,reminders:[],attachments:[],related_tasks:{},reactions:{},comments:[], 
   work_groups:[],is_favorite:false,max_permission:2}
 })
})
export const demoUsers=[
 admin,
 {...admin,id:2,username:'alina.demo',name:'Алина Волкова',email:'alina@example.invalid',is_admin:false},
 {...admin,id:3,username:'mark.demo',name:'Марк Лисов',email:'mark@example.invalid',is_admin:false}
]
export const demoTeams=[
 {id:201,name:'Команда разработки',description:'Учебная команда',members:[],max_permission:2},
 {id:202,name:'Отдел сопровождения',description:'Учебная команда',members:[],max_permission:2}
]
export const demoLeads=[
 {id:'demo-lead-1',first_name:'Ольга',last_name:'Северная',company:'Вымышленная компания А',
  phone:null,email:null,website:null,address:null,city:'Демо-город',status:'new',
  source:'demo',ingest_method:'manual',assigned_to:null,spam_protected:false,
  notes:'Только учебный сценарий.',last_called_at:null,created_at:'2026-10-10T10:00:00Z',
  updated_at:'2026-10-10T10:00:00Z',vikunja_project_id:102,converted_at:null},
 {id:'demo-lead-2',first_name:'Иван',last_name:'Тестовый',company:'Вымышленная компания Б',
  phone:null,email:null,website:null,address:null,city:'Демо-город',status:'callback',
  source:'demo',ingest_method:'manual',assigned_to:null,spam_protected:false,
  notes:'Планируемый контакт, без реальных звонков.',last_called_at:null,
  created_at:'2026-10-11T10:00:00Z',updated_at:'2026-10-11T10:00:00Z',
  vikunja_project_id:102,converted_at:null}
]
export const fictionalAdmin=admin
export function initialBrowserDemoData() {
 return {
  version:1,
  projects: structuredClone([...demoProjects,demoInbox]),
  tasks: structuredClone(demoTasks),
  users: structuredClone(demoUsers),
  teams: structuredClone(demoTeams),
  leads: structuredClone(demoLeads),
  folders: [{id:301,title:'Примеры рабочих процессов',parent_folder_id:0,position:1}],
  folder_projects:demoProjects.map((p,i)=>({project_id:p.id,folder_id:i<2?301:0,position:i+1})),
  labels:[] as Array<Record<string,unknown>>,
  comments:[] as Array<Record<string,unknown>>,
  history:[] as Array<Record<string,unknown>>,
  dialer:{batch:null as Record<string,unknown>|null,sequence:1},
  buckets:[...demoProjects,demoInbox].flatMap(p=>[
   {id:p.id*100+1,project_id:p.id,project_view_id:p.id*10+2,title:'Новые',position:1,limit:0,count:0,tasks:[],created_by:admin,created:'2026-10-01T09:00:00Z',updated:'2026-10-20T09:00:00Z'},
   {id:p.id*100+2,project_id:p.id,project_view_id:p.id*10+2,title:'В работе',position:2,limit:0,count:0,tasks:[],created_by:admin,created:'2026-10-01T09:00:00Z',updated:'2026-10-20T09:00:00Z'},
   {id:p.id*100+3,project_id:p.id,project_view_id:p.id*10+2,title:'Готово',position:3,limit:0,count:0,tasks:[],created_by:admin,created:'2026-10-01T09:00:00Z',updated:'2026-10-20T09:00:00Z'}
  ]),
  settings:admin.settings,
  extra:{} as Record<string,unknown>,
 }
}
export type BrowserDemoState=ReturnType<typeof initialBrowserDemoData>
