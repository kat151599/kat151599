import {computed, toValue} from 'vue'

import {useTitle as useTitleVueUse, type UseTitleOptions, type ReadonlyRefOrGetter, type MaybeRef, type MaybeRefOrGetter} from '@vueuse/core'

export function useTitle(
	newTitle:
		| ReadonlyRefOrGetter<string | null | undefined>
		| MaybeRef<string | null | undefined>
		| MaybeRefOrGetter<string | null | undefined> = null,
	options?: UseTitleOptions,
) {
	const pageTitle = computed(() => toValue(newTitle))

	// This composable updates <title> reactively; the one-shot setTitle helper
	// cannot override it. Keep the original name outside the portfolio demo.
	const appTitle = import.meta.env.VITE_CC58_NATIVE_DEMO === '1' ? 'ClientCircuit' : 'Vikunja'
	const completeTitle = computed(() =>
		(typeof pageTitle.value === 'undefined' || pageTitle.value === '')
			? appTitle
			: `${pageTitle.value} | ${appTitle}`,
	)

	return useTitleVueUse(completeTitle, options)
}
