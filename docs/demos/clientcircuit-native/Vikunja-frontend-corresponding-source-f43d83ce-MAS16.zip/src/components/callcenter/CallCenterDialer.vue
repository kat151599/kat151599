<script setup lang="ts">
import {computed, onMounted, onUnmounted, ref, watch} from 'vue'
import {visibleLeadNote} from '@/helpers/websiteLeadNotes'
import callCenterService, {
    type CallCenterCall,
    type CallCenterDialBatch,
    type CallCenterDialItem,
} from '@/services/callCenter'

// Escape page-local stacking contexts so the fixed main navbar cannot cover
// the call-center dialog. Normal Vikunja preserves its original placement.
const isPortfolioDemo = import.meta.env.VITE_CC58_NATIVE_DEMO === '1'

const emit = defineEmits<{
    (event: 'close'): void
    (event: 'openLead', leadId: string): void
    (event: 'changed'): void
}>()

const batch = ref<CallCenterDialBatch | null>(null)
const selectedId = ref('')
const loading = ref(false)
const saving = ref(false)
const error = ref('')
const notice = ref('')
const outcome = ref<CallCenterCall['outcome']>('answered')
const notes = ref('')
const deferReason = ref('')
const deferOpen = ref(false)

const outcomes: Array<{value: CallCenterCall['outcome']; label: string}> = [
    {value: 'answered', label: 'Дозвонились'},
    {value: 'no_answer', label: 'Не ответил'},
    {value: 'busy', label: 'Занято'},
    {value: 'voicemail', label: 'Автоответчик'},
    {value: 'wrong_number', label: 'Неверный номер'},
    {value: 'disconnected', label: 'Номер отключён'},
    {value: 'dnc', label: 'Просит больше не звонить'},
]

const statusNames: Record<string, string> = {
    new: 'Новый',
    contacted: 'Связывались',
    callback: 'Перезвонить',
    interested: 'Заинтересован',
    qualified: 'Квалифицирован',
    not_interested: 'Не заинтересован',
    do_not_contact: 'Не звонить',
    converted: 'Конвертирован',
}

const pendingCount = computed(() => batch.value?.items.filter(item => item.state === 'pending').length ?? 0)
const resolvedCount = computed(() => batch.value?.items.filter(item => item.state !== 'pending').length ?? 0)
const selected = computed(() => batch.value?.items.find(item => item.lead_id === selectedId.value) ?? null)
const selectedNote = computed(() => selected.value ? visibleLeadNote(selected.value.notes, selected.value.source, selected.value.ingest_method) : '')
const total = computed(() => batch.value?.items.length ?? 0)
const progress = computed(() => total.value ? Math.round(resolvedCount.value / total.value * 100) : 0)

function label(item: CallCenterDialItem): string {
    return [item.first_name, item.last_name].filter(Boolean).join(' ') || item.company || item.phone || 'Без имени'
}

function sourceName(item: CallCenterDialItem): string {
    return item.source === 'website' ? 'Сайт' : item.source || 'Не указан'
}

function statusName(item: CallCenterDialItem): string {
    return statusNames[item.status] ?? item.status
}

function isDemo(item: CallCenterDialItem): boolean {
    return item.ingest_method === 'alpha_demo'
}

watch(selectedId, () => {
    outcome.value = 'answered'
    notes.value = ''
    deferReason.value = ''
    deferOpen.value = false
    error.value = ''
    notice.value = ''
})

function onKeydown(event: KeyboardEvent): void {
    if (event.key === 'Escape' && !saving.value) emit('close')
}

async function refresh(): Promise<void> {
    loading.value = true
    error.value = ''
    try {
        const result = await callCenterService.currentDialBatch()
        batch.value = result.batch
        if (!result.batch?.items.some(item => item.lead_id === selectedId.value)) {
            selectedId.value = result.batch?.items[0]?.lead_id ?? ''
        }
    } catch (err) {
        error.value = err instanceof Error ? err.message : 'Не удалось загрузить рабочую партию'
    } finally {
        loading.value = false
    }
}

async function nextFive(): Promise<void> {
    if (saving.value || loading.value || pendingCount.value > 0) return
    saving.value = true
    error.value = ''
    notice.value = ''
    try {
        const result = await callCenterService.nextDialBatch()
        batch.value = result.batch
        selectedId.value = result.batch?.items[0]?.lead_id ?? ''
        if (result.empty) notice.value = 'Свободных клиентов для обзвона сейчас нет.'
    } catch (err) {
        error.value = err instanceof Error ? err.message : 'Не удалось получить пятёрку'
    } finally {
        saving.value = false
    }
}

async function resolve(mode: 'done' | 'deferred'): Promise<void> {
    const item = selected.value
    if (!item || item.state !== 'pending' || saving.value || loading.value) return
    if (mode === 'deferred' && !deferReason.value.trim()) {
        error.value = 'Укажи причину, по которой откладываешь клиента.'
        return
    }
    saving.value = true
    error.value = ''
    notice.value = ''
    try {
        const result = await callCenterService.resolveDialItem(item.lead_id, {
            mode,
            ...(mode === 'done' ? {call_outcome: outcome.value, notes: notes.value} : {reason: deferReason.value}),
        })
        batch.value = result.batch
        notice.value = mode === 'done' ? 'Результат звонка сохранён.' : 'Клиент отложен с указанной причиной.'
        notes.value = ''
        deferReason.value = ''
        deferOpen.value = false
        emit('changed')
    } catch (err) {
        error.value = err instanceof Error ? err.message : 'Не удалось сохранить результат'
    } finally {
        saving.value = false
    }
}

onMounted(() => {
    window.addEventListener('keydown', onKeydown)
    void refresh()
})
onUnmounted(() => window.removeEventListener('keydown', onKeydown))
</script>

<template>
    <Teleport to="body" :disabled="!isPortfolioDemo">
    <div class="dial-backdrop" @click.self="emit('close')">
        <section class="dial-workspace" :class="{'is-welcome': !batch && !loading}" role="dialog" aria-modal="true" aria-label="Рабочее окно обзвона">
            <header class="dial-topbar">
                <div class="dial-topbar-title">
                    <div class="dial-mark" aria-hidden="true">☎</div>
                    <div>
                        <p class="dial-eyebrow">CALL CENTER · РАБОЧЕЕ МЕСТО</p>
                        <h2>Обзвон клиентов</h2>
                        <p class="dial-subtitle">Пять контактов за раз. Следующую партию выбираешь сама.</p>
                    </div>
                </div>
                <button class="dial-icon-btn" type="button" aria-label="Закрыть обзвон" @click="emit('close')">
                    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true" focusable="false">
                        <path d="M5 5L19 19M19 5L5 19" />
                    </svg>
                </button>
            </header>

            <div v-if="error" class="dial-alert dial-alert-error" role="alert">{{ error }}</div>
            <div v-if="notice" class="dial-alert dial-alert-ok" role="status">{{ notice }}</div>

            <div v-if="loading" class="dial-loading" role="status">
                <div class="dial-spinner" aria-hidden="true"></div>
                <strong>Восстанавливаем твою рабочую партию…</strong>
            </div>
            <div v-else-if="!batch" class="dial-welcome">
                <div class="dial-welcome-icon" aria-hidden="true">☎</div>
                <div class="dial-welcome-label">ГОТОВО К РАБОТЕ</div>
                <h3>Начнём с пяти клиентов?</h3>
                <p>Получишь небольшую фиксированную партию. Она сохранится на сервере, даже если закрыть окно или перезапустить приложение.</p>
                <button type="button" class="dial-btn dial-btn-primary dial-btn-large" :disabled="saving" @click="nextFive">
                    {{ saving ? 'Подбираем клиентов…' : 'Получить 5 лидов →' }}
                </button>
                <small>Никакой автоматической выдачи шестого клиента.</small>
            </div>

            <div v-else class="dial-content">
                <aside class="dial-sidebar">
                    <div class="dial-sidebar-heading">
                        <div>
                            <div class="dial-step-label">ТЕКУЩАЯ ПАРТИЯ</div>
                            <h3>Мои пять клиентов</h3>
                        </div>
                        <span class="dial-count">{{ resolvedCount }} / {{ total }}</span>
                    </div>
                    <div
                        class="dial-progress-track"
                        role="progressbar"
                        :aria-valuenow="resolvedCount"
                        :aria-valuemin="0"
                        :aria-valuemax="total"
                        aria-label="Прогресс обзвона"
                    ><div class="dial-progress-fill" :style="{width: progress + '%'}"></div></div>

                    <div class="dial-people">
                        <button
                            v-for="item in batch.items"
                            :key="item.lead_id"
                            type="button"
                            class="dial-person"
                            :class="{'is-current': selectedId === item.lead_id, 'is-complete': item.state !== 'pending'}"
                            :aria-pressed="selectedId === item.lead_id"
                            @click="selectedId = item.lead_id"
                        >
                            <span class="dial-person-number">{{ String(item.position).padStart(2, '0') }}</span>
                            <span class="dial-person-main">
                                <strong>{{ label(item) }}</strong>
                                <small>{{ item.company || sourceName(item) }}</small>
                            </span>
                            <span class="dial-person-state" :class="'is-' + item.state">
                                {{ item.state === 'done' ? '✓' : item.state === 'deferred' ? '◷' : '○' }}
                            </span>
                        </button>
                    </div>
                    <p class="dial-sidebar-help">Готовые карточки остаются здесь до окончания партии.</p>
                </aside>

                <article v-if="selected" class="dial-detail">
                    <div class="dial-contact-head">
                        <div class="dial-avatar" aria-hidden="true">{{ label(selected).slice(0, 1).toUpperCase() }}</div>
                        <div class="dial-contact-name">
                            <div class="dial-contact-badges">
                                <span class="dial-tag dial-tag-status">{{ statusName(selected) }}</span>
                                <span v-if="isDemo(selected)" class="dial-tag dial-tag-demo">ДЕМО</span>
                            </div>
                            <h3>{{ label(selected) }}</h3>
                            <p>{{ selected.company || 'Контакт без компании' }}</p>
                        </div>
                        <button class="dial-btn dial-btn-light dial-edit" type="button" @click="emit('openLead', selected.lead_id)">
                            Полная карточка ↗
                        </button>
                    </div>

                    <div class="dial-info-grid">
                        <div class="dial-info-tile">
                            <small>ТЕЛЕФОН</small>
                            <a v-if="selected.phone" :href="'tel:' + selected.phone">{{ selected.phone }}</a>
                            <strong v-else>Не указан</strong>
                        </div>
                        <div class="dial-info-tile">
                            <small>ИСТОЧНИК ЗАЯВКИ</small>
                            <strong>{{ sourceName(selected) }}</strong>
                        </div>
                        <div class="dial-info-tile">
                            <small>EMAIL</small>
                            <a v-if="selected.email" :href="'mailto:' + selected.email">{{ selected.email }}</a>
                            <strong v-else>Не указан</strong>
                        </div>
                        <div class="dial-info-tile">
                            <small>РАБОЧИЙ СТАТУС</small>
                            <strong>{{ statusName(selected) }}</strong>
                        </div>
                    </div>

                    <div v-if="selectedNote" class="dial-lead-note">
                        <span>ЗАМЕТКА О КЛИЕНТЕ</span>
                        <p>{{ selectedNote }}</p>
                    </div>

                    <div v-if="selected.state !== 'pending'" class="dial-completed">
                        <div class="dial-completed-icon">{{ selected.state === 'done' ? '✓' : '◷' }}</div>
                        <div>
                            <strong>{{ selected.state === 'done' ? 'Клиент обработан' : 'Клиент отложен' }}</strong>
                            <p v-if="selected.state === 'deferred'">{{ selected.deferred_reason }}</p>
                            <p v-else>Результат сохранён. Можно выбрать следующего человека слева.</p>
                        </div>
                    </div>

                    <form v-else class="dial-form" @submit.prevent="resolve('done')">
                        <div class="dial-section-title">
                            <span class="dial-section-icon" aria-hidden="true">✎</span>
                            <div><h4>Результат взаимодействия</h4><p>Запиши звонок или отложи клиента с причиной.</p></div>
                        </div>
                        <div class="dial-form-row">
                            <label class="dial-field">
                                <span>Результат звонка</span>
                                <select v-model="outcome" :disabled="saving">
                                    <option v-for="choice in outcomes" :key="choice.value" :value="choice.value">{{ choice.label }}</option>
                                </select>
                            </label>
                        </div>
                        <label class="dial-field">
                            <span>Комментарий к звонку <em>необязательно</em></span>
                            <textarea v-model="notes" rows="2" maxlength="5000" placeholder="Что обсудили с клиентом?" :disabled="saving"></textarea>
                        </label>
                        <div class="dial-action-row">
                            <button class="dial-btn dial-btn-primary" type="submit" :disabled="saving">✓ Сохранить результат</button>
                            <button class="dial-btn dial-btn-light" type="button" :disabled="saving" @click="deferOpen = !deferOpen">
                                ◷ Отложить
                            </button>
                        </div>
                        <div v-if="deferOpen" class="dial-defer-box">
                            <label class="dial-field">
                                <span>Причина откладывания <b>обязательно</b></span>
                                <textarea v-model="deferReason" rows="2" maxlength="1000" placeholder="Почему клиент пока не готов к обработке?" :disabled="saving"></textarea>
                            </label>
                            <button class="dial-btn dial-btn-dark" type="button" :disabled="saving || !deferReason.trim()" @click="resolve('deferred')">Сохранить причину и отложить</button>
                        </div>
                    </form>
                </article>
            </div>

            <footer class="dial-bottom">
                <div v-if="batch" class="dial-bottom-message">
                    <span class="dial-bottom-dot" :class="{'is-ready': pendingCount === 0}"></span>
                    <span>{{ pendingCount ? 'Осталось обработать ' + pendingCount + ' из ' + total : 'Партия завершена — можно взять следующую пятёрку' }}</span>
                </div>
                <div v-else class="dial-bottom-message">Ты управляешь темпом работы.</div>
                <div class="dial-bottom-actions">
                    <button v-if="batch" class="dial-btn dial-btn-primary" type="button" :disabled="loading || saving || pendingCount > 0" @click="nextFive">
                        Следующие 5 →
                    </button>
                    <button class="dial-btn dial-btn-outline" type="button" @click="emit('close')">Закрыть</button>
                </div>
            </footer>
        </section>
    </div>
    </Teleport>
</template>

<style scoped>
.dial-backdrop { position: fixed; inset: 0; z-index: 1200; background: rgba(16, 32, 43, .68); backdrop-filter: blur(5px); display: grid; place-items: center; padding: 18px; }
.dial-workspace { position: relative; width: min(960px, calc(100vw - 48px)); height: min(650px, calc(100dvh - 56px)); min-height: 360px; display: flex; flex-direction: column; overflow: hidden; background: var(--gtt-panel, #fff); color: var(--gtt-text, #19251f); border-radius: 14px; box-shadow: 0 20px 65px rgba(7, 56, 45, .23); font: 400 13px/1.45 system-ui, -apple-system, 'Segoe UI', sans-serif; }
.dial-workspace button, .dial-workspace input, .dial-workspace textarea, .dial-workspace select { font: inherit; }
.dial-workspace button { cursor: pointer; }
.dial-workspace.is-welcome { width: min(750px, calc(100vw - 48px)); height: min(460px, calc(100dvh - 56px)); }
.dial-workspace button:disabled { cursor: not-allowed; opacity: .45; }
.dial-topbar { flex: none; padding: 16px 66px 16px 21px; min-height: 88px; display: flex; align-items: center; gap: 12px; background: linear-gradient(112deg, var(--gtt-green-950, #07382d), var(--gtt-green-800, #155c48)); color: #fff; }
.dial-topbar-title { display: flex; align-items: center; gap: 12px; min-width: 0; }
.dial-mark { background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2); width: 41px; height: 41px; border-radius: 11px; display: grid; place-items: center; font-size: 21px; flex: none; }
.dial-eyebrow { font-size: 9px; font-weight: 800; letter-spacing: .18em; color: var(--gtt-lime, #b8f35b); margin-bottom: 4px; }
.dial-topbar h2 { font-size: 20px; font-weight: 750; line-height: 1.15; margin: 0; color: #fff; }
.dial-subtitle { font-size: 11px; color: rgba(255,255,255,.83); margin: 7px 0 0; }
.dial-icon-btn { position: absolute; top: 15px; right: 16px; z-index: 1; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; padding: 0; line-height: 1; border: 1px solid rgba(255,255,255,.32); background: rgba(255,255,255,.11); color: #fff; border-radius: 8px; }
.dial-icon-btn svg { display: block; flex: none; width: 17px; height: 17px; }
.dial-icon-btn:hover { background: rgba(255,255,255,.23); }
.dial-content { flex: 1; min-height: 0; display: grid; grid-template-columns: 270px minmax(0, 1fr); }
.dial-sidebar { overflow-y: auto; background: var(--gtt-panel-soft, #f3f7f3); border-right: 1px solid var(--gtt-border, #e3eae4); padding: 19px 15px; }
.dial-sidebar-heading { display: flex; gap: 8px; align-items: center; justify-content: space-between; }
.dial-step-label { color: var(--gtt-text-soft, #647169); font-size: 10px; font-weight: 850; letter-spacing: .13em; }
.dial-sidebar h3 { color: var(--gtt-text, #19251f); font-size: 16px; font-weight: 750; margin: 6px 0 0; }
.dial-count { background: var(--gtt-lime-soft, #efffd4); color: var(--gtt-green-900, #0b4738); padding: 6px 9px; border-radius: 9px; font-weight: 800; font-size: 12px; white-space: nowrap; }
.dial-progress-track { height: 6px; border-radius: 20px; background: var(--gtt-border, #e3eae4); margin: 18px 0 23px; overflow: hidden; }
.dial-progress-fill { background: linear-gradient(90deg, var(--gtt-green-700, #26745b), var(--gtt-lime, #b8f35b)); height: 100%; border-radius: inherit; transition: width .25s ease; }
.dial-people { display: grid; gap: 8px; }
.dial-person { display: flex; align-items: center; gap: 9px; width: 100%; min-height: 60px; padding: 9px; text-align: left; color: var(--gtt-text, #19251f); background: var(--gtt-panel, #fff); border: 1px solid var(--gtt-border, #e3eae4); border-radius: 9px; box-shadow: var(--gtt-shadow-xs); }
.dial-person.is-current { border-color: var(--gtt-green-700, #26745b); background: var(--gtt-green-100, #e6f4ea); box-shadow: 0 0 0 2px rgba(184,243,91,.27); }
.dial-person.is-complete:not(.is-current) { background: var(--gtt-panel-soft, #f3f7f3); }
.dial-person-number { color: var(--gtt-text-faint, #8b9790); font-size: 12px; font-weight: 800; flex: none; }
.dial-person-main { min-width: 0; flex: 1; }
.dial-person-main strong { display: block; font-size: 13px; font-weight: 750; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dial-person-main small { display: block; color: var(--gtt-text-soft, #647169); margin-top: 4px; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dial-person-state { font-size: 20px; color: var(--gtt-text-faint, #8b9790); }
.dial-person-state.is-done { color: var(--gtt-green-700, #26745b); }
.dial-person-state.is-deferred { color: #dd9c32; }
.dial-sidebar-help { font-size: 12px; line-height: 1.55; color: var(--gtt-text-soft, #647169); margin: 22px 4px 0; }
.dial-detail { overflow-y: auto; padding: 19px 22px; background: var(--gtt-panel, #fff); min-width: 0; }
.dial-contact-head { display: flex; align-items: center; gap: 17px; flex-wrap: wrap; padding-bottom: 22px; border-bottom: 1px solid var(--gtt-border, #e3eae4); }
.dial-avatar { width: 48px; height: 48px; flex: none; background: var(--gtt-green-100, #e6f4ea); color: var(--gtt-green-800, #155c48); display: grid; place-items: center; font-size: 27px; font-weight: 800; border-radius: 18px; }
.dial-contact-name { flex: 1; min-width: 180px; }
.dial-contact-badges { display: flex; gap: 7px; align-items: center; margin-bottom: 6px; }
.dial-contact-name h3 { color: var(--gtt-text, #19251f); font-size: 19px; font-weight: 790; margin: 0; line-height: 1.2; }
.dial-contact-name p { color: var(--gtt-text-soft, #647169); margin: 6px 0 0; font-size: 13px; }
.dial-tag { display: inline-flex; padding: 3px 8px; border-radius: 6px; font-size: 10px; font-weight: 850; letter-spacing: .03em; }
.dial-tag-status { background: var(--gtt-green-100, #e6f4ea); color: var(--gtt-green-900, #0b4738); }
.dial-tag-demo { color: var(--gtt-green-950, #07382d); background: var(--gtt-lime-soft, #efffd4); }
.dial-edit { white-space: nowrap; }
.dial-info-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 9px; margin-top: 16px; }
.dial-info-tile { min-width: 0; min-height: 65px; border: 1px solid var(--gtt-border, #e3eae4); border-radius: 9px; padding: 11px 13px; background: var(--gtt-canvas-soft, #fbfcfa); }
.dial-info-tile small { display: block; color: var(--gtt-text-soft, #647169); font-weight: 850; letter-spacing: .1em; font-size: 10px; margin-bottom: 7px; }
.dial-info-tile strong, .dial-info-tile a { font-size: 14px; color: var(--gtt-text, #19251f); font-weight: 720; word-break: break-word; }
.dial-info-tile a { color: var(--gtt-green-800, #155c48); text-decoration: none; }
.dial-info-tile a:hover { text-decoration: underline; }
.dial-lead-note { margin-top: 18px; background: var(--gtt-panel-soft, #f3f7f3); border-left: 3px solid var(--gtt-green-700, #26745b); border-radius: 7px; padding: 11px 16px; }
.dial-lead-note span { font-size: 10px; letter-spacing: .12em; font-weight: 800; color: var(--gtt-text-soft, #647169); }
.dial-lead-note p { color: var(--gtt-text, #19251f); margin: 6px 0 0; font-size: 13px; white-space: pre-line; }
.dial-section-title { display: flex; gap: 12px; align-items: center; margin: 20px 0 14px; }
.dial-section-icon { width: 36px; height: 36px; display: grid; place-items: center; background: var(--gtt-green-100, #e6f4ea); color: var(--gtt-green-800, #155c48); border-radius: 10px; }
.dial-section-title h4 { color: var(--gtt-text, #19251f); font-size: 15px; font-weight: 790; margin: 0; }
.dial-section-title p { color: var(--gtt-text-soft, #647169); font-size: 12px; margin: 3px 0 0; }
.dial-form { display: grid; gap: 12px; }
.dial-field { display: grid; gap: 6px; width: 100%; color: var(--gtt-text, #19251f); font-weight: 700; font-size: 12px; }
.dial-field em { font-weight: 400; font-style: normal; color: var(--gtt-text-faint, #8b9790); }
.dial-field b { color: #ad5e2e; font-weight: 700; }
.dial-field select, .dial-field textarea { box-sizing: border-box; width: 100%; border: 1px solid var(--gtt-border-strong, #d4dfd6); background: #fff; color: var(--gtt-text, #19251f); border-radius: 9px; padding: 11px 12px; resize: vertical; outline-offset: 2px; }
.dial-field select:focus, .dial-field textarea:focus { border-color: var(--gtt-green-700, #26745b); outline: 2px solid rgba(18,140,130,.15); }
.dial-action-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.dial-btn { display: inline-flex; align-items: center; justify-content: center; gap: 7px; min-height: 36px; padding: 8px 13px; border: 1px solid transparent; border-radius: 9px; font-weight: 760 !important; font-size: 13px !important; line-height: 1.25; transition: background .14s, box-shadow .14s; }
.dial-btn-primary { background: var(--gtt-green-800, #155c48); color: #fff; box-shadow: 0 3px 8px rgba(7,56,45,.14); }
.dial-btn-primary:hover:not(:disabled) { background: var(--gtt-green-900, #0b4738); }
.dial-btn-light { background: var(--gtt-panel-soft, #f3f7f3); border-color: var(--gtt-border, #e3eae4); color: var(--gtt-text, #19251f); }
.dial-btn-light:hover:not(:disabled) { background: var(--gtt-green-100, #e6f4ea); }
.dial-btn-dark { background: var(--gtt-green-950, #07382d); color: #fff; }
.dial-btn-outline { background: #fff; border-color: var(--gtt-border-strong, #d4dfd6); color: var(--gtt-text, #19251f); }
.dial-btn-outline:hover:not(:disabled) { background: var(--gtt-panel-soft, #f3f7f3); }
.dial-defer-box { display: grid; gap: 12px; padding: 15px; margin: 3px 0; background: #fffaf0; border: 1px solid #f0dfb6; border-radius: 11px; }
.dial-defer-box button { justify-self: start; }
.dial-completed { display: flex; align-items: center; gap: 14px; background: var(--gtt-green-100, #e6f4ea); color: var(--gtt-green-800, #155c48); padding: 19px; border-radius: 12px; margin-top: 22px; }
.dial-completed-icon { width: 42px; height: 42px; border-radius: 50%; background: var(--gtt-green-100, #e6f4ea); display: grid; place-items: center; font-size: 23px; }
.dial-completed strong { font-weight: 790; }
.dial-completed p { margin: 4px 0 0; font-size: 12px; overflow-wrap: anywhere; }
.dial-bottom { flex: none; min-height: 57px; display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 9px 20px; border-top: 1px solid var(--gtt-border, #e3eae4); background: var(--gtt-panel, #fff); flex-wrap: wrap; }
.dial-bottom-message { color: var(--gtt-text-soft, #647169); font-size: 12px; display: flex; align-items: center; gap: 8px; }
.dial-bottom-dot { width: 8px; height: 8px; background: #e1ad4e; border-radius: 50%; }
.dial-bottom-dot.is-ready { background: var(--gtt-green-700, #26745b); }
.dial-bottom-actions { display: flex; gap: 10px; align-items: center; }
.dial-welcome { flex: 1; min-height: 0; overflow: auto; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; gap: 9px; padding: 16px 20px; background: radial-gradient(circle at center, var(--gtt-panel-soft, #f3f7f3) 0%, var(--gtt-panel, #fff) 70%); }
.dial-welcome-icon { width: 57px; height: 57px; border-radius: 15px; background: var(--gtt-green-100, #e6f4ea); color: var(--gtt-green-800, #155c48); font-size: 31px; display: grid; place-items: center; box-shadow: 0 10px 30px rgba(15,143,118,.1); }
.dial-welcome-label { letter-spacing: .16em; color: var(--gtt-green-800, #155c48); font-size: 11px; font-weight: 880; }
.dial-welcome h3 { color: var(--gtt-text, #19251f); font-size: 23px; font-weight: 820; margin: 0; }
.dial-welcome p { max-width: 430px; line-height: 1.65; color: var(--gtt-text-soft, #647169); margin: 0; }
.dial-welcome small { color: var(--gtt-text-faint, #8b9790); font-size: 12px; }
.dial-btn-large { min-height: 41px; font-size: 13px !important; padding: 10px 19px; margin-top: 4px; }
.dial-loading { display: flex; gap: 15px; align-items: center; justify-content: center; flex: 1; color: var(--gtt-text-soft, #647169); }
.dial-spinner { width: 27px; height: 27px; border: 3px solid var(--gtt-border-strong, #d4dfd6); border-top-color: var(--gtt-green-800, #155c48); border-radius: 50%; animation: dial-spin .7s linear infinite; }
@keyframes dial-spin { to { transform: rotate(360deg); } }
.dial-alert { padding: 12px 25px; font-size: 13px; flex: none; }
.dial-alert-error { background: #fdf0ef; color: #af3a30; }
.dial-alert-ok { background: var(--gtt-green-100, #e6f4ea); color: var(--gtt-green-900, #0b4738); }
@media (max-width: 800px) { .dial-content { grid-template-columns: 245px minmax(0,1fr); } .dial-sidebar { padding: 20px 12px; } .dial-detail { padding: 22px 18px; } .dial-edit { width: 100%; } .dial-avatar { width: 52px; height: 52px; } }
@media (max-width: 610px) { .dial-backdrop { padding: 0; } .dial-workspace, .dial-workspace.is-welcome { width: 100%; height: 100dvh; min-height: 0; border-radius: 0; } .dial-icon-btn { top: 10px; right: 10px; } .dial-topbar { padding: 14px 52px 14px 14px; min-height: 96px; } .dial-topbar h2 { font-size: 20px; } .dial-subtitle { font-size: 11px; } .dial-mark { width: 43px; height: 43px; } .dial-content { display: block; overflow-y: auto; } .dial-sidebar { overflow: visible; border-right: 0; border-bottom: 1px solid #e4ebed; padding: 14px; } .dial-people { grid-template-columns: repeat(2,minmax(0,1fr)); } .dial-person { min-height: 60px; padding: 9px; gap: 7px; } .dial-person-main strong { font-size: 12px; } .dial-sidebar-help { display: none; } .dial-detail { overflow: visible; padding: 18px 15px; } .dial-info-grid { gap: 7px; } .dial-info-tile { padding: 10px; } .dial-bottom { padding: 10px 14px; min-height: 64px; } }
</style>
