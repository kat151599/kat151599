<template>
	<header
		ref="banner"
		class="cc58-demo-banner d-print-none"
		aria-label="Панель демонстраційного режиму ClientCircuit"
	>
		<strong class="cc58-demo-banner__label">
			CLIENTCIRCUIT · DEMO EDITION · ВИГАДАНІ ДАНІ · БЕЗ ЗОВНІШНІХ API
		</strong>
		<nav class="cc58-demo-banner__actions" aria-label="Навігація демоверсії">
			<a href="../../index.html" target="_top">⌂ Додому</a>
			<a href="../../projects/clientcircuit.html" target="_top">Про проєкт ↗</a>
			<button type="button" @click="resetDemo">Скинути демо ↻</button>
		</nav>
	</header>
</template>

<script setup lang="ts">
import {onBeforeUnmount, onMounted, ref} from 'vue'

// This bar is rendered exclusively by the portfolio demo root App.vue.
// A single component covers both the embedded iframe and full-screen route.
const banner = ref<HTMLElement | null>(null)
const demoStateKey = 'cc58:v1:native-vue:fictional-state'
let sizeObserver: ResizeObserver | null = null

function syncHeight(): void {
	const height = Math.ceil(banner.value?.getBoundingClientRect().height ?? 54)
	document.documentElement.style.setProperty('--cc58-demo-banner-height', `${height}px`)
}

onMounted(() => {
	syncHeight()
	if (typeof ResizeObserver !== 'undefined' && banner.value) {
		sizeObserver = new ResizeObserver(syncHeight)
		sizeObserver.observe(banner.value)
	}
})

onBeforeUnmount(() => {
	sizeObserver?.disconnect()
	document.documentElement.style.removeProperty('--cc58-demo-banner-height')
})

function resetDemo(): void {
	if (!window.confirm('Скинути вигадані дані ClientCircuit у цьому браузері?')) return
	try {
		// Never clear the whole origin: other portfolio demos share localStorage.
		window.localStorage.removeItem(demoStateKey)
		window.location.reload()
	} catch {
		window.alert('Не вдалося скинути демо. Перевірте доступ до локального сховища браузера.')
	}
}
</script>
