<template>
	<section
		class="personal-board"
		:class="{'is-embedded': props.embedded}"
	>
		<header
			v-if="!props.embedded"
			class="personal-board__header"
		>
			<div>
				<span class="personal-board__eyebrow">
					Рабочий поток
				</span>

				<h2>
					Моя доска
				</h2>

				<p>
					Перетаскивайте задачи между этапами работы.
				</p>
			</div>
		</header>
		<div
			v-if="boardStore.isLoading || taskStore.isLoading"
			class="personal-board__state"
		>
			Загрузка…
		</div>

		<div
			v-else
			class="personal-board__scroller"
		>
			<section
				v-for="column in boardStore.columns"
				:key="column.id"
				class="personal-board__column"
				:data-system-key="column.systemKey ?? 'custom'"
			>
				<header class="personal-board__column-header">
					<div class="personal-board__column-title">
						<span
							v-if="column.systemKey === 'done'"
							class="personal-board__done"
						>✓</span>
						<input
							:value="column.title"
							class="personal-board__title-input"
							@blur="renameColumn(column.id, $event)"
							@keydown.enter.prevent="($event.target as HTMLInputElement).blur()"
							@keydown.esc.prevent="($event.target as HTMLInputElement).blur()"
						>
					</div>
					<div class="personal-board__actions">
						<span>{{ taskCount(column.id) }}</span>
						<button
							v-if="column.systemKey === null"
							type="button"
							class="personal-board__delete"
							:disabled="taskCount(column.id) > 0"
							:title="taskCount(column.id) > 0 ? 'Сначала перенесите задачи' : 'Удалить колонку'"
							@click="deleteColumn(column.id)"
						>
							×
						</button>
					</div>
				</header>

				<draggable
					:list="tasksByColumn[column.id]"
					class="personal-board__tasks"
					:data-column-id="column.id"
					:group="{name: 'personal-board-tasks', pull: true, put: true}"
					:sort="false"
					animation="150"
					item-key="id"
					ghost-class="personal-board__ghost"
					drag-class="personal-board__dragging"
					@end="handleDragEnd"
				>
					<template #item="{element: task}">
						<div
							class="personal-board__task"
							:data-task-id="task.id"
						>
							<KanbanCard
								:task="task"
								:project-id="0"
								:loading="taskUpdating[task.id] ?? false"
								@taskUpdated="handleTaskUpdated"
							/>
						</div>
					</template>
				</draggable>

				<div
					v-if="column.systemKey !== 'done'"
					class="personal-board__task-create"
					:data-column-id="column.id"
				>
					<template v-if="newTaskColumnId === column.id">
						<div class="personal-board__task-create-head">
							<span>
								Новая задача
							</span>

							<button
								type="button"
								class="personal-board__task-create-close"
								aria-label="Закрыть создание задачи"
								@click="cancelTaskCreate"
							>
								×
							</button>
						</div>

						<AddTask
							:project-id="0"
							@tasksAdded="handleTasksAdded($event, column.id)"
						/>
					</template>

					<button
						v-else
						type="button"
						class="personal-board__task-add"
						@click="startTaskCreate(column.id)"
					>
						<span aria-hidden="true">+</span>
						Добавить задачу
					</button>
				</div>
			</section>

			<section class="personal-board__column personal-board__column--new">
				<template v-if="showNewColumn">
					<input
						ref="newColumnInput"
						v-model="newColumnTitle"
						class="input"
						maxlength="200"
						placeholder="Название колонки"
						@keyup.enter="createColumn"
						@keyup.esc="cancelNewColumn"
					>
					<div class="personal-board__new-actions">
						<button
							type="button"
							@click="createColumn"
						>
							Создать
						</button>
						<button
							type="button"
							@click="cancelNewColumn"
						>
							Отмена
						</button>
					</div>
				</template>
				<button
					v-else
					type="button"
					class="personal-board__add"
					@click="startNewColumn"
				>
					+ Создать колонку
				</button>
			</section>
		</div>
	</section>
</template>

<script setup lang="ts">
import {nextTick, ref, watch} from 'vue'
import draggable from 'zhyswan-vuedraggable'

import AddTask from '@/components/tasks/AddTask.vue'
import KanbanCard from '@/components/tasks/partials/KanbanCard.vue'
import {useAuthStore} from '@/stores/auth'
import {useMyTasksStore} from '@/stores/myTasks'
import {usePersonalBoardStore} from '@/stores/personalBoard'
import TaskAssigneeModel from '@/models/taskAssignee'
import TaskAssigneeService from '@/services/taskAssignee'
import type {ITask} from '@/modelTypes/ITask'

interface DragEndEvent {
    item: HTMLElement
    to: HTMLElement
}

const props = withDefaults(defineProps<{
	embedded?: boolean
}>(), {
	embedded: false,
})
const boardStore = usePersonalBoardStore()
const authStore = useAuthStore()
const taskStore = useMyTasksStore()
const taskAssigneeService = new TaskAssigneeService()
const tasksByColumn = ref<Record<number, ITask[]>>({})
const taskUpdating = ref<Record<number, boolean>>({})
const showNewColumn = ref(false)
const newColumnTitle = ref('')
const newColumnInput = ref<HTMLInputElement | null>(null)
const newTaskColumnId = ref<number | null>(null)

function rebuild() {
	const result: Record<number, ITask[]> = {}
	for (const column of boardStore.columns) result[column.id] = []

	for (const task of taskStore.tasks) {
		const columnId = boardStore.columnIdForTask(task)
		if (columnId !== null && result[columnId]) result[columnId].push(task)
	}

	for (const column of boardStore.columns) {
		result[column.id].sort((a, b) => {
			const ap = boardStore.placementForTask(a.id)
			const bp = boardStore.placementForTask(b.id)
			if (!ap && !bp) return a.id - b.id
			if (!ap) return -1
			if (!bp) return 1
			return ap.position - bp.position || a.id - b.id
		})
	}

	tasksByColumn.value = result
}

watch(
	[
		() => taskStore.tasks.map(task => `${task.id}:${task.done}:${task.workflowState}`).join('|'),
		() => boardStore.columns.map(column => `${column.id}:${column.title}:${column.position}`).join('|'),
		() => boardStore.placements.map(item => `${item.taskId}:${item.columnId}:${item.position}`).join('|'),
	],
	rebuild,
	{immediate: true},
)

function taskCount(columnId: number) {
	return tasksByColumn.value[columnId]?.length ?? 0
}

async function renameColumn(columnId: number, event: FocusEvent) {
	const input = event.target as HTMLInputElement
	const column = boardStore.columns.find(item => item.id === columnId)
	if (!column) return
	const title = input.value.trim()
	if (!title || title === column.title) {
		input.value = column.title
		return
	}
	try {
		await boardStore.renameColumn(columnId, title)
	} catch (error) {
		console.error('Could not rename personal board column', error)
		input.value = column.title
	}
}

async function deleteColumn(columnId: number) {
	if (taskCount(columnId) > 0) return
	try {
		await boardStore.deleteColumn(columnId)
	} catch (error) {
		console.error('Could not delete personal board column', error)
		await boardStore.load()
	}
}

async function startNewColumn() {
	showNewColumn.value = true
	await nextTick()
	newColumnInput.value?.focus()
}

function cancelNewColumn() {
	showNewColumn.value = false
	newColumnTitle.value = ''
}

async function createColumn() {
	const title = newColumnTitle.value.trim()
	if (!title) return
	try {
		await boardStore.createColumn(title)
		cancelNewColumn()
	} catch (error) {
		console.error('Could not create personal board column', error)
	}
}

async function startTaskCreate(columnId: number) {
	newTaskColumnId.value = columnId

	await nextTick()

	document
		.querySelector<HTMLTextAreaElement>(
			`.personal-board__task-create[data-column-id="${columnId}"] .add-task-textarea`,
		)
		?.focus()
}

function cancelTaskCreate() {
	newTaskColumnId.value = null
}

async function assignTaskToCurrentUser(task: ITask) {
	const currentUser = authStore.info
	const userId = Number(currentUser?.id ?? 0)

	if (
		userId <= 0 ||
		task.assignees.some(user => user.id === userId)
	) {
		return
	}

	await taskAssigneeService.create(
		new TaskAssigneeModel({
			taskId: task.id,
			userId,
		}),
	)

	if (currentUser) {
		task.assignees = [
			...task.assignees,
			currentUser,
		]
	}
}

async function handleTasksAdded(
	createdTasks: ITask[],
	columnId: number,
) {
	const column =
		boardStore.columns.find(item => item.id === columnId)

	if (!column) {
		taskStore.addTasks(createdTasks)
		newTaskColumnId.value = null
		rebuild()
		return
	}

	try {
		for (const task of createdTasks) {
			await assignTaskToCurrentUser(task)

			taskStore.replaceTask(task)

			await boardStore.placeTask(
				task.id,
				column.id,
				boardStore.nextPosition(column.id),
			)
		}
	} catch (error) {
		console.error(
			'Could not finish creating task on personal board',
			error,
		)

		await Promise.all([
			taskStore.load({
				includeCreated:
					boardStore.includeCreatedTasks,
			}),
			boardStore.load(),
		])
	} finally {
		newTaskColumnId.value = null
		rebuild()
	}
}

function handleTaskUpdated(task: ITask) {
	taskStore.replaceTask(task)
}

async function handleDragEnd(event: DragEndEvent) {
	const taskId = Number(event.item.dataset.taskId)
	const targetColumnId = Number(event.to.dataset.columnId)

	if (!Number.isFinite(taskId) || !Number.isFinite(targetColumnId) || taskId < 1 || targetColumnId < 1) {
		rebuild()
		return
	}

	const task = taskStore.tasks.find(item => item.id === taskId)
	const target = boardStore.columns.find(column => column.id === targetColumnId)
	if (!task || !target) {
		rebuild()
		return
	}

	taskUpdating.value[taskId] = true
	try {
		if (target.systemKey === 'done') {
			if (!task.done) await taskStore.updateTask(task, {done: true})
			rebuild()
			return
		}

		let currentTask = task
		if (currentTask.done) currentTask = await taskStore.updateTask(currentTask, {done: false})

		await boardStore.placeTask(
			currentTask.id,
			target.id,
			boardStore.nextPosition(target.id),
		)
	} catch (error) {
		console.error('Could not move task on personal board', error)
		await Promise.all([taskStore.load(), boardStore.load()])
	} finally {
		taskUpdating.value[taskId] = false
		rebuild()
	}
}
</script>

<style scoped lang="scss">
.personal-board {
	display: grid;
	gap: .75rem;
	min-inline-size: 0;
	padding: 1rem;
	border: 1px solid var(--gtt-border);
	border-radius: var(--gtt-radius-lg);
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
}

.personal-board.is-embedded {
	padding: 0;
	border: 0;
	border-radius: 0;
	background: transparent;
	box-shadow: none;
}

.personal-board__header {
	h2 {
		margin: 0;
		color: var(--gtt-text);
		font-size: .95rem;
		font-weight: 730;
	}

	p {
		margin: .2rem 0 0;
		color: var(--gtt-text-soft);
		font-size: .76rem;
	}
}

.personal-board__eyebrow {
	display: block;
	margin-block-end: .15rem;
	color: var(--gtt-text-faint);
	font-size: .65rem;
	font-weight: 720;
	letter-spacing: .07em;
	text-transform: uppercase;
}

.personal-board__state {
	padding: 2rem;
	color: var(--gtt-text-soft);
	text-align: center;
}

.personal-board__scroller {
	display: flex;
	align-items: stretch;
	gap: .8rem;
	min-inline-size: 0;
	padding-block-end: .35rem;
	overflow-x: auto;
}

.personal-board__column {
	flex: 0 0 300px;
	inline-size: 300px;
	min-block-size: 390px;
	overflow: hidden;
	border: 1px solid var(--gtt-border);
	border-block-start: 3px solid var(--gtt-green-700);
	border-radius: 13px;
	background: var(--gtt-panel-soft);
	box-shadow: var(--gtt-shadow-xs);
}

.personal-board__column[data-system-key="in_progress"] {
	border-block-start-color: var(--gtt-blue);
}

.personal-board__column[data-system-key="waiting"] {
	border-block-start-color: var(--gtt-yellow);
}

.personal-board__column[data-system-key="done"] {
	border-block-start-color: var(--gtt-green-700);
}

.personal-board__column-header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: .5rem;
	block-size: 54px;
	padding: .65rem .7rem;
	border-block-end: 1px solid var(--gtt-border);
	background: var(--gtt-panel);
}

.personal-board__column-title {
	display: flex;
	align-items: center;
	flex: 1;
	gap: .35rem;
	min-inline-size: 0;
}

.personal-board__title-input {
	inline-size: 100%;
	min-inline-size: 0;
	padding: .25rem;
	border: 0;
	border-radius: 6px;
	outline: 0;
	background: transparent;
	color: var(--gtt-text);
	font: inherit;
	font-size: .82rem;
	font-weight: 740;

	&:focus {
		background: var(--gtt-panel-soft);
		box-shadow: 0 0 0 1px var(--gtt-border-strong);
	}
}

.personal-board__done {
	color: var(--success);
	font-weight: 800;
}

.personal-board__actions {
	display: flex;
	align-items: center;
	gap: .35rem;
	color: var(--gtt-text-soft);
	font-size: .7rem;
}

.personal-board__delete {
	padding: .1rem;
	border: 0;
	background: transparent;
	color: var(--gtt-text-faint);
	font-size: 1.15rem;
	line-height: 1;
	cursor: pointer;

	&:disabled {
		opacity: .3;
		cursor: not-allowed;
	}
}

.personal-board__tasks {
	display: flex;
	flex-direction: column;
	gap: .5rem;
	min-block-size: 330px;
	padding: .55rem;
}

.personal-board__task-create {
	padding: .55rem;
	border-block-start: 1px solid var(--gtt-border);
	background: var(--gtt-panel);
}

.personal-board__task-add {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: .4rem;
	inline-size: 100%;
	min-block-size: 38px;
	padding: .45rem .6rem;
	border: 1px dashed var(--gtt-border-strong);
	border-radius: 9px;
	background: transparent;
	color: var(--gtt-green-800);
	font-size: .76rem;
	font-weight: 680;
	cursor: pointer;
	transition:
		background-color 120ms ease,
		border-color 120ms ease;

	span {
		font-size: 1rem;
		line-height: 1;
	}

	&:hover {
		border-color: var(--gtt-green-700);
		background: var(--gtt-green-100);
	}
}

.personal-board__task-create-head {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: .5rem;
	margin-block-end: .4rem;
	color: var(--gtt-text-soft);
	font-size: .7rem;
	font-weight: 700;
}

.personal-board__task-create-close {
	display: grid;
	place-items: center;
	inline-size: 24px;
	block-size: 24px;
	padding: 0;
	border: 0;
	border-radius: 7px;
	background: transparent;
	color: var(--gtt-text-faint);
	font-size: 1rem;
	line-height: 1;
	cursor: pointer;

	&:hover {
		background: var(--gtt-panel-soft);
		color: var(--gtt-red);
	}
}

.personal-board__task-create :deep(.task-add) {
	padding: .4rem;
	border-color: var(--gtt-border);
	border-radius: 10px;
	background: var(--gtt-panel-soft);
	box-shadow: none;
}

.personal-board__task-create :deep(.task-add .add-task__field) {
	flex-direction: column;
	gap: .35rem;
}

.personal-board__task-create :deep(.task-input-wrapper) {
	inline-size: 100%;
}

.personal-board__task-create :deep(.add-task-button) {
	inline-size: 100%;
	min-inline-size: 0;
	min-block-size: 36px;
}

.personal-board__task-create :deep(.add-task-button .button-text) {
	display: inline;
}

.personal-board__ghost {
	opacity: .35;
}

.personal-board__dragging {
	opacity: .65;
}

.personal-board__column--new {
	display: flex;
	flex-direction: column;
	gap: .75rem;
	min-block-size: 0;
	padding: .75rem;
	border-block-start-color: var(--gtt-border-strong);
	border-style: dashed;
	background: transparent;
	box-shadow: none;
}

.personal-board__add {
	inline-size: 100%;
	padding: .7rem;
	border: 0;
	border-radius: 9px;
	background: transparent;
	color: var(--gtt-green-800);
	font-size: .78rem;
	font-weight: 680;
	cursor: pointer;

	&:hover {
		background: var(--gtt-green-100);
	}
}

.personal-board__new-actions {
	display: flex;
	gap: .5rem;

	button {
		padding: .45rem .65rem;
		border: 1px solid var(--gtt-border);
		border-radius: 8px;
		background: var(--gtt-panel);
		color: var(--gtt-text);
		cursor: pointer;
	}
}

@media screen and (max-width: $tablet) {
	.personal-board__column {
		flex-basis: 270px;
		inline-size: 270px;
	}
}
</style>
