<template>
	<Dropdown v-if="canManageProjects || isSavedFilter(project) || canMoveProjectToFolder">
		<template #trigger="triggerProps">
			<slot
				name="trigger"
				v-bind="triggerProps"
			>
				<BaseButton
					class="dropdown-trigger"
					:aria-expanded="triggerProps.open"
					@click="triggerProps.toggleOpen"
				>
					<span class="is-sr-only">{{ $t('project.openSettingsMenu') }}</span>
					<Icon
						icon="ellipsis-h"
						class="icon"
					/>
				</BaseButton>
			</slot>
		</template>

		<template v-if="compactCardActions">
			<DropdownItem
				v-if="!project.isArchived"
				icon="check"
				@click="toggleProjectCompleted"
			>
				{{ project.isCompleted ? reopenProjectLabel : completeProjectLabel }}
			</DropdownItem>

			<DropdownItem
				v-if="canMoveProjectToFolder"
				icon="folder"
				@click="showMoveChoices = !showMoveChoices"
			>
				{{ moveProjectLabel }}
			</DropdownItem>

			<template v-if="canMoveProjectToFolder && showMoveChoices">
				<DropdownItem
					v-if="currentFolderId !== 0"
					icon="folder"
					class="compact-move-target"
					@click="moveProjectToFolder(0)"
				>
					{{ projectRootLabel }}
				</DropdownItem>

				<DropdownItem
					v-for="folder in availableProjectFolderOptions"
					:key="`compact-move-folder-${folder.id}`"
					icon="folder"
					class="compact-move-target"
					@click="moveProjectToFolder(folder.id)"
				>
					{{ folder.label }}
				</DropdownItem>
			</template>

			<DropdownItem
				v-tooltip="isDefaultProject ? $t('menu.cantArchiveIsDefault') : ''"
				:to="{ name: 'project.settings.archive', params: { projectId: project.id } }"
				icon="archive"
				:disabled="isDefaultProject"
			>
				{{ project.isArchived ? $t('menu.unarchive') : $t('menu.archive') }}
			</DropdownItem>

			<DropdownItem
				v-if="forceAllActions || project.maxPermission === PERMISSIONS.ADMIN"
				v-tooltip="isDefaultProject ? $t('menu.cantDeleteIsDefault') : ''"
				:to="{ name: 'project.settings.delete', params: { projectId: project.id } }"
				icon="trash-alt"
				class="has-text-danger"
				:disabled="isDefaultProject"
			>
				{{ $t('menu.delete') }}
			</DropdownItem>
		</template>

		<template v-else-if="isSavedFilter(project)">
			<DropdownItem
				:to="{ name: 'filter.settings.edit', params: { projectId: project.id } }"
				icon="pen"
			>
				{{ $t('menu.edit') }}
			</DropdownItem>
			<DropdownItem
				:to="{ name: 'project.settings.views', params: { projectId: project.id } }"
				icon="eye"
			>
				{{ $t('menu.views') }}
			</DropdownItem>
			<slot name="before-delete" />
			<DropdownItem
				:to="{ name: 'filter.settings.delete', params: { projectId: project.id } }"
				icon="trash-alt"
				class="has-text-danger"
			>
				{{ $t('misc.delete') }}
			</DropdownItem>
		</template>

		<template v-else-if="project.isArchived">
			<DropdownItem
				:to="{ name: 'project.settings.archive', params: { projectId: project.id } }"
				icon="archive"
			>
				{{ $t('menu.unarchive') }}
			</DropdownItem>
		</template>
		<template v-else>
			<DropdownItem
				:to="{ name: 'project.settings.edit', params: { projectId: project.id } }"
				icon="pen"
			>
				{{ $t('menu.edit') }}
			</DropdownItem>
			<DropdownItem
				:to="{ name: 'project.settings.views', params: { projectId: project.id } }"
				icon="eye"
			>
				{{ $t('menu.views') }}
			</DropdownItem>
			<DropdownItem
				v-if="backgroundsEnabled"
				:to="{ name: 'project.settings.background', params: { projectId: project.id } }"
				icon="image"
			>
				{{ $t('menu.setBackground') }}
			</DropdownItem>
			<DropdownItem
				:to="{ name: 'project.settings.share', params: { projectId: project.id } }"
				icon="share-alt"
			>
				{{ $t('menu.share') }}
			</DropdownItem>
			<DropdownItem
				:to="{ name: 'project.settings.duplicate', params: { projectId: project.id } }"
				icon="paste"
			>
				{{ $t('menu.duplicate') }}
			</DropdownItem>
			<DropdownItem
				v-tooltip="isDefaultProject ? $t('menu.cantArchiveIsDefault') : ''"
				:to="{ name: 'project.settings.archive', params: { projectId: project.id } }"
				icon="archive"
				:disabled="isDefaultProject"
			>
				{{ $t('menu.archive') }}
			</DropdownItem>
			<Subscription
				class="has-no-shadow"
				:is-button="false"
				entity="project"
				:entity-id="project.id"
				:model-value="project.subscription"
				type="dropdown"
				@update:modelValue="setSubscriptionInStore"
			/>
			<DropdownItem
				:to="{ name: 'project.settings.webhooks', params: { projectId: project.id } }"
				icon="bolt"
			>
				{{ $t('project.webhooks.title') }}
			</DropdownItem>

			<template v-if="canMoveProjectToFolder">
				<DropdownItem
					v-if="currentFolderId !== 0"
					icon="folder"
					@click="moveProjectToFolder(0)"
				>
					Переместить в корень проектов
				</DropdownItem>
				<DropdownItem
					v-for="folder in availableProjectFolderOptions"
					:key="`move-folder-${folder.id}`"
					icon="folder"
					@click="moveProjectToFolder(folder.id)"
				>
					В папку: {{ folder.label }}
				</DropdownItem>
			</template>

			<DropdownItem
				:to="{ name: 'project.createFromParent', params: { parentProjectId: project.id } }"
				icon="layer-group"
			>
				{{ $t('menu.createProject') }}
			</DropdownItem>
			<slot name="before-delete" />
			<DropdownItem
				v-if="forceAllActions || project.maxPermission === PERMISSIONS.ADMIN"
				v-tooltip="isDefaultProject ? $t('menu.cantDeleteIsDefault') : ''"
				:to="{ name: 'project.settings.delete', params: { projectId: project.id } }"
				icon="trash-alt"
				class="has-text-danger"
				:disabled="isDefaultProject"
			>
				{{ $t('menu.delete') }}
			</DropdownItem>
		</template>
	</Dropdown>
</template>

<script setup lang="ts">
import {computed, onMounted, ref, watchEffect} from 'vue'

import BaseButton from '@/components/base/BaseButton.vue'
import Dropdown from '@/components/misc/Dropdown.vue'
import DropdownItem from '@/components/misc/DropdownItem.vue'
import Subscription from '@/components/misc/Subscription.vue'
import type {IProject} from '@/modelTypes/IProject'
import type {IProjectFolder} from '@/modelTypes/IProjectFolder'
import type {ISubscription} from '@/modelTypes/ISubscription'

import {isSavedFilter} from '@/services/savedFilter'
import {useConfigStore} from '@/stores/config'
import {useProjectStore} from '@/stores/projects'
import {useAuthStore} from '@/stores/auth'
import {useProjectFolderStore} from '@/stores/projectFolders'
import {PERMISSIONS} from '@/constants/permissions'
import {useAccessStore} from '@/stores/access'
import {ACCESS_PERMISSION} from '@/modelTypes/IAccessControl'

const props = withDefaults(defineProps<{
	project: IProject
	forceAllActions?: boolean
	compactCardActions?: boolean
}>(), {
	forceAllActions: false,
	compactCardActions: false,
})

const projectStore = useProjectStore()
const accessStore = useAccessStore()
const authStore = useAuthStore()
const folderStore = useProjectFolderStore()

const canManageProjects = computed(() => accessStore.can(ACCESS_PERMISSION.PROJECTS_MANAGE))
const subscription = ref<ISubscription | null>(null)
watchEffect(() => {
	subscription.value = props.project.subscription ?? null
})

const configStore = useConfigStore()
const backgroundsEnabled = computed(() => configStore.enabledBackgroundProviders?.length > 0)

function setSubscriptionInStore(sub: ISubscription) {
	subscription.value = sub
	const updatedProject = {
		...props.project,
		subscription: sub,
	}
	projectStore.setProject(updatedProject)
}

const isDefaultProject = computed(() => props.project?.id === authStore.settings.defaultProjectId)
const isInstanceAdmin = computed(() => Boolean(authStore.info?.isAdmin))
const currentFolderId = computed(() => folderStore.getProjectFolderId(props.project.id))
const showMoveChoices = ref(false)

const completeProjectLabel = '\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044c \u043f\u0440\u043e\u0435\u043a\u0442'
const reopenProjectLabel = '\u0412\u0435\u0440\u043d\u0443\u0442\u044c \u0432 \u0440\u0430\u0431\u043e\u0442\u0443'
const moveProjectLabel = '\u041f\u0435\u0440\u0435\u043c\u0435\u0441\u0442\u0438\u0442\u044c'
const projectRootLabel = '\u041f\u0440\u043e\u0435\u043a\u0442\u044b (\u043a\u043e\u0440\u0435\u043d\u044c)'

const canMoveProjectToFolder = computed(() =>
	!isSavedFilter(props.project) &&
	!props.project.isArchived &&
	props.project.parentProjectId === 0 &&
	!isDefaultProject.value &&
	(isInstanceAdmin.value || props.project.maxPermission === PERMISSIONS.ADMIN),
)

type FolderMoveOption = {
	id: number,
	label: string,
}

function getFolderPath(folder: IProjectFolder) {
	const labels: string[] = []
	const visited = new Set<number>()
	let current: IProjectFolder | undefined = folder

	while (current && !visited.has(current.id)) {
		visited.add(current.id)
		labels.unshift(current.title)
		current = folderStore.foldersArray.find(candidate => candidate.id === current?.parentFolderId)
	}

	return labels.join(' / ')
}

const projectFolderOptions = computed<FolderMoveOption[]>(() =>
	folderStore.foldersArray.map(folder => ({
		id: folder.id,
		label: getFolderPath(folder),
	})),
)

const availableProjectFolderOptions = computed(() =>
	projectFolderOptions.value.filter(folder => folder.id !== currentFolderId.value),
)

async function toggleProjectCompleted() {
	await projectStore.toggleProjectCompleted(props.project)
}
async function moveProjectToFolder(folderId: number) {
	await folderStore.setProjectPlacement(props.project.id, folderId)
	showMoveChoices.value = false
}

onMounted(() => {
	if (!folderStore.isLoaded && !folderStore.isLoading) {
		void folderStore.load()
	}
})
</script>
