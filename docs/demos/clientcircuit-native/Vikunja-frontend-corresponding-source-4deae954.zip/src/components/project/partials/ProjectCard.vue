<template>
	<div
		class="project-card"
		:class="{
			'has-light-text': background !== null,
			'has-background': blurHashUrl !== '' || background !== null,
			'is-due-soon': Boolean(props.dueDate) && !project.isCompleted
		}"
		:style="{
			'border-inline-start': project.hexColor ? `0.25rem solid ${project.hexColor}` : undefined,
			'background-image': blurHashUrl !== '' ? `url(${blurHashUrl})` : undefined,
		}"
	>
		<div
			class="project-background background-fade-in"
			:class="{'is-visible': background}"
			:style="{'background-image': background !== null ? `url(${background})` : undefined}"
		/>
		<span
			v-if="project.isArchived"
			class="is-archived"
		>{{ $t('project.archived') }}</span>

		<div
			class="project-title"
			aria-hidden="true"
		>
			<span
				v-if="project.id < -1"
				class="saved-filter-icon icon"
			>
				<Icon icon="filter" />
			</span>
			<span
				v-if="project.isCompleted"
				class="completed-badge"
			>
				{{ '\u0412\u044b\u043f\u043e\u043b\u043d\u0435\u043d' }}
			</span>
			{{ getProjectTitle(project) }}
		</div>

		<div
			v-if="props.dueDate && !project.isCompleted"
			class="due-warning"
		>
			нужно выполнить задачу до {{ dueDateText }}
		</div>
		<BaseButton
			class="project-button"
			:aria-label="project.title"
			:title="textOnlyDescription"
			:to="{
				name: 'project.index',
				params: { projectId: project.id}
			}"
		/>
		<BaseButton
			v-if="canManageProjects && !project.isArchived && project.id > 0"
			class="complete-toggle"
			:aria-label="project.isCompleted ? '\u0412\u0435\u0440\u043d\u0443\u0442\u044c \u0432 \u0440\u0430\u0431\u043e\u0442\u0443' : '\u041e\u0442\u043c\u0435\u0442\u0438\u0442\u044c \u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u043d\u044b\u043c'"
			:title="project.isCompleted ? '\u0412\u0435\u0440\u043d\u0443\u0442\u044c \u0432 \u0440\u0430\u0431\u043e\u0442\u0443' : '\u041e\u0442\u043c\u0435\u0442\u0438\u0442\u044c \u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u043d\u044b\u043c'"
			@click.prevent.stop="toggleCompleted"
		>
			{{ project.isCompleted ? '\u21B6' : '\u2713' }}
		</BaseButton>
		<BaseButton
			v-if="!project.isArchived && project.id > -1"
			class="favorite"
			:aria-label="project.isFavorite ? $t('project.unfavorite') : $t('project.favorite')"
			:class="{'is-favorite': project.isFavorite}"
			@click.prevent.stop="projectStore.toggleProjectFavorite(project)"
		>
			<Icon :icon="project.isFavorite ? 'star' : ['far', 'star']" />
		</BaseButton>
	</div>
</template>

<script lang="ts" setup>
import {computed} from 'vue'
import type {IProject} from '@/modelTypes/IProject'

import BaseButton from '@/components/base/BaseButton.vue'

import {useProjectBackground} from '@/composables/useProjectBackground'
import {useProjectStore} from '@/stores/projects'
import {useAccessStore} from '@/stores/access'
import {ACCESS_PERMISSION} from '@/modelTypes/IAccessControl'
import {getProjectTitle} from '@/helpers/getProjectTitle'

const props = defineProps<{
	project: IProject,
	 dueDate?: string | null,
}>()

const {background, blurHashUrl} = useProjectBackground(() => props.project)

const projectStore = useProjectStore()
const accessStore = useAccessStore()

const canManageProjects = computed(() =>
	accessStore.can(ACCESS_PERMISSION.PROJECTS_MANAGE),
)

async function toggleCompleted() {
	await projectStore.toggleProjectCompleted(props.project)
}

const dueDateText = computed(() => {
	if (!props.dueDate) {
		return ''
	}

	const date = new Date(props.dueDate)

	return new Intl.DateTimeFormat('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
	}).format(date)
})
const textOnlyDescription = computed(() => {
	return props.project.description ? props.project.description.replace(/<[^>]*>/g, '') : ''
})
</script>

<style lang="scss" scoped>
.project-card {
	--project-card-padding: 1rem;

	position: relative;
	display: flex;
	justify-content: space-between;
	flex-wrap: wrap;
	block-size: 100%;
	padding: var(--project-card-padding);
	overflow: hidden;
	border: 1px solid var(--gtt-border);
	border-radius: var(--gtt-radius-lg);
	background:
		linear-gradient(
			145deg,
			var(--gtt-panel),
			var(--gtt-panel-soft)
		);
	box-shadow: var(--gtt-shadow-sm);
	transition:
		border-color 140ms ease,
		box-shadow 140ms ease;

	&:hover {
		border-color: var(--gtt-border-strong);
		box-shadow: var(--gtt-shadow-md);
	}

	&:active,
	&:focus {
		box-shadow: var(--gtt-shadow-xs) !important;
	}

	> * {
		position: relative;
		z-index: 2;
	}
}

.has-background,
.project-background {
	background-repeat: no-repeat;
	background-position: center;
	background-size: cover;
}

.project-background,
.project-button {
	position: absolute;
	inset: 0;
}

.project-background {
	z-index: 0;
}

.project-button {
	z-index: 1;
}

.has-background::after {
	content: '';
	position: absolute;
	inset: 0;
	z-index: 1;
	background:
		linear-gradient(
			180deg,
			transparent 18%,
			rgba(7, 31, 25, .72) 100%
		);
	pointer-events: none;
}

.is-archived {
	font-size: .7rem;
}

.project-title {
	align-self: flex-end;
	inline-size: 100%;
	max-block-size: calc(100% - 2rem);
	margin: 0;
	overflow: hidden;
	color: var(--gtt-text);
	font-family: $vikunja-font;
	font-size: 1.05rem;
	font-weight: 730;
	letter-spacing: -.02em;
	line-height: 1.25;
	text-overflow: ellipsis;
	word-break: break-word;

	display: -webkit-box;
	-webkit-box-orient: vertical;
	-webkit-line-clamp: 3;
}

.has-light-text .project-title,
.has-background .project-title {
	color: var(--white);
	text-shadow: 0 2px 10px rgba(0, 0, 0, .42);
}

.project-card.is-due-soon {
	padding-block-end: 3rem;
	border-color: color-mix(
		in srgb,
		var(--gtt-red) 55%,
		var(--gtt-border)
	);
	background:
		color-mix(
			in srgb,
			var(--gtt-red) 8%,
			var(--gtt-panel)
		) !important;

	.project-background {
		opacity: .08 !important;
	}
}

.due-warning {
	position: absolute;
	inset-inline: var(--project-card-padding);
	inset-block-end: .65rem;
	z-index: 3;
	color: var(--gtt-red);
	font-size: .68rem;
	font-weight: 650;
	line-height: 1.25;
}

.completed-badge {
	display: inline-block;
	margin-inline-end: .4rem;
	padding: .2rem .4rem;
	border-radius: 6px;
	background: var(--success);
	color: var(--white);
	font-size: .65rem;
	font-weight: 650;
}

.complete-toggle {
	position: absolute;
	inset-block-start: var(--project-card-padding);
	inset-inline-start: var(--project-card-padding);
	z-index: 4;
	min-inline-size: 2rem;
	min-block-size: 2rem;
	border-radius: 9px;
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);
	font-weight: 700;
}

.favorite {
	position: absolute;
	inset-block-start: var(--project-card-padding);
	inset-inline-end: var(--project-card-padding);
	z-index: 4;
	color: var(--white);
	opacity: 1;
	transition:
		opacity 120ms ease,
		color 120ms ease;

	&:hover,
	&.is-favorite {
		color: var(--warning);
	}
}

.project-card:not(.has-background) .favorite {
	color: var(--gtt-text-faint);

	&:hover,
	&.is-favorite {
		color: var(--warning);
	}
}

@media (hover: hover) and (pointer: fine) {
	.project-card .favorite {
		opacity: 0;
	}

	.project-card:hover .favorite,
	.project-card .favorite.is-favorite {
		opacity: 1;
	}
}

.background-fade-in {
	opacity: 0;
	transition: opacity $transition;
	transition-delay: $transition-duration * 2;

	&.is-visible {
		opacity: 1;
	}
}

.saved-filter-icon {
	color: var(--gtt-text-faint);
	font-size: .75em;
}
</style>


