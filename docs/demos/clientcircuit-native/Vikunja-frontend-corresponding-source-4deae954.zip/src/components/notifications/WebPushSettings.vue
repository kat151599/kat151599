<template>
	<div class="web-push-settings">
		<p class="help mb-2">
			{{ $t('webPush.description') }}
		</p>

		<p
			v-if="state === 'requires-install'"
			class="help"
		>
			{{ $t('webPush.requiresInstall') }}
		</p>
		<p
			v-else-if="state === 'blocked'"
			class="help"
		>
			{{ $t('webPush.blocked') }}
		</p>
		<p
			v-else-if="state === 'unsupported'"
			class="help"
		>
			{{ $t('webPush.unsupported') }}
		</p>
		<p
			v-else-if="state === 'not-configured'"
			class="help"
		>
			{{ $t('webPush.notConfigured') }}
		</p>

		<XButton
			v-if="state === 'available'"
			:loading="loading"
			@click="enable"
		>
			{{ $t('webPush.enable') }}
		</XButton>
		<XButton
			v-else-if="state === 'enabled'"
			variant="tertiary"
			:loading="loading"
			@click="disable"
		>
			{{ $t('webPush.disable') }}
		</XButton>

		<p
			v-if="state === 'enabled'"
			class="help mt-2"
		>
			{{ $t('webPush.enabled') }}
		</p>
	</div>
</template>

<script setup lang="ts">
import {onMounted, ref} from 'vue'
import {useI18n} from 'vue-i18n'

import XButton from '@/components/input/Button.vue'
import {
	disableWebPush,
	enableWebPush,
	getWebPushState,
	type WebPushState,
} from '@/helpers/webPush'
import {error, success} from '@/message'

const {t} = useI18n({useScope: 'global'})
const state = ref<WebPushState>('unsupported')
const loading = ref(false)

async function refresh() {
	try {
		state.value = await getWebPushState()
	} catch (e) {
		console.warn('[Vikunja] Could not read web push state:', e)
		state.value = 'not-configured'
	}
}

async function enable() {
	loading.value = true
	try {
		await enableWebPush()
		await refresh()
		success({message: t('webPush.enabledSuccess')})
	} catch (e) {
		error(e)
	} finally {
		loading.value = false
	}
}

async function disable() {
	loading.value = true
	try {
		await disableWebPush()
		await refresh()
		success({message: t('webPush.disabledSuccess')})
	} catch (e) {
		error(e)
	} finally {
		loading.value = false
	}
}

onMounted(refresh)
</script>

<style lang="scss" scoped>
.web-push-settings {
	padding-block-start: .5rem;
}
</style>
