<template>
	<div class="content-widescreen">
		<div class="side-nav-shell">
			<nav class="navigation">
				<ul>
					<li
						v-for="(item, index) in navigationItems"
						:key="`nav-${index}`"
					>
						<RouterLink
							v-slot="{href, navigate, isActive, isExactActive}"
							:to="{name: item.routeName}"
							custom
						>
							<a
								:href="href"
								class="navigation-link"
								:class="{'is-active': (exact ? isExactActive : isActive) || isAliasActive(item)}"
								@click="navigate"
							>
								{{ item.title }}
							</a>
						</RouterLink>
					</li>
					<li
						v-for="({url, text}, index) in extraLinks"
						:key="`extra-${index}`"
					>
						<BaseButton
							class="navigation-link is-flex is-align-items-center"
							:href="url"
						>
							<span>
								{{ text }}
							</span>
							<span class="ml-1 has-text-grey-light is-size-7">
								<Icon
									icon="arrow-up-right-from-square"
								/>
							</span>
						</BaseButton>
					</li>
				</ul>
			</nav>
			<section class="view">
				<RouterView />
			</section>
		</div>
	</div>
</template>

<script setup lang="ts">
import {useRoute} from 'vue-router'

import BaseButton from '@/components/base/BaseButton.vue'

export interface SideNavItem {
	title: string
	routeName: string
	activeRouteNames?: string[]
}

export interface SideNavExtraLink {
	url: string
	text: string
}

withDefaults(defineProps<{
	navigationItems: SideNavItem[]
	extraLinks?: SideNavExtraLink[]
	exact?: boolean
}>(), {
	extraLinks: () => [],
	exact: false,
})

const route = useRoute()

function isAliasActive(item: SideNavItem) {
	return item.activeRouteNames?.includes(route.name as string) ?? false
}
</script>

<style lang="scss" scoped>
.side-nav-shell {
	display: grid;
	grid-template-columns: minmax(190px, 230px) minmax(0, 1fr);
	gap: 1.25rem;
	align-items: start;

	@media screen and (max-width: $tablet) {
		grid-template-columns: 1fr;
	}
}

.navigation {
	position: sticky;
	inset-block-start: calc(#{$navbar-height} + 1rem);
	inline-size: 100%;
	padding: .45rem;
	border: 1px solid var(--gtt-border);
	border-radius: var(--gtt-radius-lg);
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-sm);

	ul {
		margin: 0;
	}
}

.navigation-link {
	display: flex;
	align-items: center;
	inline-size: 100%;
	min-block-size: 42px;
	padding: .6rem .75rem;
	border: 0;
	border-radius: 9px;
	color: var(--gtt-text-soft);
	font-size: .86rem;
	font-weight: 650;
	text-decoration: none;
	transition:
		background-color 120ms ease,
		color 120ms ease;

	&:hover {
		background: var(--gtt-panel-soft);
		color: var(--gtt-text);
	}

	&.is-active {
		background: var(--gtt-green-100);
		color: var(--gtt-green-900);
		font-weight: 720;
	}
}

.view {
	min-inline-size: 0;
	inline-size: 100%;
}

@media screen and (max-width: $tablet) {
	.navigation {
		position: static;
		overflow-x: auto;

		ul {
			display: flex;
			gap: .25rem;
		}

		li {
			flex: 0 0 auto;
		}
	}

	.navigation-link {
		white-space: nowrap;
	}

	.view {
		padding-block-start: 0;
	}
}
</style>
