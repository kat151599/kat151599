<script setup lang="ts">
import BaseButton from '@/components/base/BaseButton.vue'
import {useBaseStore} from '@/stores/base'
import {onBeforeUnmount, onMounted} from 'vue'
import {eventToShortcutString} from '@/helpers/shortcut'
import {isAppleDevice} from '@/helpers/isAppleDevice'

const baseStore = useBaseStore()

const shortcutLabel =
	isAppleDevice()
		? '⌘ K'
		: 'Ctrl + K'

function openQuickActionsViaHotkey(event: KeyboardEvent) {
	const shortcutString = eventToShortcutString(event)

	if (!shortcutString) {
		return
	}

	const expectedShortcut =
		isAppleDevice()
			? 'Meta+KeyK'
			: 'Control+KeyK'

	if (shortcutString !== expectedShortcut) {
		return
	}

	event.preventDefault()
	openQuickActions()
}

onMounted(() => {
	document.addEventListener(
		'keydown',
		openQuickActionsViaHotkey,
	)
})

onBeforeUnmount(() => {
	document.removeEventListener(
		'keydown',
		openQuickActionsViaHotkey,
	)
})

function openQuickActions() {
	baseStore.setQuickActionsActive(true)
}
</script>

<template>
	<BaseButton
		class="trigger-button quick-search-trigger"
		:title="$t('keyboardShortcuts.quickSearch')"
		:aria-label="$t('keyboardShortcuts.quickSearch')"
		@click="openQuickActions"
	>
		<span class="quick-search-icon">
			<Icon icon="search" />
		</span>

		<span class="quick-search-label">
			Поиск задач, проектов, пользователей...
		</span>

		<kbd class="quick-search-shortcut">
			{{ shortcutLabel }}
		</kbd>
	</BaseButton>
</template>

<style lang="scss" scoped>
.quick-search-trigger {
	display: flex;
	align-items: center;
	gap: .65rem;
	inline-size: min(42vw, 680px);
	min-block-size: 42px;
	padding: .45rem .55rem .45rem .8rem;
	border: 1px solid var(--gtt-border);
	border-radius: 11px;
	background: var(--gtt-panel);
	color: var(--gtt-text-soft);
	box-shadow: var(--gtt-shadow-xs);
	text-align: start;
	transition:
		border-color 140ms ease,
		box-shadow 140ms ease,
		background-color 140ms ease;

	&:hover {
		border-color: var(--gtt-border-strong);
		background: var(--gtt-canvas-soft);
		color: var(--gtt-text);
		box-shadow: var(--gtt-shadow-sm);
	}

	&:focus-visible {
		outline: none;
		border-color: var(--gtt-green-700);
		box-shadow: var(--focus-ring);
	}
}

.quick-search-icon {
	display: grid;
	place-items: center;
	flex: 0 0 auto;
	color: var(--gtt-text-soft);
}

.quick-search-label {
	flex: 1 1 auto;
	min-inline-size: 0;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
	font-size: .84rem;
}

.quick-search-shortcut {
	flex: 0 0 auto;
	padding: .22rem .42rem;
	border: 1px solid var(--gtt-border);
	border-radius: 6px;
	background: var(--gtt-panel-soft);
	color: var(--gtt-text-soft);
	font-family: inherit;
	font-size: .68rem;
	line-height: 1;
	box-shadow: none;
}

@media screen and (max-width: $tablet) {
	.quick-search-trigger {
		inline-size: 42px;
		min-inline-size: 42px;
		padding: 0;
		justify-content: center;
		border-color: transparent;
		background: transparent;
		box-shadow: none;
	}

	.quick-search-label,
	.quick-search-shortcut {
		display: none;
	}
}
</style>