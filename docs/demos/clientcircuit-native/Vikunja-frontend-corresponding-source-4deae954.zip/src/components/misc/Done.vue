<template>
	<div
		v-if="isDone"
		v-bind="$attrs"
		class="is-done"
		:class="{ 'is-done--small': variant === 'small' }"
	>
		{{ $t('task.attributes.done') }}
	</div>
</template>

<script lang="ts" setup>
withDefaults(defineProps<{
	isDone?: boolean
	variant?: 'default' | 'small'
}>(), {
	isDone: false,
	variant: 'default',
})
defineOptions({inheritAttrs: false})
</script>


<style lang="scss" scoped>
.is-done {
  // bright brand green with fixed dark text passes contrast in both themes
  background: var(--success);
  color: hsl(215, 27.9%, 16.9%);
  padding: .5rem;
  font-weight: bold;
  line-height: 1;
  border-radius: 4px;
  text-align: center;
}

.is-done--small {
	padding: .2rem .3rem;
}
</style>
