<template>
	<div class="dashboard-tabs">
		<div
			v-for="tab in tabs"
			:key="tab.id"
			class="dashboard-tabs__item"
		>
			<input
				v-if="editing && tab.id === activeTabId"
				class="dashboard-tabs__input"
				:value="tab.title"
				aria-label="Название вкладки"
				@change="renameTab(tab.id, $event)"
			>

			<button
				v-else
				type="button"
				class="dashboard-tabs__tab"
				:class="{'is-active': tab.id === activeTabId}"
				@click="$emit('select', tab.id)"
			>
				{{ tab.title }}
			</button>

			<button
				v-if="editing && tabs.length > 1"
				type="button"
				class="dashboard-tabs__delete"
				aria-label="Удалить вкладку"
				@click="$emit('delete', tab.id)"
			>
				×
			</button>
		</div>

		<button
			v-if="editing"
			type="button"
			class="dashboard-tabs__add"
			aria-label="Добавить вкладку"
			@click="$emit('add')"
		>
			+
		</button>
	</div>
</template>

<script setup lang="ts">
import type {IDashboardTab} from '@/modelTypes/IDashboard'

defineProps<{
tabs: IDashboardTab[]
activeTabId: string
editing: boolean
}>()

const emit = defineEmits<{
select: [tabId: string]
add: []
delete: [tabId: string]
rename: [tabId: string, title: string]
}>()

function renameTab(tabId: string, event: Event) {
	const input = event.target as HTMLInputElement
	emit('rename', tabId, input.value)
}
</script>

<style lang="scss" scoped>
.dashboard-tabs {
	display: flex;
	align-items: center;
	gap: .35rem;
	min-inline-size: 0;
	padding: .25rem;
	border: 1px solid var(--gtt-border);
	border-radius: 12px;
	background: var(--gtt-panel);
	box-shadow: var(--gtt-shadow-xs);
	overflow-x: auto;
}

.dashboard-tabs__item {
	display: flex;
	align-items: center;
	flex: 0 0 auto;
}

.dashboard-tabs__tab,
.dashboard-tabs__add {
	padding: .5rem .75rem;
	border: 0;
	border-radius: 8px;
	background: transparent;
	color: var(--gtt-text-soft);
	font-size: .82rem;
	font-weight: 650;
	cursor: pointer;

	&:hover {
		background: var(--gtt-panel-soft);
		color: var(--gtt-text);
	}

	&.is-active {
		background: var(--gtt-green-100);
		color: var(--gtt-green-900);
		font-weight: 720;
	}
}

.dashboard-tabs__input {
	inline-size: 160px;
	margin: .15rem;
	padding: .42rem .55rem;
	border: 1px solid var(--gtt-border);
	border-radius: 8px;
	background: var(--gtt-panel);
	color: var(--gtt-text);
}

.dashboard-tabs__delete {
	inline-size: 28px;
	block-size: 28px;
	padding: 0;
	border: 0;
	border-radius: 7px;
	background: transparent;
	color: var(--gtt-text-faint);
	cursor: pointer;

	&:hover {
		background: var(--gtt-panel-soft);
		color: var(--danger);
	}
}

.dashboard-tabs__add {
	font-size: 1rem;
}
</style>