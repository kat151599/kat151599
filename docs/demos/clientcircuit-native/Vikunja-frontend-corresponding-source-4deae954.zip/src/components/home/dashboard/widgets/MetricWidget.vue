<template>
	<div class="metric-widget">
		<div
			v-for="stat in stats"
			:key="stat.label"
			class="metric-widget__item"
			:class="`metric-widget__item--${stat.tone}`"
		>
			<span class="metric-widget__label">
				{{ stat.label }}
			</span>

			<strong class="metric-widget__value">
				{{ stat.value }}
			</strong>

			<span class="metric-widget__hint">
				{{ stat.hint }}
			</span>
		</div>
	</div>
</template>

<script setup lang="ts">
import {computed, onMounted} from 'vue'

import {useMyTasksStore} from '@/stores/myTasks'
import {useProjectStore} from '@/stores/projects'

const taskStore = useMyTasksStore()
const projectStore = useProjectStore()

function startOfDay(date: Date): Date {
	const result = new Date(date)

	result.setHours(0, 0, 0, 0)

	return result
}

const activeTasks = computed(() =>
	taskStore.tasks.filter(task => !task.done),
)

const overdueTasks = computed(() => {
	const today = startOfDay(new Date())

	return activeTasks.value.filter(task => {
		if (!task.dueDate) {
			return false
		}

		return new Date(task.dueDate).getTime() < today.getTime()
	}).length
})

const todayTasks = computed(() => {
	const today = startOfDay(new Date())
	const tomorrow = new Date(today)

	tomorrow.setDate(tomorrow.getDate() + 1)

	return activeTasks.value.filter(task => {
		if (!task.dueDate) {
			return false
		}

		const timestamp =
			new Date(task.dueDate).getTime()

		return (
			timestamp >= today.getTime() &&
			timestamp < tomorrow.getTime()
		)
	}).length
})

const projectCount = computed(() =>
	projectStore.projectsArray.filter(project =>
		project.id > 0 &&
		!project.isArchived,
	).length,
)

const stats = computed(() => [
	{
		label: 'Активные задачи',
		value: activeTasks.value.length,
		hint: 'в работе',
		tone: 'green',
	},
	{
		label: 'На сегодня',
		value: todayTasks.value,
		hint: 'по сроку',
		tone: 'blue',
	},
	{
		label: 'Просрочено',
		value: overdueTasks.value,
		hint:
			overdueTasks.value === 0
				? 'всё спокойно'
				: 'требуют внимания',
		tone:
			overdueTasks.value === 0
				? 'green'
				: 'red',
	},
	{
		label: 'Проекты',
		value: projectCount.value,
		hint: 'активные',
		tone: 'purple',
	},
])

onMounted(async () => {
	const jobs: Promise<unknown>[] = []

	if (taskStore.tasks.length === 0) {
		jobs.push(taskStore.load())
	}

	if (projectStore.projectsArray.length === 0) {
		jobs.push(projectStore.loadAllProjects())
	}

	await Promise.all(jobs)
})
</script>

<style scoped lang="scss">
.metric-widget {
	display: grid;
	grid-template-columns:
		repeat(
			auto-fit,
			minmax(min(100%, 10rem), 1fr)
		);
	gap: .75rem;
}

.metric-widget__item {
	position: relative;
	display: flex;
	flex-direction: column;
	min-inline-size: 0;
	padding: .9rem 1rem;
	border: 1px solid var(--gtt-border);
	border-radius: 13px;
	background: var(--gtt-panel);

	&::before {
		content: '';
		position: absolute;
		inset-block: .75rem;
		inset-inline-start: 0;
		inline-size: 3px;
		border-radius: 999px;
		background: var(--gtt-green-700);
	}

	&--blue::before {
		background: var(--gtt-blue);
	}

	&--red::before {
		background: var(--gtt-red);
	}

	&--purple::before {
		background: var(--gtt-purple);
	}
}

.metric-widget__label {
	color: var(--gtt-text-soft);
	font-size: .74rem;
	font-weight: 650;
	overflow-wrap: anywhere;
}

.metric-widget__value {
	margin-block-start: .15rem;
	color: var(--gtt-text);
	font-size: 1.65rem;
	font-weight: 780;
	letter-spacing: -.045em;
	line-height: 1.1;
}

.metric-widget__hint {
	margin-block-start: .2rem;
	color: var(--gtt-text-faint);
	font-size: .7rem;
	overflow-wrap: anywhere;
}

@container dashboard-widget-content (width <= 700px) {
	.metric-widget {
		grid-template-columns: repeat(2, minmax(0, 1fr));
		gap: .6rem;
	}

	.metric-widget__item {
		padding: .75rem .8rem;
	}

	.metric-widget__label {
		font-size: .7rem;
		line-height: 1.25;
	}

	.metric-widget__value {
		font-size: 1.45rem;
	}

	.metric-widget__hint {
		font-size: .66rem;
	}
}

@container dashboard-widget-content (width <= 300px) {
	.metric-widget {
		grid-template-columns: 1fr;
	}
}
</style>
