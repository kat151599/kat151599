<template>
	<div class="dashboard-widget-picker">
		<select
			v-model="selectedType"
			class="dashboard-widget-picker__select"
		>
			<option
				v-for="option in options"
				:key="option.value"
				:value="option.value"
			>
				{{ option.label }}
			</option>
		</select>

		<XButton
			variant="secondary"
			icon="plus"
			@click="$emit('add', selectedType)"
		>
			Добавить виджет
		</XButton>
	</div>
</template>

<script setup lang="ts">
import {computed, ref, watch} from 'vue'

import XButton from '@/components/input/Button.vue'

import type {DashboardWidgetType} from '@/modelTypes/IDashboard'
import {
	DASHBOARD_WIDGET_TITLES,
	OVERVIEW_DASHBOARD_WIDGET_TYPES,
} from '@/composables/useDashboardLayout'

const props = withDefaults(defineProps<{
	allowedTypes?: DashboardWidgetType[]
}>(), {
	allowedTypes: () => OVERVIEW_DASHBOARD_WIDGET_TYPES,
})

defineEmits<{
	add: [type: DashboardWidgetType]
}>()

const selectedType = ref<DashboardWidgetType>('activities')

const options = computed(() =>
	props.allowedTypes.map(value => ({
		value,
		label: DASHBOARD_WIDGET_TITLES[value],
	})),
)

watch(
	() => props.allowedTypes,
	allowed => {
		if (
			allowed.length > 0 &&
			!allowed.includes(selectedType.value)
		) {
			selectedType.value = allowed[0]
		}
	},
	{
		deep: true,
		immediate: true,
	},
)
</script>

<style lang="scss" scoped>
.dashboard-widget-picker {
	display: flex;
	align-items: center;
	gap: .6rem;
	flex-wrap: wrap;
}

.dashboard-widget-picker__select {
	min-inline-size: 190px;
	block-size: 38px;
	padding-inline: .65rem 2rem;
	border: 1px solid var(--brand-border);
	border-radius: 6px;
	background: var(--white);
	color: var(--text);
}
</style>
