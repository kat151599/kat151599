<template>
	<div
		ref="grid"
		class="dashboard-grid"
	>
		<DashboardWidget
			v-for="widget in widgets"
			:key="widget.id"
			:data-widget-id="widget.id"
			:widget="widget"
			:editing="editing"
			:locked="locked"
			@remove="$emit('remove', widget.id)"
			@settings="$emit('settings', widget.id)"
		>
			<component
				:is="widgetComponent(widget.type)"
				v-if="widgetComponent(widget.type)"
				v-bind="widgetProps(widget)"
			/>

			<div
				v-else
				class="dashboard-widget-placeholder"
			>
				<p>{{ widgetDescription(widget.type) }}</p>
				<span>
					Данные будут подключены на следующем этапе.
				</span>
			</div>
		</DashboardWidget>
	</div>
</template>

<script setup lang="ts">
import {
	type Component,
	nextTick,
	onBeforeUnmount,
	onMounted,
	ref,
	watch,
} from 'vue'
import Sortable from 'sortablejs'

import DashboardWidget from './DashboardWidget.vue'
import ActivitiesWidget from './widgets/ActivitiesWidget.vue'
import CalendarWidget from './widgets/CalendarWidget.vue'
import TasksWidget from './widgets/TasksWidget.vue'
import MetricWidget from './widgets/MetricWidget.vue'
import ActivityStreamWidget from './widgets/ActivityStreamWidget.vue'
import StickyNotes from '@/components/personal/StickyNotes.vue'
import PersonalGantt from '@/components/personal/PersonalGantt.vue'
import PersonalKanban from '@/components/personal/PersonalKanban.vue'
import TaskStatusWidget from './widgets/TaskStatusWidget.vue'

import type {
	DashboardWidgetType,
	IDashboardWidget,
} from '@/modelTypes/IDashboard'

import {
	DASHBOARD_WIDGET_DESCRIPTIONS,
} from '@/composables/useDashboardLayout'

const props = defineProps<{
widgets: IDashboardWidget[]
editing: boolean
locked: boolean
}>()

const emit = defineEmits<{
'update:widgets': [widgets: IDashboardWidget[]]
remove: [widgetId: string]
settings: [widgetId: string]
}>()

const grid = ref<HTMLElement | null>(null)

let sortable: Sortable | null = null

function createSortable() {
	if (!grid.value || sortable !== null) {
		return
	}

	sortable = Sortable.create(grid.value, {
		animation: 150,
		handle: '.dashboard-widget__drag-handle',
		disabled: !props.editing || props.locked,
		onEnd(event) {
			const oldIndex = event.oldIndex
			const newIndex = event.newIndex

			if (
				oldIndex === undefined ||
newIndex === undefined ||
oldIndex === newIndex
			) {
				return
			}

			const reordered = [...props.widgets]
			const [moved] = reordered.splice(oldIndex, 1)

			if (!moved) {
				return
			}

			reordered.splice(newIndex, 0, moved)

			emit('update:widgets', reordered)
		},
	})
}

watch(
	() => [props.editing, props.locked] as const,
	([editing, locked]) => {
		sortable?.option(
			'disabled',
			!editing || locked,
		)
	},
)

onMounted(async () => {
	await nextTick()
	createSortable()
})

onBeforeUnmount(() => {
	sortable?.destroy()
	sortable = null
})

const widgetComponents: Partial<Record<DashboardWidgetType, Component>> = {
	activities: ActivitiesWidget,
	calendar: CalendarWidget,
	recordList: TasksWidget,
	metric: MetricWidget,
	activityStream: ActivityStreamWidget,
	personalNotes: StickyNotes,
	personalTasks: TasksWidget,
	personalTaskStatus: TaskStatusWidget,
	personalGantt: PersonalGantt,
	personalKanban: PersonalKanban,
}

function widgetComponent(type: DashboardWidgetType): Component | undefined {
	return widgetComponents[type]
}

function widgetProps(widget: IDashboardWidget): Record<string, unknown> {
	switch (widget.type) {
		case 'personalNotes':
		case 'personalGantt':
		case 'personalKanban':
			return {embedded: true}
		case 'personalTasks':
			return {autoload: false}
		case 'personalTaskStatus':
			return {widget}
		default:
			return {}
	}
}

function widgetDescription(type: DashboardWidgetType): string {
	return DASHBOARD_WIDGET_DESCRIPTIONS[type]
}
</script>

<style lang="scss" scoped>
.dashboard-grid {
	display: grid;
	grid-template-columns: repeat(12, minmax(0, 1fr));
	align-items: stretch;
	gap: 1.1rem;
	min-block-size: 0;
}

.dashboard-widget-placeholder {
	display: flex;
	flex-direction: column;
	justify-content: center;
	min-block-size: 100px;
	color: var(--gtt-text-soft);

	p {
		margin: 0 0 .35rem;
		color: var(--gtt-text);
		font-weight: 650;
	}

	span {
		font-size: .82rem;
	}
}
</style>