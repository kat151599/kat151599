<template>
	<div class="task-status-widget">
		<div v-if="loading" class="task-status-widget__state">Загрузка…</div>

		<div v-else-if="task" class="task-status-widget__body">
			<RouterLink
				:to="{name: 'task.detail', params: {id: task.id}}"
				class="task-status-widget__title"
			>
				{{ task.title }}
			</RouterLink>

			<div class="task-status-widget__status">
				<span class="task-status-widget__dot" :class="statusClass" />
				<strong>{{ statusLabel }}</strong>
			</div>

			<dl class="task-status-widget__meta">
				<div>
					<dt>Проект</dt>
					<dd>{{ projectTitle }}</dd>
				</div>
				<div>
					<dt>Срок</dt>
					<dd>{{ dueLabel }}</dd>
				</div>
				<div>
					<dt>Прогресс</dt>
					<dd>{{ percentDone }}%</dd>
				</div>
			</dl>

			<div class="task-status-widget__progress">
				<span :style="{width: `${percentDone}%`}" />
			</div>
		</div>

		<div v-else class="task-status-widget__state">
			{{ emptyText }}
		</div>
	</div>
</template>

<script setup lang="ts">
import {computed, ref, watch} from 'vue'

import TaskModel from '@/models/task'
import TaskService from '@/services/task'
import {formatDate} from '@/helpers/time/formatDate'
import {useMyTasksStore} from '@/stores/myTasks'
import {useProjectStore} from '@/stores/projects'

import type {IDashboardWidget} from '@/modelTypes/IDashboard'
import type {ITask} from '@/modelTypes/ITask'

const props = defineProps<{
	widget: IDashboardWidget
}>()

const taskStore = useMyTasksStore()
const projectStore = useProjectStore()
const service = new TaskService()

const fetchedTask = ref<ITask | null>(null)
const loading = ref(false)
let generation = 0

const taskId = computed(() => Number(props.widget.settings.taskId ?? 0))
const task = computed(() =>
	taskStore.tasks.find(item => item.id === taskId.value) ?? fetchedTask.value,
)

const emptyText = computed(() =>
	taskId.value > 0
		? 'Задача недоступна или была удалена.'
		: 'Выберите задачу в настройках виджета.',
)

const statusLabel = computed(() => {
	if (!task.value) return ''
	if (task.value.done) return 'Готово'

	switch (task.value.workflowState) {
		case 'in_progress':
			return 'В работе'
		case 'waiting':
			return 'Ожидает'
		default:
			return 'Новая'
	}
})

const statusClass = computed(() => {
	if (!task.value) return ''
	if (task.value.done) return 'is-done'
	if (task.value.workflowState === 'in_progress') return 'is-progress'
	if (task.value.workflowState === 'waiting') return 'is-waiting'
	return 'is-new'
})

const projectTitle = computed(() => {
	if (!task.value) return '—'
	if (task.value.projectId === 0) return 'Без проекта'

	return projectStore.projects[task.value.projectId]?.title ??
		`#${task.value.projectId}`
})

const dueLabel = computed(() =>
	task.value?.dueDate
		? formatDate(task.value.dueDate, 'D MMMM YYYY')
		: 'Не задан',
)

const percentDone = computed(() => {
	if (!task.value) return 0
	if (task.value.done) return 100

	return Math.round(
		Math.min(1, Math.max(0, task.value.percentDone || 0)) * 100,
	)
})

async function loadSelectedTask() {
	const id = taskId.value
	const currentGeneration = ++generation
	fetchedTask.value = null

	if (
		id <= 0 ||
		taskStore.tasks.some(item => item.id === id)
	) {
		return
	}

	loading.value = true

	try {
		const result = await service.get(new TaskModel({id}))

		if (currentGeneration === generation) {
			fetchedTask.value = result
		}
	} catch {
		if (currentGeneration === generation) {
			fetchedTask.value = null
		}
	} finally {
		if (currentGeneration === generation) {
			loading.value = false
		}
	}
}

watch(
	taskId,
	() => {
		void loadSelectedTask()
	},
	{immediate: true},
)
</script>

<style scoped>
.task-status-widget {
	min-block-size: 150px;
}

.task-status-widget__state {
	display: grid;
	place-items: center;
	min-block-size: 150px;
	padding: 1rem;
	color: var(--gtt-text-soft);
	text-align: center;
}

.task-status-widget__body {
	display: grid;
	gap: 1rem;
}

.task-status-widget__title {
	color: var(--gtt-text);
	font-size: 1rem;
	font-weight: 750;
	line-height: 1.3;
}

.task-status-widget__status {
	display: flex;
	align-items: center;
	gap: .5rem;
	color: var(--gtt-text);
}

.task-status-widget__dot {
	inline-size: 10px;
	block-size: 10px;
	border-radius: 999px;
	background: var(--gtt-text-faint);
}

.task-status-widget__dot.is-done {
	background: var(--success);
}

.task-status-widget__dot.is-progress {
	background: var(--gtt-blue);
}

.task-status-widget__dot.is-waiting {
	background: var(--gtt-yellow);
}

.task-status-widget__dot.is-new {
	background: var(--gtt-red);
}

.task-status-widget__meta {
	display: grid;
	grid-template-columns: repeat(3, minmax(0, 1fr));
	gap: .7rem;
	margin: 0;
}

.task-status-widget__meta div {
	min-width: 0;
}

.task-status-widget__meta dt {
	color: var(--gtt-text-faint);
	font-size: .68rem;
	font-weight: 700;
	text-transform: uppercase;
}

.task-status-widget__meta dd {
	margin: .18rem 0 0;
	color: var(--gtt-text);
	font-size: .78rem;
	font-weight: 650;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.task-status-widget__progress {
	block-size: 7px;
	overflow: hidden;
	border-radius: 999px;
	background: var(--gtt-panel-soft);
}

.task-status-widget__progress span {
	display: block;
	block-size: 100%;
	border-radius: inherit;
	background: var(--gtt-green-700);
}

@media (max-width: 700px) {
	.task-status-widget__meta {
		grid-template-columns: 1fr;
	}
}
</style>
