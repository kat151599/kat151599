<template>
	<div class="root-projects-navigation">
		<menu
			v-if="rootFolders.length > 0"
			class="menu-list can-be-hidden"
		>
			<li
				v-for="folder in rootFolders"
				:key="`root-folder-${folder.id}`"
				class="list-menu root-folder-item"
			>
				<BaseButton
					:to="{
						name: 'projects.index',
						query: {folder: String(folder.id)},
					}"
					class="list-menu-link"
					:class="{
						'router-link-exact-active': currentFolderId === folder.id,
					}"
				>
					<span class="collapse-project-button-placeholder" />

					<span class="icon menu-item-icon root-folder-icon">
						<Icon icon="folder" />
					</span>

					<span class="root-item-title">
						{{ folder.title }}
					</span>
				</BaseButton>
			</li>
		</menu>

		<ProjectsNavigation
			v-if="rootProjects.length > 0"
			:model-value="rootProjects"
			:can-edit-order="false"
			:can-collapse="false"
		/>
	</div>
</template>

<script setup lang="ts">
import {computed, onMounted} from 'vue'
import {useRoute} from 'vue-router'

import BaseButton from '@/components/base/BaseButton.vue'
import ProjectsNavigation from '@/components/home/ProjectsNavigation.vue'

import type {IProject} from '@/modelTypes/IProject'

import {useProjectStore} from '@/stores/projects'
import {useProjectFolderStore} from '@/stores/projectFolders'
import {useAuthStore} from '@/stores/auth'

const route = useRoute()
const projectStore = useProjectStore()
const folderStore = useProjectFolderStore()
const authStore = useAuthStore()

const currentFolderId = computed(() => {
	const raw = Array.isArray(route.query.folder)
		? route.query.folder[0]
		: route.query.folder

	const parsed = Number(raw ?? 0)

	return Number.isInteger(parsed) && parsed > 0
		? parsed
		: 0
})

const rootFolders = computed(() => folderStore.rootFolders)

const rootProjects = computed<IProject[]>(() =>
	projectStore.projectsArray.filter(project =>
		project.id > 0 &&
		project.id !== authStore.settings.defaultProjectId &&
		!project.isArchived &&
		!project.isCompleted &&
		project.parentProjectId === 0 &&
		folderStore.getProjectFolderId(project.id) === 0,
	),
)

onMounted(() => {
	if (!folderStore.isLoaded && !folderStore.isLoading) {
		void folderStore.load()
	}
})
</script>

<style lang="scss" scoped>
.root-projects-navigation {
	min-block-size: 0;
	margin-block-start: .35rem;
	overflow-y: auto;
}

.menu-list {
	margin-block-end: 0;
}

.root-folder-item {
	position: relative;
}

.root-folder-icon {
	flex-shrink: 0;
	opacity: .9;
}

.root-item-title {
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}
</style>