import {onBeforeUnmount, ref, watch} from 'vue'
import {nanoid} from 'nanoid'

import {useAuthStore} from '@/stores/auth'
import UserSettingsModel from '@/models/userSettings'

import {
	DASHBOARD_LAYOUT_VERSION,
	type DashboardWidgetType,
	type DashboardWidgetWidth,
	type IDashboardLayout,
	type IDashboardTab,
	type IDashboardWidget,
} from '@/modelTypes/IDashboard'

export const OVERVIEW_DASHBOARD_WIDGET_TYPES: DashboardWidgetType[] = [
	'activities',
	'calendar',
	'activityStream',
	'recordList',
	'metric',
]

export const PERSONAL_DASHBOARD_WIDGET_TYPES: DashboardWidgetType[] = [
	'personalNotes',
	'personalTasks',
	'personalTaskStatus',
	'personalGantt',
	'personalKanban',
]

export const DASHBOARD_WIDGET_TITLES: Record<DashboardWidgetType, string> = {
	activities: 'Мои дела',
	calendar: 'Календарь',
	activityStream: 'Последняя активность',
	recordList: 'Список',
	metric: 'Показатели',
	personalNotes: 'Заметки',
	personalTasks: 'Задачи',
	personalTaskStatus: 'Статус задачи',
	personalGantt: 'Гант',
	personalKanban: 'Моя доска',
}

export const DASHBOARD_WIDGET_DESCRIPTIONS: Record<DashboardWidgetType, string> = {
	activities: 'Ближайшие задачи и действия текущего пользователя.',
	calendar: 'Личные события Google Calendar и рабочие события Vikunja в одном календаре.',
	activityStream: 'Хронологическая лента последних изменений и действий.',
	recordList: 'Универсальный список данных с фильтрами и сортировкой.',
	metric: 'Компактные рабочие показатели.',
	personalNotes: 'Личные быстрые заметки.',
	personalTasks: 'Активные задачи текущего пользователя.',
	personalTaskStatus: 'Состояние одной выбранной задачи.',
	personalGantt: 'Персональный план задач по времени.',
	personalKanban: 'Персональная доска задач.',
}

function cloneLayout(layout: IDashboardLayout): IDashboardLayout {
	return JSON.parse(JSON.stringify(layout)) as IDashboardLayout
}

export function createDashboardWidget(
	type: DashboardWidgetType,
	title = DASHBOARD_WIDGET_TITLES[type],
	width?: DashboardWidgetWidth,
): IDashboardWidget {
	const defaultWidth: DashboardWidgetWidth =
		type === 'activities' ||
		type === 'personalTasks'
			? 'wide'
			: type === 'personalNotes' ||
				type === 'personalGantt' ||
				type === 'personalKanban'
				? 'full'
				: 'normal'

	return {
		id: `widget-${nanoid(10)}`,
		type,
		title,
		width: width ?? defaultWidth,
		settings: {},
	}
}

export function createDashboardTab(
	title = 'Обзор',
	widgets: IDashboardWidget[] = [],
): IDashboardTab {
	return {
		id: `tab-${nanoid(10)}`,
		title,
		widgets,
	}
}

export function createDefaultDashboardLayout(): IDashboardLayout {
	const tab = createDashboardTab('Обзор', [
		createDashboardWidget('metric', 'Показатели', 'full'),
		createDashboardWidget('recordList', 'Мои задачи', 'wide'),
		createDashboardWidget('calendar', 'Календарь', 'normal'),
		createDashboardWidget('activities', 'Мои дела', 'wide'),
		createDashboardWidget('activityStream', 'Последняя активность', 'normal'),
	])

	return {
		version: DASHBOARD_LAYOUT_VERSION,
		activeTabId: tab.id,
		locked: false,
		tabs: [tab],
	}
}

export function createDefaultPersonalDashboardLayout(): IDashboardLayout {
	const tab = createDashboardTab('Личное', [
		createDashboardWidget('personalNotes', 'Заметки', 'full'),
		createDashboardWidget('personalTasks', 'Задачи', 'wide'),
		createDashboardWidget('personalTaskStatus', 'Статус задачи', 'normal'),
		createDashboardWidget('personalGantt', 'Гант', 'full'),
		createDashboardWidget('personalKanban', 'Моя доска', 'full'),
	])

	return {
		version: DASHBOARD_LAYOUT_VERSION,
		activeTabId: tab.id,
		locked: false,
		tabs: [tab],
	}
}

type DashboardSettingsKey = 'dashboard' | 'personalDashboard'

interface DashboardLayoutOptions {
	settingsKey?: DashboardSettingsKey
	createDefaultLayout?: () => IDashboardLayout
}

function isDashboardLayout(value: unknown): value is IDashboardLayout {
	if (
		value === null ||
typeof value !== 'object'
	) {
		return false
	}

	const candidate = value as Partial<IDashboardLayout>

	if (
		candidate.version !== DASHBOARD_LAYOUT_VERSION ||
typeof candidate.activeTabId !== 'string' ||
typeof candidate.locked !== 'boolean' ||
!Array.isArray(candidate.tabs) ||
candidate.tabs.length === 0
	) {
		return false
	}

	return candidate.tabs.every(tab =>
		typeof tab?.id === 'string' &&
typeof tab?.title === 'string' &&
Array.isArray(tab?.widgets),
	)
}

function normalizeDashboardLayout(
	value: unknown,
	createDefaultLayout: () => IDashboardLayout,
	migrateLegacyOverview: boolean,
): IDashboardLayout {
	if (!isDashboardLayout(value)) {
		return createDefaultLayout()
	}

	const layout = cloneLayout(value)

	// Migrate only the untouched legacy default arrangement.
	// Any custom user dashboard keeps its order and widths.
	const firstTab = layout.tabs[0]
	const legacyDefaultOrder = [
		'activities',
		'calendar',
		'activityStream',
		'recordList',
		'metric',
	]

	if (
		migrateLegacyOverview &&
		firstTab &&
		layout.tabs.length === 1 &&
		firstTab.widgets.map(widget => widget.type).join('|') ===
			legacyDefaultOrder.join('|')
	) {
		const modernOrder = [
			'metric',
			'recordList',
			'calendar',
			'activities',
			'activityStream',
		]

		firstTab.widgets.sort(
			(first, second) =>
				modernOrder.indexOf(first.type) -
modernOrder.indexOf(second.type),
		)

		for (const widget of firstTab.widgets) {
			if (widget.type === 'metric') {
				widget.width = 'full'
				continue
			}

			if (
				widget.type === 'recordList' ||
widget.type === 'activities'
			) {
				widget.width = 'wide'
				continue
			}

			widget.width = 'normal'
		}
	}

	if (!layout.tabs.some(tab => tab.id === layout.activeTabId)) {
		layout.activeTabId = layout.tabs[0].id
	}

	return layout
}

export function useDashboardLayout(
	options: DashboardLayoutOptions = {},
) {
	const authStore = useAuthStore()
	const settingsKey = options.settingsKey ?? 'dashboard'
	const createDefaultLayout =
		options.createDefaultLayout ?? createDefaultDashboardLayout

	const layout = ref<IDashboardLayout>(
		normalizeDashboardLayout(
			authStore.settings.frontendSettings[settingsKey],
			createDefaultLayout,
			settingsKey === 'dashboard',
		),
	)

	const saving = ref(false)

	let saveTimer: ReturnType<typeof setTimeout> | undefined

	async function saveLayout() {
		saveTimer = undefined
		saving.value = true

		try {
			const settings = new UserSettingsModel({
				...authStore.settings,
				frontendSettings: {
					...authStore.settings.frontendSettings,
					[settingsKey]: cloneLayout(layout.value),
				},
			})

			await authStore.saveUserSettings({
				settings,
				showMessage: false,
			})
		} finally {
			saving.value = false
		}
	}

	function scheduleSave() {
		if (saveTimer !== undefined) {
			clearTimeout(saveTimer)
		}

		saveTimer = setTimeout(() => {
			void saveLayout()
		}, 500)
	}

	function resetLayout() {
		layout.value = createDefaultLayout()
	}

	watch(
		layout,
		scheduleSave,
		{deep: true},
	)

	onBeforeUnmount(() => {
		if (saveTimer === undefined) {
			return
		}

		clearTimeout(saveTimer)
		void saveLayout()
	})

	return {
		layout,
		saving,
		resetLayout,
		saveLayout,
	}
}