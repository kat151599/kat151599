import {beforeEach,expect,it} from 'vitest'
import {featureRead,featureWrite,UNHANDLED} from './features'
import {initialBrowserDemoData,type BrowserDemoState} from './seed'
let state:BrowserDemoState
const query=new URLSearchParams()
beforeEach(()=>{state=initialBrowserDemoData()})
it('returns native mailbox page with fictional incoming message',()=>{
 const mail=featureRead(state,'/mailbox/messages',query) as {items:Array<{subject:string}>;total:number}
 expect(mail.total).toBe(1)
 expect(mail.items[0].subject).toContain('демо')
 expect(featureRead(state,'/mailbox/unread-count',query)).toEqual({count:1})
})
it('records sent message locally without invoking an email provider',()=>{
 const saved=featureWrite(state,'post','/mailbox/messages',{recipient_id:2,subject:'Локальное письмо',body:'Не отправлять'})
 expect(saved).toMatchObject({sender_id:1,subject:'Локальное письмо'})
 const sent=featureRead(state,'/mailbox/messages',new URLSearchParams({folder:'sent'})) as {items:Array<{subject:string}>}
 expect(sent.items[0].subject).toBe('Локальное письмо')
})
it('provides CRM campaigns and persistent local prospect update',()=>{
 const list=featureRead(state,'/crm/prospects',query) as {items:Array<{id:number}>}
 expect(list.items.length).toBe(1)
 const edited=featureWrite(state,'put','/crm/prospects/1',{notes:'Локальная заметка'})
 expect(edited).toMatchObject({notes:'Локальная заметка'})
 expect(featureRead(state,'/crm/prospects/1',query)).toMatchObject({notes:'Локальная заметка'})
})
it('supports per-project client profile and custom fields without real PII',()=>{
 const orig=featureRead(state,'/projects/102/client',query) as {phone:string;email:string}
 expect(orig.phone).toBe('')
 expect(orig.email).toBe('')
 featureWrite(state,'put','/projects/102/client',{display_name:'Изменённый клиент'})
 expect(featureRead(state,'/projects/102/client',query)).toMatchObject({display_name:'Изменённый клиент'})
 featureWrite(state,'post','/projects/102/client/custom-fields',{name:'Проверка',value:'Да'})
 const fields=featureRead(state,'/projects/102/client/custom-fields',query) as Array<{name:string}>
 expect(fields[0].name).toBe('Проверка')
})
it('handles personal task board placements within visitor state',()=>{
 const data=featureRead(state,'/user/task-board',query) as {columns:unknown[];placements:unknown[]}
 expect(data.columns.length).toBe(4)
 featureWrite(state,'put','/user/task-board/tasks/1001',{column_id:4,position:1})
 const after=featureRead(state,'/user/task-board',query) as {placements:Array<{task_id:number;column_id:number}>}
 expect(after.placements.find(p=>p.task_id===1001)?.column_id).toBe(4)
})
it('never retains external Wialon API or bearer token',()=>{
 const response=featureWrite(state,'patch','/admin/wialon/settings',{
  token:'REAL_SHOULD_NEVER_PERSIST',api_url:'https://external.example.invalid',enabled:true
 }) as Record<string,unknown>
 expect(response).not.toHaveProperty('token')
 expect(response.api_url).toBe('')
 expect(JSON.stringify(state.extra)).not.toContain('REAL_SHOULD_NEVER_PERSIST')
})
it('returns absent external integrations instead of contacting them',()=>{
 expect(featureRead(state,'/wialon/units',query)).toEqual({units:[]})
 const calendar=featureRead(state,'/integrations/google-calendar/status',query)
 expect(calendar).toMatchObject({connected:false})
})
it('rejects unknown resources, never silently pretends writes succeeded',()=>{
 expect(featureRead(state,'/unknown-data',query)).toBe(UNHANDLED)
 expect(featureWrite(state,'post','/provider/real-dial',{number:'000'})).toBe(UNHANDLED)
})
