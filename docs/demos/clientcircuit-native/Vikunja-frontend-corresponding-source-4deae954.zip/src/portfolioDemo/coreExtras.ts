/**
 * Original Vikunja's secondary project/task/team routes.
 * No external data or network: CRUD stays inside BrowserDemoState.
 */
import {fictionalAdmin,type BrowserDemoState} from './seed'
import {UNHANDLED} from './features'
type Row=Record<string,unknown>
function generatedId(rows:Array<{id:number}>) {
 return Math.max(1000,...rows.map(r=>Number(r.id)||0))+1
}
function selected<T>(rows:T[],start:string|undefined):T[] {
 return start?rows.filter(r=>String((r as Row).id)===start):rows
}
function extraCollection(state:BrowserDemoState,key:string):Row[]{
 const data=state.extra['core:'+key]
 return Array.isArray(data)?data as Row[]:[]
}
function save(state:BrowserDemoState,key:string,data:Row[]){
 state.extra['core:'+key]=data
}
export function coreRead(state:BrowserDemoState,path:string):unknown {
 const team=path.match(/^\/teams\/(\d+)$/)
 if(team)return state.teams.find(x=>x.id===Number(team[1]))??UNHANDLED
 const members=path.match(/^\/teams\/(\d+)\/members$/)
 if(members)return extraCollection(state,'team-members-'+members[1])
 const teamProjects=path.match(/^\/projects\/(\d+)\/teams$/)
 if(teamProjects)return extraCollection(state,'project-teams-'+teamProjects[1])
 const projectUsers=path.match(/^\/projects\/(\d+)\/(?:users|projectusers)$/)
 if(projectUsers)return state.users
 const comments=path.match(/^\/tasks\/(\d+)\/comments$/)
 if(comments)return state.comments.filter(c=>Number((c as Row).task_id)===Number(comments[1]))
 const taskLabels=path.match(/^\/tasks\/(\d+)\/labels$/)
 if(taskLabels)return state.tasks.find(t=>t.id===Number(taskLabels[1]))?.labels??[]
 const assignees=path.match(/^\/tasks\/(\d+)\/assignees$/)
 if(assignees)return state.tasks.find(t=>t.id===Number(assignees[1]))?.assignees??[]
 if(path==='/filters')return extraCollection(state,'filters')
 const filter=path.match(/^\/filters\/(\d+)$/)
 if(filter)return extraCollection(state,'filters').find(x=>x.id===Number(filter[1]))??UNHANDLED
 if(path==='/user/sessions')return [{id:1,user_id:1,created:'2026-10-20T09:00:00Z',
  last_seen:'2026-10-20T09:00:00Z',user_agent:'Portfolio fictional browser session',ip:''}]
 if(path==='/user/bots'||path==='/tokens'||path==='/user/settings/token/caldav')return []
 if(path==='/routes')return []
 if(path==='/notifications')return []
 if(path==='/user/export')return {status:'demo',note:'Данные браузера можно очистить локально'}
 return UNHANDLED
}
export function coreWrite(state:BrowserDemoState,method:string,path:string,input:Row):unknown {
 // Original project views are editable in the local simulation.
 const view=path.match(/^\/projects\/(\d+)\/views(?:\/(\d+))?$/)
 if(view){
  const p=state.projects.find(x=>x.id===Number(view[1]))
  if(!p)return UNHANDLED
  const id=Number(view[2])
  if(view[2]){
   const idx=p.views.findIndex(v=>v.id===id)
   if(idx<0)return UNHANDLED
   if(method==='delete')return p.views.splice(idx,1)[0]
   p.views[idx]={...p.views[idx],...input,id} as typeof p.views[number]
   return p.views[idx]
  }
  if(!['put','post'].includes(method))return UNHANDLED
  const idNew=Math.max(...state.projects.flatMap(x=>x.views.map(v=>v.id)),1000)+1
  const kind=String(input.view_kind||'list') as 'list'|'kanban'|'table'|'gantt'
  if(!['list','kanban','table','gantt'].includes(kind))return UNHANDLED
  const item={...p.views[0],...input,id:idNew,project_id:p.id,view_kind:kind}
  p.views.push(item)
  return item
 }
 if(path==='/project-folders'&&method==='put'){
  const id=generatedId(state.folders),now=new Date().toISOString()
  const folder={id,title:String(input.title||'Демо-папка'),
   parent_folder_id:Number(input.parent_folder_id)||0,position:state.folders.length+1,
   created:now,updated:now}
  state.folders.push(folder);return folder
 }
 const label=path.match(/^\/tasks\/(\d+)\/labels(?:\/(\d+))?$/)
 if(label){
  const task=state.tasks.find(t=>t.id===Number(label[1]))
  if(!task)return UNHANDLED
  const tag=Number(label[2]||input.label_id||input.labelId||input.id)
  const found=state.labels.find(l=>Number((l as Row).id)===tag)
  if(!found)return UNHANDLED
  task.labels=method==='delete'
   ?task.labels.filter(l=>Number((l as Row).id)!==tag)
   :[...task.labels.filter(l=>Number((l as Row).id)!==tag),found]
  return found
 }
 const assignee=path.match(/^\/tasks\/(\d+)\/assignees(?:\/(\d+))?$/)
 if(assignee){
  const t=state.tasks.find(x=>x.id===Number(assignee[1]))
  if(!t)return UNHANDLED
  const id=Number(assignee[2]||input.user_id||input.userId||input.id)
  const user=state.users.find(x=>x.id===id)
  if(!user)return UNHANDLED
  t.assignees=method==='delete'?t.assignees.filter(u=>u.id!==id):
   [...t.assignees.filter(u=>u.id!==id),user]
  return {task_id:t.id,user_id:id,assignee:user}
 }
 const comments=path.match(/^\/tasks\/(\d+)\/comments(?:\/(\d+))?$/)
 if(comments){
  const taskId=Number(comments[1]),task=state.tasks.find(t=>t.id===taskId)
  if(!task)return UNHANDLED
  if(comments[2]){
   const index=state.comments.findIndex(c=>Number((c as Row).id)===Number(comments[2]))
   if(index<0)return UNHANDLED
   if(method==='delete')return state.comments.splice(index,1)[0]
   state.comments[index]={...state.comments[index],...input} as typeof state.comments[number]
   return state.comments[index]
  }
  if(!['put','post'].includes(method))return UNHANDLED
  const comment={id:Math.max(0,...state.comments.map(c=>Number((c as Row).id)||0))+1,
   task_id:taskId,comment:String(input.comment||''),author:fictionalAdmin,
   created:new Date().toISOString(),updated:new Date().toISOString()}
  state.comments.push(comment)
  return comment
 }
 const position=path.match(/^\/tasks\/(\d+)\/position$/)
 if(position){
  const task=state.tasks.find(t=>t.id===Number(position[1]))
  if(!task)return UNHANDLED
  task.position=Number(input.position)||0
  return {task_id:task.id,position:task.position}
 }
 const duplicateTask=path.match(/^\/tasks\/(\d+)\/duplicate$/)
 if(duplicateTask){
  const task=state.tasks.find(t=>t.id===Number(duplicateTask[1]))
  if(!task)return UNHANDLED
  const duplicated={...task,id:generatedId(state.tasks),title:task.title+' (копия)',
   created:new Date().toISOString()}
  state.tasks.push(duplicated)
  return {task:duplicated,task_id:duplicated.id}
 }
 const duplicateProject=path.match(/^\/projects\/(\d+)\/duplicate$/)
 if(duplicateProject){
  const project=state.projects.find(p=>p.id===Number(duplicateProject[1]))
  if(!project)return UNHANDLED
  const id=generatedId(state.projects)
  const result={...project,id,title:project.title+' (копия)',
   views:project.views.map(v=>({...v,id:id*10+v.position,project_id:id}))}
  state.projects.push(result)
  // Keep the native Kanban views usable on duplicated projects.
  for(const b of state.buckets.filter(b=>b.project_id===project.id)){
   const bucketNumber=b.id-project.id*100
   state.buckets.push({...b,id:id*100+bucketNumber,project_id:id,
    project_view_id:id*10+2,tasks:[],count:0})
  }
  // Real project duplication may omit tasks; match the user's duplication option.
  if(input.duplicate_tasks===true){
   for(const task of state.tasks.filter(t=>t.project_id===project.id)){
    const clone={...task,id:generatedId(state.tasks),project_id:id,
     bucket_id:id*100+(task.bucket_id-project.id*100)}
    state.tasks.push(clone)
   }
  }
  return {project:result,project_id:id}
 }
 if(path==='/filters'&&method==='put'){
  const rows=extraCollection(state,'filters')
  const filter={...input,id:generatedId(rows as Array<{id:number}>)}
  rows.push(filter);save(state,'filters',rows);return filter
 }
 const f=path.match(/^\/filters\/(\d+)$/)
 if(f){
  const rows=extraCollection(state,'filters'),idx=rows.findIndex(x=>Number(x.id)===Number(f[1]))
  if(idx<0)return UNHANDLED
  if(method==='delete'){rows.splice(idx,1);save(state,'filters',rows);return {}}
  rows[idx]={...rows[idx],...input,id:Number(f[1])};save(state,'filters',rows);return rows[idx]
 }
 const member=path.match(/^\/teams\/(\d+)\/members(?:\/([^/]+)(?:\/admin)?)?$/)
 if(member){
  const key='team-members-'+member[1],list=extraCollection(state,key)
  const username=member[2]
  if(username){
   const i=list.findIndex(r=>r.username===decodeURIComponent(username))
   if(i<0)return UNHANDLED
   if(method==='delete'){list.splice(i,1);save(state,key,list);return {}}
   list[i]={...list[i],...input};save(state,key,list);return list[i]
  }
  const u=state.users.find(u=>u.username===input.username)
  if(!u)return UNHANDLED
  const item={...u,admin:false}
  list.push(item);save(state,key,list);return item
 }
 const projectTeam=path.match(/^\/projects\/(\d+)\/teams(?:\/(\d+))?$/)
 if(projectTeam){
  const key='project-teams-'+projectTeam[1],list=extraCollection(state,key)
  const id=Number(projectTeam[2]||input.team_id||input.id)
  const team=state.teams.find(t=>t.id===id)
  if(!team)return UNHANDLED
  if(method==='delete'){
   const i=list.findIndex(x=>Number(x.id)===id)
   if(i<0)return UNHANDLED
   list.splice(i,1);save(state,key,list);return {}
  }
  const row={...team,...input,id}
  const i=list.findIndex(x=>Number(x.id)===id)
  if(i>=0)list[i]=row;else list.push(row)
  save(state,key,list);return row
 }
 const projectUser=path.match(/^\/projects\/(\d+)\/users(?:\/([^/]+))?$/)
 if(projectUser){
  const username=String(projectUser[2]||input.username||'')
  const user=state.users.find(u=>u.username===username)
  if(!user)return UNHANDLED
  return {...user,max_permission:Number(input.right||input.permission)||2}
 }
 const session=path.match(/^\/user\/sessions\/(\d+)$/)
 if(session&&method==='delete')return {}
 // Subscription is a local marker, not an external notification signup.
 const subscription=path.match(/^\/subscriptions\/(project|task)\/(\d+)$/)
 if(subscription)return {entity:subscription[1],entity_id:Number(subscription[2]),
  subscribed:method!=='delete'}
 return UNHANDLED
}
