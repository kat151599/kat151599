import type {BrowserDemoState} from './seed'
import {UNHANDLED} from './features'

type StoredFile = {id:number,name:string,mime:string,size:number,content:string,created:string}
const MAX_FILE_BYTES=512*1024

function key(route:string){return 'files:'+route}
function getFiles(state:BrowserDemoState,route:string):StoredFile[] {
 const data=state.extra[key(route)]
 return Array.isArray(data)?data as StoredFile[]:[]
}
function setFiles(state:BrowserDemoState,route:string,files:StoredFile[]) {
 state.extra[key(route)]=files
}
function toBase64(bytes:Uint8Array):string {
 let result=''
 for(let i=0;i<bytes.length;i+=8192){
  result+=String.fromCharCode(...bytes.subarray(i,i+8192))
 }
 return btoa(result)
}
function fromBase64(value:string):Uint8Array {
 const binary=atob(value)
 const bytes=new Uint8Array(binary.length)
 for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i)
 return bytes
}
function container(path:string):string|null {
 const t=path.match(/^\/tasks\/(\d+)\/attachments(?:\/\d+)?$/)
 if(t)return '/tasks/'+t[1]+'/attachments'
 const m=path.match(/^\/mailbox\/messages\/(\d+)\/attachments(?:\/\d+)?$/)
 if(m)return '/mailbox/messages/'+m[1]+'/attachments'
 const p=path.match(/^\/projects\/(\d+)\/client\/proposal$/)
 if(p)return '/projects/'+p[1]+'/client/proposal'
 return null
}
function wireFile(stored:StoredFile,route:string){
 const file={id:stored.id,name:stored.name,mime:stored.mime,size:stored.size,created:stored.created}
 const number=Number(route.match(/\/(?:tasks|messages)\/(\d+)/)?.[1])||0
 return route.startsWith('/mailbox')?
  {id:stored.id,message_id:number,file,created:stored.created}:
  {id:stored.id,task_id:number,file,created:stored.created}
}
export function demoFileRead(state:BrowserDemoState,path:string):unknown {
 const projectBackground=path.match(/^\/projects\/(\d+)\/background$/)
 if(projectBackground){
  const stored=state.extra['background:'+projectBackground[1]] as StoredFile|undefined
  return stored?new Blob([fromBase64(stored.content)],{type:stored.mime}):UNHANDLED
 }
 const base=container(path)
 if(!base)return UNHANDLED
 const files=getFiles(state,base)
 if(path===base){
  if(base.includes('/client/proposal')){
   const selected=files[0]
   return selected?new Blob([fromBase64(selected.content)],{type:selected.mime}):UNHANDLED
  }
  return files.map(f=>wireFile(f,base))
 }
 const id=Number(path.slice(base.length+1))
 const file=files.find(x=>x.id===id)
 return file?new Blob([fromBase64(file.content)],{type:file.mime}):UNHANDLED
}
export function demoFileWrite(state:BrowserDemoState,method:string,path:string,input:Record<string,unknown>):unknown {
 // Native ProjectModel background UI remains functional in this visitor's browser.
 const background=path.match(/^\/projects\/(\d+)\/backgrounds\/upload$/)
 const backgroundRemoval=path.match(/^\/projects\/(\d+)\/background$/)
 if(background||backgroundRemoval){
  const projectId=Number((background||backgroundRemoval)![1])
  const project=state.projects.find(x=>x.id===projectId)
  if(!project)return UNHANDLED
  if(backgroundRemoval&&method==='delete'){
   delete state.extra['background:'+projectId]
   return {...project,background_information:null,background_blur_hash:''}
  }
  if(background&&['post','put'].includes(method)){
   const file=Array.isArray(input.files)?input.files[0] as Record<string,unknown>:null
   if(!file||Number(file.size||0)>MAX_FILE_BYTES)return UNHANDLED
   state.extra['background:'+projectId]={
    id:1,name:String(file.name||'demo-background'),mime:String(file.mime||'image/png'),
    size:Number(file.size)||0,content:String(file.content||''),created:new Date().toISOString()
   } as StoredFile
   return {...project,background_information:{type:'upload',id:1},background_blur_hash:''}
  }
  return UNHANDLED
 }
 const base=container(path)
 if(!base)return UNHANDLED
 const files=getFiles(state,base)
 if(method==='delete'){
  if(path===base&&base.includes('/client/proposal')){
   setFiles(state,base,[])
   return {commercial_proposal:null}
  }
  const id=Number(path.slice(base.length+1))
  if(!Number.isFinite(id))return UNHANDLED
  const index=files.findIndex(x=>x.id===id)
  if(index<0)return UNHANDLED
  files.splice(index,1);setFiles(state,base,files);return {}
 }
 if(!['post','put'].includes(method)||path!==base)return UNHANDLED
 const uploads=input.files
 if(!Array.isArray(uploads)||!uploads.length)return UNHANDLED
 const rows:StoredFile[]=[]
 for(const entry of uploads){
  if(!entry||typeof entry!=='object')continue
  const file=entry as Record<string,unknown>
  const size=Number(file.size)||0
  if(size<0||size>MAX_FILE_BYTES)return UNHANDLED
  rows.push({
   id:Math.max(0,...files.map(x=>x.id),...rows.map(x=>x.id))+1,
   name:String(file.name||'demo-file').slice(0,160),
   mime:String(file.mime||'application/octet-stream'),
   size,content:String(file.content||''),created:new Date().toISOString()
  })
 }
 if(!rows.length)return UNHANDLED
 if(base.includes('/client/proposal')){
  setFiles(state,base,rows.slice(0,1))
  const projectId=Number(base.split('/')[2])
  const clientKey='feature:client-'+projectId
  const current=state.extra[clientKey]
  const client=current&&typeof current==='object'&&!Array.isArray(current)
   ?current as Record<string,unknown>:{project_id:projectId}
  const proposal={id:rows[0].id,name:rows[0].name,mime:rows[0].mime,
   size:rows[0].size}
  state.extra[clientKey]={...client,commercial_proposal:proposal}
  return {...state.extra[clientKey] as Record<string,unknown>}
 }
 files.push(...rows);setFiles(state,base,files)
 return {success:rows.map(x=>wireFile(x,base)),errors:[]}
}
export async function demoConvertInput(data:unknown):Promise<Record<string,unknown>>{
 if(typeof FormData==='undefined'||!(data instanceof FormData))return {}
 const pending:Array<Promise<{name:string,entry:Record<string,unknown>}>>=[]
 data.forEach((value,name)=>{
  if(typeof value==='string'){
   pending.push(Promise.resolve({name,entry:{text:value}}))
  }else{
   pending.push((async()=>{
    if(value.size>MAX_FILE_BYTES)throw new Error('DEMO_FILE_TOO_LARGE_512_KIB')
    const bytes=new Uint8Array(await value.arrayBuffer())
    return {name,entry:{name:value.name,mime:value.type||'application/octet-stream',
     size:value.size,content:toBase64(bytes)}}
   })())
  }
 })
 const values=await Promise.all(pending)
 const result:Record<string,unknown>={}
 for(const {name,entry} of values){
  if(name==='files'||name==='proposal'||name==='background'){
   const target=Array.isArray(result.files)?result.files as Record<string,unknown>[]:[]
   target.push(entry);result.files=target
  }else result[name]=entry.text
 }
 return result
}
