import {beforeEach, expect, it} from 'vitest'
import {initialBrowserDemoData, type BrowserDemoState} from './seed'
import {readCallCenter, writeCallCenter} from './callCenterDemo'
import {UNHANDLED} from './features'

let state:BrowserDemoState
beforeEach(()=>{state=initialBrowserDemoData()})

it('opens the ORIGINAL CallCenterView lead table with fictional contacts',()=>{
 const leads=readCallCenter(state,'/callcenter/leads') as Array<{id:string,phone:null,email:null}>
 expect(leads).toHaveLength(2)
 expect(leads.every(lead=>!lead.phone&&!lead.email)).toBe(true)
 expect(readCallCenter(state,'/call-center/website-attempts/stats')).toMatchObject({
  total:2,with_contact:2,without_contact:0
 })
})
it('records a CallCenter history note and call with the exact shape expected by the original Vue UI',()=>{
 const id=state.leads[0].id
 const note=writeCallCenter(state,'post','/callcenter/leads/'+id+'/events',{
  event_type:'manual_note',text:'Запись только в браузере'
 })
 expect(note).toMatchObject({event_type:'manual_note',data:{text:'Запись только в браузере'}})
 const call=writeCallCenter(state,'post','/callcenter/leads/'+id+'/calls',{
  direction:'outbound',outcome:'answered',duration_seconds:14,notes:'Демо'
 })
 expect(call).toMatchObject({direction:'outbound',outcome:'answered',duration_seconds:14})
 const history=readCallCenter(state,'/callcenter/leads/'+id+'/history-snapshot') as {
  lead:unknown,events:unknown[],calls:unknown[]
 }
 expect(history.events).toHaveLength(2)
 expect(history.calls).toHaveLength(1)
 const saved=JSON.parse(JSON.stringify(state)) as BrowserDemoState
 expect((readCallCenter(saved,'/callcenter/leads/'+id+'/history-snapshot') as typeof history).calls)
  .toHaveLength(1)
})
it('preserves a locally scheduled callback event and reuses a real demo project',()=>{
 const id=state.leads[0].id
 const item=writeCallCenter(state,'post','/callcenter/leads/'+id+'/scheduled-calls',{
  scheduled_at:'2026-11-14T10:00:00Z',notes:'Локально',project_id:102,vikunja_task_id:1002
 })
 expect(item).toMatchObject({event_type:'callback_scheduled',data:{
  project_id:102,vikunja_task_id:1002
 }})
})
it('advances the original dialer batch without a phone call or provider',()=>{
 const batch=writeCallCenter(state,'post','/callcenter/dialer/next',{}) as {
  batch:{items:Array<{lead_id:string,state:string}>}
 }
 expect(batch.batch.items).toHaveLength(2)
 const id=batch.batch.items[0].lead_id
 writeCallCenter(state,'post','/callcenter/dialer/items/'+id+'/resolve',{
  mode:'deferred',reason:'Вымышленная заметка'
 })
 const current=readCallCenter(state,'/callcenter/dialer') as typeof batch
 expect(current.batch.items[0].state).toBe('deferred')
 expect(state.extra['external:telephony']).toBeUndefined()
})
it('changes only the fictional leads and never calls a backend',()=>{
 const id=state.leads[0].id
 writeCallCenter(state,'patch','/callcenter/leads/'+id,{status:'qualified'})
 const history=readCallCenter(state,'/callcenter/leads/'+id+'/history-snapshot') as {
  events:Array<{event_type:string,data:{old_status:string,new_status:string}}>
 }
 expect(history.events[0].event_type).toBe('status_changed')
 expect(history.events[0].data).toMatchObject({old_status:'new',new_status:'qualified'})
 expect(writeCallCenter(state,'post','/external/send-sms',{phone:'000'})).toBe(UNHANDLED)
})
