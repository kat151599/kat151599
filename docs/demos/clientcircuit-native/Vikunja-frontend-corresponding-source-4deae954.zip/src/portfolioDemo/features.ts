/**
 * Secondary ORIGINAL-Vue screens: browser-only CRM, mailbox, settings, work
 * groups and tasks. All effects simulated, all state owned by localStorage.
 * Unsupported calls return UNHANDLED to fail-closed in the Axios adapter.
 */
import type {BrowserDemoState} from './seed'
export const UNHANDLED: unique symbol=Symbol('unknown-local-demo-route')
type Row=Record<string,unknown>
const baseline='2026-10-20T09:00:00Z'
const copied=<T>(v:T):T=>JSON.parse(JSON.stringify(v)) as T
function collection(s:BrowserDemoState,key:string,initial:Row[]=[]):Row[] {
 const data=s.extra['feature:'+key]
 return Array.isArray(data)?data as Row[]:copied(initial)
}
function saveCollection(s:BrowserDemoState,key:string,data:Row[]) {
 s.extra['feature:'+key]=data
}
function obj(s:BrowserDemoState,key:string,initial:Row={}):Row {
 const data=s.extra['feature:'+key]
 return data && typeof data==='object' && !Array.isArray(data)?data as Row:copied(initial)
}
function save(s:BrowserDemoState,key:string,data:Row){s.extra['feature:'+key]=data}
function page(rows:Row[],query:URLSearchParams):Row {
 const q=(query.get('q')||query.get('s')||'').toLowerCase()
 const filtered=q?rows.filter(x=>JSON.stringify(x).toLowerCase().includes(q)):rows
 const per=Math.max(1,Math.min(500,Number(query.get('per_page'))||30))
 const p=Math.max(1,Number(query.get('page'))||1)
 return {items:filtered.slice((p-1)*per,p*per),total:filtered.length,page:p,
  per_page:per,total_pages:Math.max(1,Math.ceil(filtered.length/per))}
}
function nextId(rows:Row[]){return Math.max(0,...rows.map(x=>Number(x.id)||0))+1}
function crud(s:BrowserDemoState,key:string,path:string,base:string,method:string,input:Row,seed:Row[]=[]):unknown {
 const rows=collection(s,key,seed)
 if(path===base&&['post','put'].includes(method)){
  const row={...input,id:nextId(rows),created:baseline,updated:new Date().toISOString()}
  rows.push(row);saveCollection(s,key,rows);return row
 }
 if(!path.startsWith(base+'/'))return UNHANDLED
 const suffix=path.slice(base.length+1)
 if(!/^[0-9]+$/.test(suffix))return UNHANDLED
 const i=rows.findIndex(x=>Number(x.id)===Number(suffix))
 if(i<0)return UNHANDLED
 if(method==='delete'){rows.splice(i,1);saveCollection(s,key,rows);return {}}
 rows[i]={...rows[i],...input,id:Number(suffix),updated:new Date().toISOString()}
 saveCollection(s,key,rows);return rows[i]
}
const fakeUser={id:1,name:'Демо-администратор',username:'portfolio-demo-admin'}
const mailInitial:Row[]=[{
 id:1,sender_id:2,recipient_id:1,reply_to_id:0,subject:'Добро пожаловать в демо-почту',
 body:'Это вымышленное сообщение. Настоящая почта отключена.',read_at:null,
 sender:{id:2,name:'Алина (демо)',username:'alina.demo'},recipient:fakeUser,
 attachments:[],created:baseline,updated:baseline
}]
const campaigns:Row[]=[{id:1,name:'Пример работы с клиентами',
 description:'Демонстрационная кампания',created_by_user_id:1,archived:false,
 created:baseline,updated:baseline}]
const prospects:Row[]=[{id:1,campaign_id:1,company_name:'Учебный заказчик',
 contact_name:'Тестовый клиент',phone:'',phone_normalized:'',phone_secondary:'',
 email:'',website:'',region:'',city:'Демо-город',notes:'Нет реальных клиентов.',
 status:'new',responsible_user_id:1,responsible:fakeUser,project_id:102,
 created:baseline,updated:baseline}]
const clientBase=(id:number):Row=>({
 project_id:id,client_type:'company',display_name:'Учебный клиент',contact_name:'Тестовый',
 status:'potential',source:'demo',responsible_user_id:1,responsible:fakeUser,
 phone:'',phone_secondary:'',email:'',email_secondary:'',telegram:'',viber:'',
 whatsapp:'',website:'',preferred_contact_method:'',preferred_language:'ru',
 tax_id:'',legal_name:'',director_name:'',ownership_form:'',industry:'',
 employee_count:0,requisites:'',iban:'',bank:'',mfo:'',vat_number:'',tax_system:'',
 addresses:[],contact_persons:[],commercial_proposal:null,added_at:baseline,
 updated:baseline})
function personalBoard(s:BrowserDemoState):Row {
 const columns=[
  {id:1,title:'Новые',position:1,system_key:'new',created:baseline,updated:baseline},
  {id:2,title:'В работе',position:2,system_key:'in_progress',created:baseline,updated:baseline},
  {id:3,title:'Ожидание',position:3,system_key:'waiting',created:baseline,updated:baseline},
  {id:4,title:'Готово',position:4,system_key:'done',created:baseline,updated:baseline}]
 return obj(s,'personal-board',{columns,placements:s.tasks.map((t,i)=>({
  id:i+1,task_id:t.id,column_id:t.done?4:2,position:i+1,updated:baseline}))})
}
const wialon={enabled:false,api_url:'',token_configured:false,timeout_seconds:15,track_max_points:500}
const calendar={enabled:true,connected:false,google_email:'',vikunja_calendar_id:'',
 sync_enabled:false,reminders:[],last_sync_at:null}
export function featureRead(s:BrowserDemoState,path:string,q:URLSearchParams):unknown {
 if(path==='/mailbox/messages')return page(collection(s,'mail',mailInitial).filter(m=>
  q.get('folder')==='sent'?m.sender_id===1:m.recipient_id===1),q)
 const message=path.match(/^\/mailbox\/messages\/(\d+)$/)
 if(message)return collection(s,'mail',mailInitial).find(x=>Number(x.id)===Number(message[1]))??UNHANDLED
 if(path==='/mailbox/unread-count')return {count:collection(s,'mail',mailInitial).filter(x=>x.recipient_id===1&&!x.read_at).length}
 if(path==='/mailbox/recipients')return s.users.map(u=>({id:u.id,name:u.name,username:u.username}))
 if(path==='/crm/prospect-campaigns')return collection(s,'campaigns',campaigns)
 if(path==='/crm/prospects')return page(collection(s,'prospects',prospects),q)
 const prospect=path.match(/^\/crm\/prospects\/(\d+)$/)
 if(prospect)return collection(s,'prospects',prospects).find(x=>Number(x.id)===Number(prospect[1]))??UNHANDLED
 const calls=path.match(/^\/crm\/prospects\/(\d+)\/calls$/)
 if(calls)return collection(s,'prospect-calls').filter(x=>Number(x.prospect_id)===Number(calls[1]))
 if(path==='/admin/overview')return {
  users:s.users.length,projects:s.projects.length,tasks:s.tasks.length,teams:s.teams.length,
  shares:{link_shares:0,team_shares:0,user_shares:0},
  license:{licensed:true,instance_id:'portfolio-demo',features:['admin_panel','time_tracking'],
   max_users:100,expires_at:'2099-01-01T00:00:00Z',validated_at:baseline,last_check_failed:false}}
 if(path==='/admin/users')return s.users
 if(path==='/admin/projects')return s.projects
 if(path==='/user/task-board')return personalBoard(s)
 if(path==='/user/task-board/settings')return obj(s,'task-board-settings',{include_created_tasks:false})
 if(path==='/time-entries')return page(collection(s,'time-entries'),q)
 if(path==='/wialon/status')return {enabled:false,configured:false,api_url:''}
 if(path==='/wialon/units')return {units:[]}
 if(/^\/wialon\/units\/\d+\/track$/.test(path))return {unit_id:0,from:0,to:0,points:[],original_point_count:0}
 if(path==='/admin/wialon/settings')return obj(s,'wialon-settings',wialon)
 if(path==='/integrations/google-calendar/status')return obj(s,'calendar',calendar)
 const client=path.match(/^\/projects\/(\d+)\/client$/)
 if(client)return obj(s,'client-'+client[1],clientBase(Number(client[1])))
 const history=path.match(/^\/projects\/(\d+)\/client\/history$/)
 if(history)return page(collection(s,'client-history-'+history[1]),q)
 const fields=path.match(/^\/projects\/(\d+)\/client\/custom-fields$/)
 if(fields)return collection(s,'fields-'+fields[1])
 if(/^\/projects\/\d+\/users\/search$/.test(path))return {items:s.users}
 if(/^\/projects\/\d+\/client\/geocode$/.test(path))return {
  display_name:'Демо-адрес без внешних карт',postal_code:'',latitude:0,longitude:0}
 if(path==='/admin/access/groups')return {groups:collection(s,'groups')}
 if(path==='/admin/access/permissions')return {permissions:[]}
 if(path==='/notifications')return collection(s,'notifications')
 if(path==='/work-groups')return collection(s,'work-groups')
 if(path==='/webhooks')return collection(s,'webhooks')
 return UNHANDLED
}
export function featureWrite(s:BrowserDemoState,method:string,path:string,input:Row):unknown {
 if(path==='/mailbox/messages'&&method==='post'){
  const list=collection(s,'mail',mailInitial)
  const row={id:nextId(list),sender_id:1,recipient_id:Number(input.recipient_id)||2,
   reply_to_id:Number(input.reply_to_id)||0,subject:String(input.subject||''),
   body:String(input.body||''),read_at:baseline,sender:fakeUser,
   recipient:s.users.find(u=>u.id===Number(input.recipient_id))??fakeUser,
   attachments:[],created:new Date().toISOString(),updated:new Date().toISOString()}
  list.push(row);saveCollection(s,'mail',list);return row
 }
 const msg=path.match(/^\/mailbox\/messages\/(\d+)(\/read)?$/)
 if(msg){
  const list=collection(s,'mail',mailInitial),i=list.findIndex(x=>Number(x.id)===Number(msg[1]))
  if(i<0)return UNHANDLED
  if(method==='delete'){list.splice(i,1);saveCollection(s,'mail',list);return {}}
  list[i]={...list[i],read_at:input.read?new Date().toISOString():null}
  saveCollection(s,'mail',list);return list[i]
 }
 if(path==='/crm/prospect-campaigns')return crud(s,'campaigns',path,path,method,input,campaigns)
 if(path.startsWith('/crm/prospects')){
  const call=path.match(/^\/crm\/prospects\/(\d+)\/calls$/)
  if(call&&method==='post'){
   const list=collection(s,'prospect-calls')
   const row={...input,id:nextId(list),prospect_id:Number(call[1]),
    user_id:1,occurred_at:new Date().toISOString(),created:new Date().toISOString()}
   list.push(row);saveCollection(s,'prospect-calls',list);return row
  }
  return crud(s,'prospects',path,'/crm/prospects',method,input,prospects)
 }
 const client=path.match(/^\/projects\/(\d+)\/client$/)
 if(client&&['put','post','patch'].includes(method)){
  const key='client-'+client[1],data={...obj(s,key,clientBase(Number(client[1]))),...input,
   project_id:Number(client[1]),updated:new Date().toISOString()}
  save(s,key,data);return data
 }
 const history=path.match(/^\/projects\/(\d+)\/client\/history(?:\/\d+)?$/)
 if(history)return crud(s,'client-history-'+history[1],path,
  '/projects/'+history[1]+'/client/history',method,input)
 const fields=path.match(/^\/projects\/(\d+)\/client\/custom-fields(?:\/\d+)?$/)
 if(fields)return crud(s,'fields-'+fields[1],path,
  '/projects/'+fields[1]+'/client/custom-fields',method,input)
 if(path==='/user/task-board/columns'&&method==='post'){
  const board=personalBoard(s),cols=copied(board.columns as Row[])
  const row={id:nextId(cols),title:String(input.title||'Новая колонка'),
   position:cols.length+1,system_key:null,created:baseline,updated:new Date().toISOString()}
  cols.push(row);board.columns=cols;save(s,'personal-board',board);return row
 }
 const column=path.match(/^\/user\/task-board\/columns\/(\d+)$/)
 if(column){
  const board=personalBoard(s),cols=copied(board.columns as Row[])
  const i=cols.findIndex(c=>Number(c.id)===Number(column[1]))
  if(i<0)return UNHANDLED
  const result=method==='delete'?{}:{...cols[i],...input,updated:new Date().toISOString()}
  if(method==='delete')cols.splice(i,1);else cols[i]=result
  board.columns=cols;save(s,'personal-board',board);return result
 }
 const placement=path.match(/^\/user\/task-board\/tasks\/(\d+)$/)
 if(placement&&method==='put'){
  const board=personalBoard(s),rows=copied(board.placements as Row[])
  const id=Number(placement[1]),i=rows.findIndex(r=>Number(r.task_id)===id)
  const row={id:i>=0?rows[i].id:id,task_id:id,column_id:Number(input.column_id),
   position:Number(input.position)||1,updated:new Date().toISOString()}
  if(i<0)rows.push(row);else rows[i]=row
  board.placements=rows;save(s,'personal-board',board);return row
 }
 if(path==='/user/task-board/settings'&&method==='patch'){
  const data={...obj(s,'task-board-settings',{include_created_tasks:false}),...input}
  save(s,'task-board-settings',data);return data
 }
 if(path.startsWith('/time-entries')){
  if(path==='/time-entries/timer/stop'&&method==='post'){
   const rows=collection(s,'time-entries'),active=rows.find(x=>!x.end_time)
   if(!active)return UNHANDLED
   active.end_time=new Date().toISOString();saveCollection(s,'time-entries',rows);return active
  }
  return crud(s,'time-entries',path,'/time-entries',method,input)
 }
 if(path==='/admin/wialon/settings'&&method==='patch'){
  const data={...obj(s,'wialon-settings',wialon),...input,api_url:'',
   token_configured:false}
  delete data.token
  save(s,'wialon-settings',data);return data
 }
 if(path==='/admin/wialon/test'&&method==='post')return {
  ok:true,unit_count:0,message:'Демо: подключение к внешней системе не выполняется'}
 if(path==='/integrations/google-calendar/settings'&&method==='put'){
  const data={...obj(s,'calendar',calendar),...input};save(s,'calendar',data);return data
 }
 if(path==='/integrations/google-calendar/sync'&&method==='post')return {
  ...obj(s,'calendar',calendar),last_sync_at:new Date().toISOString()}
 if(path==='/integrations/google-calendar'&&method==='delete'){
  save(s,'calendar',calendar);return {}
 }
 if(path==='/admin/users'&&method==='post'){
  const id=Math.max(3,...s.users.map(u=>u.id))+1
  const clean={...input}
  delete clean.password
  delete clean.new_password
  delete clean.token
  const data={...s.users[1],...clean,id,username:'demo.user'+id,email:''}
  s.users.push(data);return data
 }
 const adminUser=path.match(/^\/admin\/users\/(\d+)(?:\/(status|admin|password|password-reset-email))?$/)
 if(adminUser){
  const i=s.users.findIndex(u=>u.id===Number(adminUser[1]))
  if(i<0)return UNHANDLED
  if(adminUser[2]==='password'||adminUser[2]==='password-reset-email')return {
   ...s.users[i],note:'Настоящие пароли и почта отключены'}
  if(method==='delete'){return s.users.splice(i,1)[0]}
  const updated={...s.users[i],...input}
  s.users[i]=updated;return updated
 }
 const adminOwner=path.match(/^\/admin\/projects\/(\d+)\/owner$/)
 if(adminOwner){
  const i=s.projects.findIndex(p=>p.id===Number(adminOwner[1]))
  if(i<0)return UNHANDLED
  s.projects[i]={...s.projects[i],owner_id:Number(input.owner_id)||1,
   owner:s.users.find(u=>u.id===Number(input.owner_id))??s.users[0]}
  return s.projects[i]
 }
 if(path==='/admin/access/groups'||/^\/admin\/access\/groups\/\d+$/.test(path))return crud(s,'groups',path,'/admin/access/groups',method,input)
 if(path==='/work-groups'||/^\/work-groups\/\d+$/.test(path))return crud(s,'work-groups',path,'/work-groups',method,input)
 if(path==='/webhooks'||/^\/webhooks\/\d+$/.test(path))return crud(s,'webhooks',path,'/webhooks',method,input)
 return UNHANDLED
}
