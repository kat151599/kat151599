/**
 * The ORIGINAL CallCenterView.vue and CallCenterDialer.vue consume these
 * contracts. State is fictional and per-visitor; dialer never uses SIP/Twilio,
 * and callback tasks exist only in browser-local Vikunja project/task fixtures.
 */
import type {BrowserDemoState} from './seed'
import {UNHANDLED} from './features'
type RecordData=Record<string,unknown>
const copy=<T>(obj:T):T=>JSON.parse(JSON.stringify(obj)) as T
const timestamp=()=>new Date().toISOString()
const historyKey='callcenter:events'
const callsKey='callcenter:calls'
const readExtra=(state:BrowserDemoState,key:string):RecordData[]=>{
 const data=state.extra[key]
 return Array.isArray(data)?data as RecordData[]:[]
}
const writeExtra=(state:BrowserDemoState,key:string,rows:RecordData[])=>{
 state.extra[key]=rows
}
const event=(state:BrowserDemoState,id:string,eventType:string,data:RecordData)=>{
 const rows=readExtra(state,historyKey)
 const item={id:'demo-event-'+(rows.length+1),lead_id:id,event_type:eventType,
  actor_user_id:'1',occurred_at:timestamp(),data:copy(data)}
 rows.push(item);writeExtra(state,historyKey,rows)
 return item
}
const leadOf=(state:BrowserDemoState,id:string)=>state.leads.find(l=>l.id===id)
export function readCallCenter(state:BrowserDemoState,path:string):unknown {
 if(path==='/callcenter/leads')return state.leads
 if(path==='/callcenter/dialer')return {batch:state.dialer.batch,empty:state.dialer.batch===null}
 if(path==='/call-center/website-attempts/stats')return {
  total:2,with_contact:2,without_contact:0}
 const idPath=path.match(/^\/callcenter\/leads\/([^/]+)(?:\/(history|history-snapshot))?$/)
 if(idPath){
  const id=decodeURIComponent(idPath[1]),lead=leadOf(state,id)
  if(!lead)return UNHANDLED
  if(!idPath[2])return lead
  return {lead,events:readExtra(state,historyKey).filter(e=>e.lead_id===id),
   calls:readExtra(state,callsKey).filter(c=>c.lead_id===id)}
 }
 return UNHANDLED
}
export function writeCallCenter(state:BrowserDemoState,method:string,path:string,input:RecordData):unknown {
 if(path==='/callcenter/leads/import'&&method==='post'){
  const values=Array.isArray(input.rows)?input.rows:[]
  let count=0
  for(const raw of values){
   if(!raw||typeof raw!=='object')continue
   const id='demo-lead-'+(state.leads.length+1)
   const row={...copy(state.leads[0]),...raw as RecordData,id,
    created_at:timestamp(),updated_at:timestamp()}
   state.leads.push(row as typeof state.leads[number]);count++
   event(state,id,'lead_created',{})
  }
  return {imported:count}
 }
 if(path==='/callcenter/leads'&&method==='post'){
  const id='demo-lead-'+(state.leads.length+1)
  const row={...copy(state.leads[0]),...input,id,created_at:timestamp(),
   updated_at:timestamp(),converted_at:null}
  state.leads.push(row as typeof state.leads[number])
  event(state,id,'lead_created',{})
  return row
 }
 const leadPath=path.match(/^\/callcenter\/leads\/([^/]+)$/)
 if(leadPath){
  const id=decodeURIComponent(leadPath[1])
  const lead=leadOf(state,id)
  if(!lead)return UNHANDLED
  if(method==='delete'){
   state.leads=state.leads.filter(l=>l.id!==id)
   return {id,deleted:true}
  }
  if(!['patch','put','post'].includes(method))return UNHANDLED
  const oldStatus=lead.status
  const updated={...lead,...input,id,updated_at:timestamp()}
  if(input.spam_action==='spam')Object.assign(updated,{is_spam:true})
  if(input.spam_action==='restore')Object.assign(updated,{is_spam:false})
  delete (updated as RecordData).spam_action
  const index=state.leads.findIndex(l=>l.id===id)
  state.leads[index]=updated as typeof lead
  if(oldStatus!==updated.status)event(state,id,'status_changed',{
   old_status:oldStatus,new_status:updated.status})
  return updated
 }
 const action=path.match(/^\/callcenter\/leads\/([^/]+)\/(events|calls|scheduled-calls|convert)$/)
 if(action&&method==='post'){
  const id=decodeURIComponent(action[1]),lead=leadOf(state,id)
  if(!lead)return UNHANDLED
  if(action[2]==='events')return event(state,id,String(input.event_type||'manual_note'),{
   text:String(input.text||'')})
  if(action[2]==='calls'){
   const calls=readExtra(state,callsKey)
   const item={id:'demo-call-'+(calls.length+1),lead_id:id,
    direction:String(input.direction||'outbound'),
    user_id:'1',outcome:String(input.outcome||'no_answer'),
    duration_seconds:Number(input.duration_seconds||0),notes:String(input.notes||''),
    started_at:String(input.started_at||timestamp()),created_at:timestamp()}
   calls.push(item);writeExtra(state,callsKey,calls)
   lead.last_called_at=timestamp()
   event(state,id,'call_recorded',{outcome:item.outcome,notes:item.notes})
   return item
  }
  if(action[2]==='scheduled-calls')return event(state,id,'callback_scheduled',{
   scheduled_at:String(input.scheduled_at||timestamp()),notes:String(input.notes||''),
   project_id:Number(input.project_id)||0,vikunja_task_id:Number(input.vikunja_task_id)||0})
  // Converting a fictional lead links to an existing fictional project. No API.
  lead.status='converted'
  ;(lead as {converted_at:string|null}).converted_at=timestamp()
  event(state,id,'lead_converted',{project_id:lead.vikunja_project_id||102})
  return {project_id:lead.vikunja_project_id||102,created:false,lead}
 }
 if(path==='/callcenter/dialer/next'&&method==='post'){
  const eligible=state.leads.filter(l=>l.status!=='converted'&&l.status!=='do_not_contact')
  const items=eligible.slice(0,8).map((lead,i)=>({
   batch_id:'demo-batch-'+state.dialer.sequence,lead_id:lead.id,position:i+1,
   state:'pending',deferred_reason:null,resolved_at:null,
   first_name:lead.first_name,last_name:lead.last_name,company:lead.company,
   phone:lead.phone,email:lead.email,status:lead.status,notes:lead.notes,
   source:lead.source,ingest_method:lead.ingest_method,created_at:timestamp()}))
  const batch={id:'demo-batch-'+state.dialer.sequence,created_at:timestamp(),items}
  state.dialer={sequence:state.dialer.sequence+1,batch}
  return {batch,empty:items.length===0}
 }
 const resolve=path.match(/^\/callcenter\/dialer\/items\/([^/]+)\/resolve$/)
 if(resolve&&method==='post'){
  const batch=state.dialer.batch
  if(!batch)return UNHANDLED
  const id=decodeURIComponent(resolve[1])
  const items=batch.items as Array<RecordData>
  const item=items.find(x=>x.lead_id===id)
  if(!item)return UNHANDLED
  item.state=input.mode==='deferred'?'deferred':'done'
  item.deferred_reason=item.state==='deferred'?String(input.reason||''):null
  item.resolved_at=timestamp()
  if(input.call_outcome)event(state,id,'call_recorded',{
   outcome:String(input.call_outcome),notes:String(input.notes||'')})
  state.dialer.batch={...batch,items}
  return {batch:state.dialer.batch,empty:false}
 }
 return UNHANDLED
}