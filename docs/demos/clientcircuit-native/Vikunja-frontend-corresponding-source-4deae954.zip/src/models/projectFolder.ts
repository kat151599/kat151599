import AbstractModel from './abstractModel'
import type {IProjectFolder} from '@/modelTypes/IProjectFolder'

export default class ProjectFolderModel extends AbstractModel<IProjectFolder> implements IProjectFolder {
	id = 0
	title = ''
	parentFolderId = 0
	position = 0
	created: Date = null
	updated: Date = null

	constructor(data: Partial<IProjectFolder> = {}) {
		super()
		this.assignData(data)

		if (this.created) {
			this.created = new Date(this.created)
		}
		if (this.updated) {
			this.updated = new Date(this.updated)
		}
	}
}
