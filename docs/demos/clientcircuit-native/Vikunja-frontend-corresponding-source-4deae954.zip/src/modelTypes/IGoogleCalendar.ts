export type GoogleCalendarReminderMethod = 'popup' | 'email'

export interface IGoogleCalendarReminder {
	method: GoogleCalendarReminderMethod
	minutes: number
}

export interface IGoogleCalendarStatus {
	enabled: boolean
	connected: boolean
	googleEmail?: string
	vikunjaCalendarId?: string
	syncEnabled: boolean
	reminders: IGoogleCalendarReminder[]
	lastSyncAt?: string
	lastSyncError?: string
	connectedAt?: string
}

export interface IGoogleCalendarConnect {
	url: string
}

export interface IGoogleCalendarCallback {
	code: string
	state: string
}

export interface IGoogleCalendarSettings {
	syncEnabled: boolean
	reminders: IGoogleCalendarReminder[]
}
