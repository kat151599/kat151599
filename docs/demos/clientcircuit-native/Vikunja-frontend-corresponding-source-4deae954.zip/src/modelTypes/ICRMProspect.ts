export type ProspectStatus =
| 'new'
| 'no_answer'
| 'in_progress'
| 'callback'
| 'interested'
| 'not_interested'
| 'invalid'
| 'archived'

export type ProspectCallOutcome =
| 'no_answer'
| 'busy'
| 'conversation'
| 'callback'
| 'interested'
| 'not_interested'
| 'wrong_number'

export interface IProspectUser {
id: number
name?: string
username?: string
}

export interface IProspectCampaign {
id: number
name: string
description: string
created_by_user_id: number
archived: boolean
created: string | Date
updated: string | Date
}

export interface IProspect {
id: number
campaign_id: number

company_name: string
contact_name: string

phone: string
phone_normalized: string
phone_secondary: string

email: string
website: string

region: string
city: string

notes: string
status: ProspectStatus

responsible_user_id: number
responsible?: IProspectUser

last_contact_at?: string | Date | null
next_contact_at?: string | Date | null

project_id: number

import_row_number?: number

created: string | Date
updated: string | Date
}

export interface IProspectPage {
items: IProspect[]
total: number
page: number
per_page: number
total_pages: number
}

export interface IProspectCreate {
campaign_id: number
company_name: string
contact_name: string
phone: string
phone_secondary: string
email: string
website: string
region: string
city: string
notes: string
status: ProspectStatus
responsible_user_id: number
}

export interface IProspectCampaignCreate {
name: string
description: string
}

export interface IProspectCall {
id: number
prospect_id: number
user_id: number
occurred_at: string | Date
outcome: ProspectCallOutcome
duration_minutes: number
note: string
next_contact_at?: string | Date | null
created: string | Date
}

export interface IProspectCallCreate {
outcome: ProspectCallOutcome
duration_minutes: number
note: string
next_contact_at?: string | null
}

export interface IProspectListParams {
q?: string
status?: ProspectStatus | ''
campaign_id?: number
responsible_user_id?: number
page?: number
per_page?: number
}